/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package wordleremake;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

/**
 *
 * @author River
 */
public class WordleGameplayScreen extends javax.swing.JPanel {
    
    private WordleMainFrame main;
    private JPanel cards;
    private CardLayout cl;
    private String[] cardsText;
    
    private ArrayList<JLabel> boardTiles = new ArrayList<>();   //Stores boardTiles (List of JLabels)
    private String[] dictionary = new String[2315];             //Our Wordle dictionary
    private String[] secretWordTiled = new String[5];           //String array holding each of the five letters of our secret word        
    private int startingRowTileIndex = 0;                       //Integer holding the index of the row's starting tile
    private int endingRowTileIndex = 4;                         //Integer holding the index of the row's ending tile
    private int movingTileIndex = 0;                            //Integer holding the index of the tile of which we are currently working with
    private int rowIndex = 1;                                   //Integer holding the index of the row currently being played
    boolean allRowsPlayed = false;                              //Boolean to tell whether all rows were played
    
    private ArrayList<JLabel> keyBoardTiles = new ArrayList<>();
    
    /**
     * Creates new form WordleRemakeBoard
     * @param main
     * @param cards
     * @param cl
     * @param cardsText
     */
    public WordleGameplayScreen(WordleMainFrame main, JPanel cards, CardLayout cl, String[] cardsText) {
        this.main = main;
        this.cards = cards;
        this.cl = cl;
        this.cardsText = cardsText;
        initComponents();
        initializeBoardTiles();
        populateDictionary();
        randomlySelectSecretWord();
        setFocusable(true);
        requestFocusInWindow();
        keyBoardTiles.add(labelQ); keyBoardTiles.add(labelW); keyBoardTiles.add(labelE); keyBoardTiles.add(labelR); keyBoardTiles.add(labelT);
        keyBoardTiles.add(labelY); keyBoardTiles.add(labelU); keyBoardTiles.add(labelI); keyBoardTiles.add(labelO); keyBoardTiles.add(labelP);
        keyBoardTiles.add(labelA); keyBoardTiles.add(labelS); keyBoardTiles.add(labelD); keyBoardTiles.add(labelF); keyBoardTiles.add(labelG);
        keyBoardTiles.add(labelH); keyBoardTiles.add(labelJ); keyBoardTiles.add(labelK); keyBoardTiles.add(labelL); keyBoardTiles.add(labelZ);
        keyBoardTiles.add(labelX); keyBoardTiles.add(labelC); keyBoardTiles.add(labelV); keyBoardTiles.add(labelB); keyBoardTiles.add(labelN);
        System.out.println(secretWordTiled[0] + secretWordTiled[1] + secretWordTiled[2] + secretWordTiled[3] + secretWordTiled[4]);
    }
    
    private void initializeBoardTiles(){
        JPanel overPanel = new JPanel();
        overPanel.setLayout(new GridLayout(6,5));
        overPanel.setBounds(0, 0, 235, 290);
        overPanel.setBackground(new Color(255,255,255));
        int x = 80;
        int y = 50;
        for (int i = 0; i < 30; i ++){
            if (i % 5 == 0){
                y = y + 50;
            }
            JLabel boardTile = new JLabel();
            boardTile.setBackground(new Color(255,255,255));
            boardTile.setForeground(new Color(0,0,0));
            boardTile.setFont(new java.awt.Font("Arial", Font.BOLD, 30));
            boardTile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            boardTile.setOpaque(true);
            Border tileBorder = BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0,0,0));
            boardTile.setBorder(tileBorder);
            boardTile.setBounds(x, y, 40, 40);
            boardTiles.add(boardTile);
            overPanel.add(boardTile);
            x = x + 50;
        }
        underPanel.add(overPanel);
    }
    
    private void populateDictionary() {
        try {
            URL url = new URL("https://gist.githubusercontent.com/cfreshman/a03ef2cba789d8cf00c08f767e0fad7b/raw/28804271b5a226628d36ee831b0e36adef9cf449/wordle-answers-alphabetical.txt");
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
             
            String line;
            int i = 0;
            while ((line = in.readLine()) != null) {
                dictionary[i] = line.toUpperCase();
                i++;
            }
            in.close();
        }
        catch (MalformedURLException e) {
            System.out.println("Malformed URL: " + e.getMessage());
        }
        catch (IOException e) {
            System.out.println("I/O Error: " + e.getMessage());
        }
    }
    
    public void randomlySelectSecretWord() {
        String secretWord = dictionary[(int) (Math.random() * dictionary.length) + 0];
        secretWordTiled[0] = secretWord.substring(0, 1);
        secretWordTiled[1] = secretWord.substring(1, 2);
        secretWordTiled[2] = secretWord.substring(2, 3);
        secretWordTiled[3] = secretWord.substring(3, 4);
        secretWordTiled[4] = secretWord.substring(4, 5);
    }
    
    public void resetBoardTiles() {
        for (JLabel bTiles : boardTiles){
            bTiles.setBackground(new Color(255,255,255));
            bTiles.setForeground(new Color(0,0,0));
            bTiles.setText("");
        }
    }
    
    public void resetBoardTileIndices() {
        startingRowTileIndex = 0;
        endingRowTileIndex = 4;
        movingTileIndex = 0;
        rowIndex = 1;
        allRowsPlayed = false;
    }
    
    public void resetKeyBoardTiles() {
        for (JLabel keyTiles : keyBoardTiles){
            keyTiles.setBackground(new Color(230,230,230));
            keyTiles.setForeground(new Color(0,0,0));
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelP = new javax.swing.JLabel();
        labelW = new javax.swing.JLabel();
        labelE = new javax.swing.JLabel();
        labelR = new javax.swing.JLabel();
        labelT = new javax.swing.JLabel();
        labelY = new javax.swing.JLabel();
        labelU = new javax.swing.JLabel();
        labelI = new javax.swing.JLabel();
        labelO = new javax.swing.JLabel();
        labelA = new javax.swing.JLabel();
        labelS = new javax.swing.JLabel();
        labelD = new javax.swing.JLabel();
        labelF = new javax.swing.JLabel();
        labelG = new javax.swing.JLabel();
        labelH = new javax.swing.JLabel();
        labelJ = new javax.swing.JLabel();
        labelK = new javax.swing.JLabel();
        labelL = new javax.swing.JLabel();
        labelZ = new javax.swing.JLabel();
        labelX = new javax.swing.JLabel();
        labelC = new javax.swing.JLabel();
        labelV = new javax.swing.JLabel();
        labelB = new javax.swing.JLabel();
        labelN = new javax.swing.JLabel();
        labelM = new javax.swing.JLabel();
        labelQ = new javax.swing.JLabel();
        underPanel = new javax.swing.JPanel();
        exitLabel = new javax.swing.JLabel();
        backToStartLabel = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 0, 204));
        setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelP.setBackground(new java.awt.Color(230, 230, 230));
        labelP.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelP.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelP.setText("P");
        labelP.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelP.setOpaque(true);
        add(labelP, new org.netbeans.lib.awtextra.AbsoluteConstraints(325, 390, 25, 25));

        labelW.setBackground(new java.awt.Color(230, 230, 230));
        labelW.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelW.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelW.setText("W");
        labelW.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelW.setOpaque(true);
        add(labelW, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 390, 25, 25));

        labelE.setBackground(new java.awt.Color(230, 230, 230));
        labelE.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelE.setText("E");
        labelE.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelE.setOpaque(true);
        add(labelE, new org.netbeans.lib.awtextra.AbsoluteConstraints(115, 390, 25, 25));

        labelR.setBackground(new java.awt.Color(230, 230, 230));
        labelR.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelR.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelR.setText("R");
        labelR.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelR.setOpaque(true);
        add(labelR, new org.netbeans.lib.awtextra.AbsoluteConstraints(145, 390, 25, 25));

        labelT.setBackground(new java.awt.Color(230, 230, 230));
        labelT.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelT.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelT.setText("T");
        labelT.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelT.setOpaque(true);
        add(labelT, new org.netbeans.lib.awtextra.AbsoluteConstraints(175, 390, 25, 25));

        labelY.setBackground(new java.awt.Color(230, 230, 230));
        labelY.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelY.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelY.setText("Y");
        labelY.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelY.setOpaque(true);
        add(labelY, new org.netbeans.lib.awtextra.AbsoluteConstraints(205, 390, 25, 25));

        labelU.setBackground(new java.awt.Color(230, 230, 230));
        labelU.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelU.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelU.setText("U");
        labelU.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelU.setOpaque(true);
        add(labelU, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 390, 25, 25));

        labelI.setBackground(new java.awt.Color(230, 230, 230));
        labelI.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelI.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelI.setText("I");
        labelI.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelI.setOpaque(true);
        add(labelI, new org.netbeans.lib.awtextra.AbsoluteConstraints(265, 390, 25, 25));

        labelO.setBackground(new java.awt.Color(230, 230, 230));
        labelO.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelO.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelO.setText("O");
        labelO.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelO.setOpaque(true);
        add(labelO, new org.netbeans.lib.awtextra.AbsoluteConstraints(295, 390, 25, 25));

        labelA.setBackground(new java.awt.Color(230, 230, 230));
        labelA.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelA.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelA.setText("A");
        labelA.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelA.setOpaque(true);
        add(labelA, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 420, 25, 25));

        labelS.setBackground(new java.awt.Color(230, 230, 230));
        labelS.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelS.setText("S");
        labelS.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelS.setOpaque(true);
        add(labelS, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 420, 25, 25));

        labelD.setBackground(new java.awt.Color(230, 230, 230));
        labelD.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelD.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelD.setText("D");
        labelD.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelD.setOpaque(true);
        add(labelD, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 420, 25, 25));

        labelF.setBackground(new java.awt.Color(230, 230, 230));
        labelF.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelF.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelF.setText("F");
        labelF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelF.setOpaque(true);
        add(labelF, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 420, 25, 25));

        labelG.setBackground(new java.awt.Color(230, 230, 230));
        labelG.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelG.setText("G");
        labelG.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelG.setOpaque(true);
        add(labelG, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 420, 25, 25));

        labelH.setBackground(new java.awt.Color(230, 230, 230));
        labelH.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelH.setText("H");
        labelH.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelH.setOpaque(true);
        add(labelH, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 420, 25, 25));

        labelJ.setBackground(new java.awt.Color(230, 230, 230));
        labelJ.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelJ.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelJ.setText("J");
        labelJ.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelJ.setOpaque(true);
        add(labelJ, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 420, 25, 25));

        labelK.setBackground(new java.awt.Color(230, 230, 230));
        labelK.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelK.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelK.setText("K");
        labelK.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelK.setOpaque(true);
        add(labelK, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 420, 25, 25));

        labelL.setBackground(new java.awt.Color(230, 230, 230));
        labelL.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelL.setText("L");
        labelL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelL.setOpaque(true);
        add(labelL, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 420, 25, 25));

        labelZ.setBackground(new java.awt.Color(230, 230, 230));
        labelZ.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelZ.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelZ.setText("Z");
        labelZ.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelZ.setOpaque(true);
        add(labelZ, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 450, 25, 25));

        labelX.setBackground(new java.awt.Color(230, 230, 230));
        labelX.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelX.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelX.setText("X");
        labelX.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelX.setOpaque(true);
        add(labelX, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 450, 25, 25));

        labelC.setBackground(new java.awt.Color(230, 230, 230));
        labelC.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelC.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelC.setText("C");
        labelC.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelC.setOpaque(true);
        add(labelC, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 450, 25, 25));

        labelV.setBackground(new java.awt.Color(230, 230, 230));
        labelV.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelV.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelV.setText("V");
        labelV.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelV.setOpaque(true);
        add(labelV, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 450, 25, 25));

        labelB.setBackground(new java.awt.Color(230, 230, 230));
        labelB.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelB.setText("B");
        labelB.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelB.setOpaque(true);
        add(labelB, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 450, 25, 25));

        labelN.setBackground(new java.awt.Color(230, 230, 230));
        labelN.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelN.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelN.setText("N");
        labelN.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelN.setOpaque(true);
        add(labelN, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 450, 25, 25));

        labelM.setBackground(new java.awt.Color(230, 230, 230));
        labelM.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelM.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelM.setText("M");
        labelM.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelM.setOpaque(true);
        add(labelM, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 450, 25, 25));

        labelQ.setBackground(new java.awt.Color(230, 230, 230));
        labelQ.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelQ.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelQ.setText("Q");
        labelQ.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        labelQ.setOpaque(true);
        add(labelQ, new org.netbeans.lib.awtextra.AbsoluteConstraints(55, 390, 25, 25));

        underPanel.setFocusable(false);

        javax.swing.GroupLayout underPanelLayout = new javax.swing.GroupLayout(underPanel);
        underPanel.setLayout(underPanelLayout);
        underPanelLayout.setHorizontalGroup(
            underPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 235, Short.MAX_VALUE)
        );
        underPanelLayout.setVerticalGroup(
            underPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 290, Short.MAX_VALUE)
        );

        add(underPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 50, 235, 290));

        exitLabel.setBackground(new java.awt.Color(255, 0, 204));
        exitLabel.setFont(new java.awt.Font("Franklin Gothic Medium Cond", 0, 30)); // NOI18N
        exitLabel.setForeground(new java.awt.Color(255, 255, 255));
        exitLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitLabel.setText("×");
        exitLabel.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 0, 0, 3, new java.awt.Color(0, 0, 0)));
        exitLabel.setOpaque(true);
        exitLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitLabelMouseExited(evt);
            }
        });
        add(exitLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, 60, 30));

        backToStartLabel.setBackground(new java.awt.Color(255, 0, 204));
        backToStartLabel.setFont(new java.awt.Font("Franklin Gothic Medium Cond", 0, 24)); // NOI18N
        backToStartLabel.setForeground(new java.awt.Color(255, 255, 255));
        backToStartLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        backToStartLabel.setText("<html><b>←</b></html>");
        backToStartLabel.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 0, 0, new java.awt.Color(0, 0, 0)));
        backToStartLabel.setOpaque(true);
        backToStartLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backToStartLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                backToStartLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                backToStartLabelMouseExited(evt);
            }
        });
        add(backToStartLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 60, 30));
    }// </editor-fold>//GEN-END:initComponents
    
    private void exitLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitLabelMouseClicked

    private void exitLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitLabelMouseEntered
        exitLabel.setBackground(new java.awt.Color(255, 0, 51));
    }//GEN-LAST:event_exitLabelMouseEntered

    private void exitLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitLabelMouseExited
        exitLabel.setBackground(new java.awt.Color(255,0,204));
    }//GEN-LAST:event_exitLabelMouseExited

    private void backToStartLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backToStartLabelMouseClicked
        WordleReturnToStartOptionFrame wordleReturnToStartOptionFrame = new WordleReturnToStartOptionFrame(main, cards, cl, cardsText);
    }//GEN-LAST:event_backToStartLabelMouseClicked

    private void backToStartLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backToStartLabelMouseEntered
        backToStartLabel.setBackground(new Color(255,30,234));
    }//GEN-LAST:event_backToStartLabelMouseEntered

    private void backToStartLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backToStartLabelMouseExited
        backToStartLabel.setBackground(new Color(255,0,204));
    }//GEN-LAST:event_backToStartLabelMouseExited

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_DELETE) { //If Delete key is pressed, prompt exit to start option frame
            WordleReturnToStartOptionFrame wordleReturnToStartOptionFrame = new WordleReturnToStartOptionFrame(main, cards, cl, cardsText);
        }
        if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) { //If Esc key is pressed, close main frame
            System.exit(0);
        }
        if (evt.getKeyCode() == KeyEvent.VK_BACK_SPACE){ //if Backspace key is pressed, remove character from board (if possible)
            if (movingTileIndex != startingRowTileIndex) {
                movingTileIndex -= 1;
                boardTiles.get(movingTileIndex).setText(" ");
            }
        }
        for (int i = 65; i <= 90; i++) { //if any letter key is pressed, add that letter to the board (if possible)
            if (evt.getKeyCode() == i) {
                if (movingTileIndex - 1 != endingRowTileIndex) {
                    boardTiles.get(movingTileIndex).setText(String.valueOf(evt.getKeyChar()).toUpperCase());
                    movingTileIndex += 1;
                }
            }
        }
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) { //if Enter key is pressed, verify word
            String submittedWord = "";
            for (int i = startingRowTileIndex; i <= endingRowTileIndex; i++){ //assign boardTiles characters to submittedWord String
                submittedWord = submittedWord + boardTiles.get(i).getText(); 
            }
            var al = new ArrayList<String>(Arrays.asList(dictionary)); //Convert dictionary array into ArrayList
            //If submittedWord IS NOT a word
            if (!al.contains(submittedWord)){
                WordleNotAWordFrame wordleNotAWordFrame = new WordleNotAWordFrame(main);
            //If submittedWord IS a word
            } else {
                //Loop through boardTiles and change boardTile background colors based on the rules
                for (int i = startingRowTileIndex; i <= endingRowTileIndex; i++){
                    //If boardTiles[0] and secretWordTiled[0] have the same text, make boardTiles[0] background green
                    //If boardTiles[1] and secretWordTiled[1] have the same text, make boardTiles[1] background green
                    //If boardTiles[2] and secretWordTiled[2] have the same text, make boardTiles[2] background green
                    //If boardTiles[3] and secretWordTiled[3] have the same text, make boardTiles[3] background green
                    //If boardTiles[4] and secretWordTiled[4] have the same text, make boardTiles[4] background green
                    if (boardTiles.get(i).getText().toString().equals(getSecretWordTiled()[i-startingRowTileIndex].toString())){
                        boardTiles.get(i).setBackground(new Color(0,204,51));
                        boardTiles.get(i).setForeground(Color.white);
                    //If boardTiles[i] and secretWordTiled[i] have the same text, make boardTiles[i] background orange
                    } else if (boardTiles.get(i).getText().toString().equals(getSecretWordTiled()[0].toString()) ||
                               boardTiles.get(i).getText().toString().equals(getSecretWordTiled()[1].toString()) ||
                               boardTiles.get(i).getText().toString().equals(getSecretWordTiled()[2].toString()) ||
                               boardTiles.get(i).getText().toString().equals(getSecretWordTiled()[3].toString()) ||
                               boardTiles.get(i).getText().toString().equals(getSecretWordTiled()[4].toString()) ){
                        boardTiles.get(i).setBackground(Color.orange);
                        boardTiles.get(i).setForeground(Color.white);
                    //If boardTile[i] and any of secretWordTiled[i] text do not match, make boardTiles[i] background dark gray
                    } else {
                        boardTiles.get(i).setBackground(Color.darkGray);
                        boardTiles.get(i).setForeground(Color.white);
                    }
                }
                //Double loop to remove orange background colors from any boardTiles that follow boardTiles with green background colors
                for (int i = startingRowTileIndex; i <= endingRowTileIndex; i++){
                    if (boardTiles.get(i).getBackground().equals(new Color(0,204,51))){
                        for (int j = i + 1; j <= endingRowTileIndex; j++){
                            if (boardTiles.get(j).getBackground().equals(Color.orange) && boardTiles.get(i).getText().equals(boardTiles.get(j).getText())){
                                boardTiles.get(j).setBackground(Color.darkGray);
                            }
                        }
                    }
                }
                //Double loop to remove orange background colors from any boardTiles that follow boardTiles with orange background colors
                for (int i = startingRowTileIndex; i <= endingRowTileIndex; i++){
                    if (boardTiles.get(i).getBackground().equals(Color.orange)){
                        for (int j = i + 1; j <= endingRowTileIndex; j++){
                            if (boardTiles.get(j).getBackground().equals(Color.orange) && boardTiles.get(i).getText().equals(boardTiles.get(j).getText())){
                                boardTiles.get(j).setBackground(Color.darkGray);
                            }
                        }
                    }
                }
                //keyBoardTiles background color change based on updated boardTile background changes
                for (int i = 0; i < keyBoardTiles.size(); i++){
                    for (int j = startingRowTileIndex; j <= endingRowTileIndex; j++) {
                        if (keyBoardTiles.get(i).getText().toString().equals(boardTiles.get(j).getText().toString())){
                            if ((keyBoardTiles.get(i).getBackground().equals(Color.orange) &&           //if keyTile is orange and bTile is green
                                    boardTiles.get(j).getBackground().equals(new Color(0,204,51))) ||
                                (keyBoardTiles.get(i).getBackground().equals(Color.darkGray) &&         //if keyTile is darkGray and bTile is green
                                    boardTiles.get(j).getBackground().equals(new Color(0,204,51))) ||
                                (keyBoardTiles.get(i).getBackground().equals(new Color(230,230,230)) && //if keyTile is lightGray and bTile is green
                                    boardTiles.get(j).getBackground().equals(new Color(0,204,51)))) {
                                keyBoardTiles.get(i).setBackground(new Color(0,204,51));                //SET to green
                                keyBoardTiles.get(i).setForeground(new Color(255,255,255));
                                
                            } else if ((keyBoardTiles.get(i).getBackground().equals(Color.darkGray) &&          //if keyTile is darkGray and bTile is orange
                                            boardTiles.get(j).getBackground().equals(Color.orange)) || 
                                       (keyBoardTiles.get(i).getBackground().equals(new Color(230,230,230)) &&  //if keyTile is lightGray and bTile is orange
                                            boardTiles.get(j).getBackground().equals(Color.orange))) {
                                keyBoardTiles.get(i).setBackground(Color.orange);                               //SET to orange
                                keyBoardTiles.get(i).setForeground(new Color(255,255,255));
                                
                            } else if ((keyBoardTiles.get(i).getBackground().equals(new Color(230,230,230)) && //if keyTile is lightGray and bTile is darkGray
                                            boardTiles.get(j).getBackground().equals(Color.darkGray))){
                                keyBoardTiles.get(i).setBackground(Color.darkGray);                            //SET to darkGray
                                keyBoardTiles.get(i).setForeground(new Color(255,255,255));
                            }
                        }
                    }
                }
                
                //If your submitted word matches the secret word, you win
                if (boardTiles.get(startingRowTileIndex).getBackground().equals(new Color(0,204,51)) &&
                    boardTiles.get(startingRowTileIndex + 1).getBackground().equals(new Color(0,204,51)) &&
                    boardTiles.get(startingRowTileIndex + 2).getBackground().equals(new Color(0,204,51)) &&
                    boardTiles.get(startingRowTileIndex + 3).getBackground().equals(new Color(0,204,51)) &&
                    boardTiles.get(startingRowTileIndex).getBackground().equals(new Color(0,204,51)) ){
                    
                    String secretWord = getSecretWordTiled()[0] + getSecretWordTiled()[1] + getSecretWordTiled()[2] +
                                        getSecretWordTiled()[3] + getSecretWordTiled()[4];
                    WordleYouWonFrame wordleYouWonFrame = new WordleYouWonFrame(main, "The word was: " + secretWord, this);
                }
                
                if (rowIndex <= 6){
                    rowIndex++;
                    startingRowTileIndex += 5;
                    endingRowTileIndex += 5;
                }
                if (rowIndex >= 7){
                    allRowsPlayed = true;
                }
                //If your submitted word does not match the secret word at the end of the game, you lose
                if (allRowsPlayed) {
                    if (!(boardTiles.get(startingRowTileIndex - 5).getBackground().equals(new Color(0,204,51)) &&
                          boardTiles.get(startingRowTileIndex - 4).getBackground().equals(new Color(0,204,51)) &&
                          boardTiles.get(startingRowTileIndex - 3).getBackground().equals(new Color(0,204,51)) &&
                          boardTiles.get(startingRowTileIndex - 2).getBackground().equals(new Color(0,204,51)) &&
                          boardTiles.get(startingRowTileIndex - 1).getBackground().equals(new Color(0,204,51)))){
                    System.out.println("Made it");
                    String secretWord = getSecretWordTiled()[0] + getSecretWordTiled()[1] + getSecretWordTiled()[2] +
                                        getSecretWordTiled()[3] + getSecretWordTiled()[4];
                    WordleYouLoseFrame wordleYouLoseFrame = new WordleYouLoseFrame(main, "The word was: " + secretWord, this);
                    }
                }
                
            }
            System.out.println(allRowsPlayed);
            System.out.println("current row: " + rowIndex);
            System.out.println("moving index: " + movingTileIndex);
            System.out.println("starting index: " + startingRowTileIndex);
            System.out.println("ending index: " + endingRowTileIndex);
            System.out.println("All rows are played: " + allRowsPlayed);
        }
    }//GEN-LAST:event_formKeyPressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel backToStartLabel;
    private javax.swing.JLabel exitLabel;
    private javax.swing.JLabel labelA;
    private javax.swing.JLabel labelB;
    private javax.swing.JLabel labelC;
    private javax.swing.JLabel labelD;
    private javax.swing.JLabel labelE;
    private javax.swing.JLabel labelF;
    private javax.swing.JLabel labelG;
    private javax.swing.JLabel labelH;
    private javax.swing.JLabel labelI;
    private javax.swing.JLabel labelJ;
    private javax.swing.JLabel labelK;
    private javax.swing.JLabel labelL;
    private javax.swing.JLabel labelM;
    private javax.swing.JLabel labelN;
    private javax.swing.JLabel labelO;
    private javax.swing.JLabel labelP;
    private javax.swing.JLabel labelQ;
    private javax.swing.JLabel labelR;
    private javax.swing.JLabel labelS;
    private javax.swing.JLabel labelT;
    private javax.swing.JLabel labelU;
    private javax.swing.JLabel labelV;
    private javax.swing.JLabel labelW;
    private javax.swing.JLabel labelX;
    private javax.swing.JLabel labelY;
    private javax.swing.JLabel labelZ;
    private javax.swing.JPanel underPanel;
    // End of variables declaration//GEN-END:variables

    /**
     * @return the secretWordTiled
     */
    public String[] getSecretWordTiled() {
        return secretWordTiled;
    }

}
