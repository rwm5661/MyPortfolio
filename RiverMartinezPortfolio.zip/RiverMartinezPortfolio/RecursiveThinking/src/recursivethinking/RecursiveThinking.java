/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package recursivethinking;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;

/**
 *
 * @author River
 */
public class RecursiveThinking {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        spellName("RIVER");
    }
    
    public static void spellName(String name){
        int length = name.length();
        int i = 0;
        int j = 1;
        if (i == length){
            System.out.println("all done");
        } else {
            System.out.println(name.substring(i, j));
            i++;
            j++;
            spellName(name.substring(i, length));
        }    
    }
}
