package Lab3;


/*
 * File: Customer.java
 * Author: Java, Java, Java
 * Description: This class defines a customer thread for
 *  the bakery simulation. Each customer object has a 
 *  reference to the TakeANumber gadget. When a customer 
 *  arrives in the bakery, it takes a number and then
 *  waits to be served. 
 */

/**  
 * IST 411-001 - Lab #3 
 * Customer.java  
 * Purpose: Runs the Customer Thread - Customer enters shop, then takes a ticket
 *  
 * @author Bill Cantor & River Martinez
 * @version 1.1 1/31/2021  
 */
public class Customer extends Thread { //inherits Thread class
  
    private static int number = 10000;      //Initial ID number
    private int id;                         //Holds actual Customer ID
    private TakeANumber takeANumber;        //TakeANumber attribute
    private Shop shop;                      //Shop attribute
  
    /** 
     * Customer() constructor gives each customer a reference
     * to the shared TakeANumber gadget and gives each an id number.
     * 
     * @param sentShop
     * @param gadget
     */
    public Customer(Shop sentShop, TakeANumber gadget) {
        id = ++number;
        takeANumber = gadget;
        shop = sentShop;
    }
  
    /**
     *  run() is the main algorithm for the customer thread. It allows Customers 
     *  to enter the shop and take a number when they enter the bakery. Customers then
     *  waits to be served until the clerk calls its number.
     */
    public void run() {
        try {
            sleep((int)(Math.random() * 2000));
            takeANumber.nextNumber(shop.enterShop(id));
        } catch (InterruptedException e) {
            System.out.println("Exception: " + e.getMessage() );
        }  
    } // run()
} // Customer

