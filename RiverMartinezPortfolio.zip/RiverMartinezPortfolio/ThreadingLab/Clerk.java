package Lab3;


/*
 * File: Clerk.java
 * Author: Java, Java, Java
 * Description: This class defines the clerk thread of
 *  the bakery simulation. The clerk has a reference to
 *  the TakeANumber gadget. The clerk "serves" the next
 *  customer by repeatedly calling takeANumber.nextCustomer().
 *  To simulate the randomness involved in serving times,
 *  the clerk sleeps for a random interval on each iteration of
 *  its run loop.
 */

/**  
 * IST 411-001 - Lab #3 
 * Clerk.java  
 * Purpose: Runs the Clerk Thread - Clerk serves Customer, then Customer leaves
 *  
 * @author Bill Cantor & River Martinez  
 * @version 1.1 1/31/2021  
 */
public class Clerk extends Thread { //inherits Thread class
    
    private TakeANumber takeANumber;           //TakeANumber attribute
    private Shop shop;                         //Shop attribute
    
    /** 
     * Clerk() constructor gives the clerk a reference to the
     * TakeANumber gadget and the Shop class.
     * 
     * @param myShop
     * @param gadget
     */
    public Clerk(Shop myShop, TakeANumber gadget) {
        takeANumber = gadget;
        shop = myShop;
    }

    /**
     *  run() is the main algorithm for the clerk thread. Note
     *  that it runs in an infinite loop.  Note that in this version
     *  the clerk no longer checks if there are customers waiting before
     *  calling nextCustomer(). This check has been moved into the
     *  TakeANumber object itself.
     * 
     *  run() executes the nextCustomer(), allowing Customers to be taken by the Clerk. 
     *  It will return and pass ticket number to leaveShop() allowing Customers to leave the shop
     */
    public void run() {
        while (true) {
            try {
                sleep((int)(Math.random() * 1000));
                shop.leaveShop(takeANumber.nextCustomer());
            } catch (InterruptedException e) {
                System.out.println("Exception: " + e.getMessage() );
            }  
        } // while
    } // run()
} // Clerk
