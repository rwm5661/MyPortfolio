package Lab3;

import java.util.logging.Level;
import java.util.logging.Logger;

/**  
 * IST 411-001 - Lab #3 
 * Shop.java  
 * Purpose: Invokes methods to allow customers to enter and exit the shop
 *  
 * @author River Martinez  
 * @version 1.1 1/31/2021  
 */
public class Shop {
    
    private int shopSize; //integer variable holding the number of customer in the shop
    
    /**
     * Shop constructor
     */
    public Shop()
    {
        shopSize = 0; //shopSize initialized to 0
    }
    
    /**
     * enterShop() allows Customers to enter the Shop. If shopSize equals 5, the Shop is considered full 
     * and the wait() is executed, preventing Customers from entering the Shop. If the Shop is not full, 
     * shopSize is incremented and a Customer is allowed to enter.
     * 
     * @param custNo
     * @return 
     */
    public synchronized int enterShop(int custNo)
    {
        try {
            while (shopSize == 5){
                wait();
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Shop.class.getName()).log(Level.SEVERE, null, ex);
        } finally { //executes block of code no matter what
            ++shopSize;
            System.out.println("Customer " + custNo + " has entered - Shop size: " + shopSize);
            return custNo;
        }
    }
    
    /**
     * leaveShop() allows Customers to leave the Shop. When leaveShop() is executed, 
     * shopSize is decremented, Customer is allowed to leave, and notify() is executed.
     * When notify() executes, the next thread waiting wakes up.
     * 
     * @param ticket
     * @return
     */
    public synchronized int leaveShop(int ticket)
    {
        --shopSize;
        System.out.println("Ticket " + ticket + " has left");
        notify();
        return ticket;
    }
}
