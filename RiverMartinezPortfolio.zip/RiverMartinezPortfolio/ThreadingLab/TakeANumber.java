package Lab3;
/*
 * File: TakeANumber.java
 * Author: Java, Java, Java
 * Description: An instance of this class serves as
 *  a shared resource for the customers and clerk threads
 *  of the bakery simulation. This object contains two
 *  instance variables, both of which are initialized to 0.
 *  The variable next represents the next place in line. 
 *  This simulates the "ticket" given to customers as they
 *  arrive. The variable "serving" represents the next 
 *  customer to be served. This simulates the "now serving"
 *  display that the clerk accesses to determine who's next.

 * In this version all of its methods are synchronized and
 *  the println() statements that report the state of the
 *  simulation have been moved into these syncrhonized methods.
 *  Also, the nextCustomer() method forces the clerk to wait
 *  if there are no customers.
 */

/**  
 * IST 411-001 - Lab #3 
 * TakeANumber.java  
 * Purpose: Invokes methods to allow customers to take a ticket and the clerk to serve customers
 *  
 * @author Bill Cantor & River Martinez
 * @version 1.1 1/31/2021  
 */
public class TakeANumber {

    private int next = 0;           //number of customers who are next
    private int serving = 0;        //holds ticket/serving number
  
    /**
     * nextNumber() allows Customers to take a ticket. First, next is incremented by 1.
     * Then, Customer takes a ticket. Finally, notify() is executed letting the Clerk 
     * know there are Customers to be served.
     * 
     * @param custId
     * @return 
     */
    public synchronized int nextNumber(int custId) {
        next = next + 1;
        System.out.println( "Customer " + custId + " takes ticket " + next );
        notify();
        return next;
    } // nextNumber()
  
    /**
     * nextCustomer() allows Clerk to serve Customers. 
     * First, Clerk checks if there are Customers to be served. 
     * If no customer are present, the wait() is executed (Clerk waits for Customers). 
     * If Customers are present, serving is incremented by 1 and Customer is served.
     * 
     * @return 
     */
    public synchronized int nextCustomer() {
        try {
            while (next <= serving)  { 
                System.out.println("  Clerk waiting ");  
                wait();
            }
        } catch(InterruptedException e) {
            System.out.println("Exception " + e.getMessage() );
        } finally {
            ++serving;
            System.out.println("  Clerk serving ticket " + serving );
            return serving;
        }
    } // nextCustomer()
} // TakeANumber
