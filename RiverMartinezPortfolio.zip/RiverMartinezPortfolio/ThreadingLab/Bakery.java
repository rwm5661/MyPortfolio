package Lab3;


/*
 * File: Bakery.java
 * Author: Java, Java, Java
 * Description: This is the main class for the bakery 
 *  simulation. It first creates a TakeANumber gadget, which 
 *  simulates the gadget that keeps track of waiting lines in
 *  banks and bakeries. It then creates a clerk and 5 customers,
 *  each implemented as a separate thread, and each of which is
 *  passed a reference to the TakeANumber object. Thus all the
 *  threads in the simulation share the TakeANumber resource.  
 *  Each thread is started. Controls built into the 
 *  threads themselves are responsible for managing the simulation.  
 */

/**  
 * IST 411-001 - Lab #3 
 * Bakery.java  
 * Purpose: Instantiates Bakery objects (Shop, TakeANumber, Customer, and Clerk)
 * and executes the Customer and Clerk Threads
 *  
 * @author Bill Cantor & River Martinez  
 * @version 1.1 1/31/2021  
 */
public class Bakery {
    
    public static void main(String args[]) { //main method
        System.out.println( "Starting clerk and customer threads" );
        Shop shop = new Shop();
        TakeANumber numberGadget = new TakeANumber();
        Clerk clerk = new Clerk(shop,numberGadget);
        clerk.start();
        for (int k = 0; k < 10; k++) {
            Customer customer = new Customer(shop,numberGadget);
            customer.start();
        }
    } // main()
} // Bakery
