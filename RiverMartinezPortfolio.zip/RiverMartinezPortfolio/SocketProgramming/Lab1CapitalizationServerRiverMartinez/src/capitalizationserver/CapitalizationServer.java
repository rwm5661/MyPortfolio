package capitalizationserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**  
 * IST 411-001 - Lab #1  
 * CapitalizationServer.java  
 * Purpose: Creates a capitalization echo server  
 *  
 * @author River Martinez  
 * @version 1.0 1/24/2021  
 */ 
public class CapitalizationServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Capitalization Echo Server");
        try (ServerSocket serverSocket = new ServerSocket(6000)){       
            System.out.println("Waiting for connection.....");

            Socket clientSocket = serverSocket.accept(); //blocks call until client connects
            System.out.println("Connected to client"); //Console outputs this message when connected

            //Receives and sends messages from and to client using BufferedReader, InputStreamReader and PrintWriter objects
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(clientSocket.getInputStream()));
                    PrintWriter out = new PrintWriter(
                            clientSocket.getOutputStream(), true)) {
                // Traditional implementation
                String inputLine;
                while ((inputLine = br.readLine()) != null) {
                    System.out.println("Client request: " + inputLine);
                    out.println(inputLine.toUpperCase());
                }
            } 
            catch (IOException ex) {
                ex.printStackTrace();
            }
        } 
        catch (IOException ex) {
            ex.printStackTrace();
        }
        System.out.println("Capitalization Echo Server Terminating"); //Console outputs this message when client quits the server
    }
}
