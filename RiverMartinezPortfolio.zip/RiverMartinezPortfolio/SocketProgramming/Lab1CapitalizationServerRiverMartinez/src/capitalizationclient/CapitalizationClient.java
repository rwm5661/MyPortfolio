package capitalizationclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

/**  
 * IST 411-001 - Lab #1  
 * CapitalizationClient.java  
 * Purpose: Creates a capitalization echo server client  
 *  
 * @author River Martinez  
 * @version 1.0 1/24/2021  
 */
public class CapitalizationClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Capitalization Echo Client");
        try {
            System.out.println("Waiting for connection.....");
            InetAddress localAddress = InetAddress.getLocalHost(); //retrieves IP Address of local host

            //Client tries to connect server on local host address on port 6000
            try (Socket clientSocket = new Socket(localAddress, 6000);
                    PrintWriter out = new PrintWriter(
                            clientSocket.getOutputStream(), true); //PrintWriter object used to send messages to server
                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(                 //BufferedReader and InputStreamReader objects used to receive messages to server
                                    clientSocket.getInputStream()))) {
                System.out.println("Connected to server"); //Console outputs this message when client connects to server
                Scanner scanner = new Scanner(System.in);

                // Traditional implementation
                while (true) {
                    System.out.print("Enter text: ");
                    String inputLine = scanner.nextLine(); 
                    if ("quit".equalsIgnoreCase(inputLine)) {
                        break;
                    }
                    out.println(inputLine);

                    String response = br.readLine();
                    System.out.println("Server response: " + response);
                }
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
