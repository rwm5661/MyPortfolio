//Name: River Martinez
//Assignment: Homework 8
//Due: December 4, 2020
//rwm5661.psu.edu

package defaultpackage;

//Class name: GuessTheNumberUI.java 2.4
//Purpose of class: contains main method; runs Guess The Number application

public class GuessTheNumberUI 
{
    public static void main(String[] args) //main method
    {
        GuessTheNumberGUI gameFrame = new GuessTheNumberGUI(); //Instantiates GuessTheNumberFrame object
        gameFrame.getComputerPlay().doClick(); //Automatic click of Computer Plays Mode on start up
        GuessTheNumber game = new GuessTheNumber(); //Instantiates GuessTheNumberGame object
        game.autoPlay(); //runs Guess The Number console application
    } 
}
