//Name: River Martinez
//Assignment: Homework 8
//Due: December 4, 2020
//rwm5661.psu.edu

package defaultpackage;

import javax.swing.*;

//Class name: GuessTheNumber.java 2.4
//Purpose of class: Executes Guess The Number game

public class GuessTheNumber
{
    private int secretNumber; //class attribute to hold value of secret number
    private int numberGuessed; //class attribute to hold value of number guessed
    private int countGuesses; //class attribute to hold value of number of guesses made
    
    public GuessTheNumber() //GuessTheNumber constructor. USED FOR THE CONSOLE
    {
        numberGuessed = 100; //Initialize number guessed to 100; value represents highest number in the range
        generateSecretNumber(numberGuessed); //Generate secret number
        countGuesses = 0; //Initialize number of guesses to 0; when the game starts, number of guesses is to be 0
    }
    
    public GuessTheNumber(int last) //GuessTheNumber constructor. USED FOR THE GUI
    {
        numberGuessed = last; //Initialize number guessed to 100; value represents highest number in the range
        generateSecretNumber(last); //Generate secret number
        countGuesses = 0; //Initialize number of guesses to 0; when the game starts, number of guesses is to be 0
    }
    
    /**
     * @param display
     * @param guess
     * userRun() enables users to play Guess The Number game. DISPLAYS ON THE GUI
     */
    public void userRun(JTextArea display, int guess)
    {
        if (guess > 0 && guess <= numberGuessed) //if guess is within range
        {
            reportResult(display, guess); //output number guessed
            countGuesses++; //increment number of guesses
            if (guess < secretNumber) //if guess is less than secret number
            {
                display.append("\n   The number is too low. Try again."); //outputs "too low of number" message to display
            }
            else if (guess > secretNumber) //if guess is greater than secret number
            {
                display.append("\n   The number is too high. Try again."); //outputs "too high of number" message to display
            }
            else //if guess equals secret number
            {
                display.append("\n   You guessed the number in " + countGuesses + " tries.\n\n"); //outputs "number of guesses" message to display
                countGuesses = 0; //sets number of guesses back to 0
            }
        }
        else //if guess is outside range
        {
            throw new IllegalArgumentException(); //throw "out of range" exception
        }
    }
    
    /**
     * autoPlay() runs the game until the secret number is guessed correctly. DISPLAYS ON THE CONSOLE
     */
    public void autoPlay()
    {
        int first = 1; //lowest number in the range to be guessed
        int last = numberGuessed; //highest number in the range to be guessed
        System.out.println("Guess a number between " + first + " and " + last + "."); //outputs starting header
        while (numberGuessed != secretNumber) //loop to keep playing the game until the secret number is guessed
        {        
            int mid = (first + last)/2; //average of the the lowest and highest numbers in the range; first number to be guessed
            countGuesses++; //increment number of guesses after a guess is made
            numberGuessed = mid; //number guessed equals value of mid
            reportResult(); //outputs number guessed
            
            //binary search to reach secret number
            if (numberGuessed < secretNumber) //if number guessed is less than secret number, first equals mid + 1 and game continues
            {
                first = mid + 1;
            }
            else if (numberGuessed > secretNumber) //if number guessed is greater than secret number, last equals mid - 1 and game continues
            {
                last = mid - 1;
            }
            else //if number guessed equals secret number, game ends and number of guesses is outputted to the console
            {
                System.out.println("The computer guessed the number in " + countGuesses + " tries."); 
            }
            if (first > last) //if first is greater than last, game ends and error message is displayed to the console
            {
                System.out.println("Time to play Guess The Number! "); 
                System.out.println("Error.");
                break;
            }
        }
    }
    
    /**
     * @param display
     * autoPlay() runs the game until the secret number is guessed correctly. DISPLAYS ON THE GUI
     */
    public void autoPlay(JTextArea display) //autoPlay() takes in JTextArea display as parameter
    {
        int first = 1; //lowest number in the range to be guessed
        int last = numberGuessed; //highest number in the range to be guessed
        display.append("Guess a number between " + first + " and " + last + "."); //outputs starting header to JTextArea display
        while (numberGuessed != secretNumber) //loop to keep playing the game until the secret number is guessed
        {        
            int mid = (first + last)/2; //average of the the lowest and highest numbers in the range; first number to be guessed
            countGuesses++; //increment number of guesses after a guess is made
            numberGuessed = mid; //number guessed equals value of mid
            reportResult(display); //output number guessed to JTextArea display
            
            //binary search to reach secret number
            if (numberGuessed < secretNumber) //if number guessed is less than secret number, first equals mid + 1 and game continues
            {
                first = mid + 1;
            }
            else if (numberGuessed > secretNumber) //if number guessed is greater than secret number, last equals mid - 1 and game continues
            {
                last = mid - 1;
            }
            else //if number guessed equals secret number, game ends and number of guesses is outputted to the JTextField outputField
            {
                display.append("\nThe computer guessed the number in " + countGuesses + " tries.\n\n");
            }
            if (first > last) //if first is greater than last, game ends and error message is displayed to the JTextArea display
            {
                display.append("\nTime to play Guess The Number! "); 
                display.append("\nError."); 
            }
        }
    }
    
    /**
     * reportResult() outputs game data related to the number guessed. DISPLAYS ON THE CONSOLE
     */
    public void reportResult(){System.out.println("Number guessed: " + numberGuessed);}
    
    /**
     * @param display
     * reportResult() outputs game data related to the number guessed. DISPLAYS ON THE GUI
     */
    public void reportResult(JTextArea display){display.append("\nNumber guessed: " + numberGuessed);}
    
    /**
     * @param display
     * @param guess
     * reportResult() outputs game data related to the number guessed. DISPLAYS ON THE GUI
     */
    public void reportResult(JTextArea display, int guess){display.append("\nNumber guessed: " + guess);}
    
    /**
     * 
     * @param last
     * @return randomly generated secret number
     */
    private int generateSecretNumber(int last){return secretNumber = (int) Math.floor(Math.random() * last) + 1;}
    
    /**
     * @return the secretNumber
     */
    public int getSecretNumber(){return secretNumber;}

    /**
     * @param secretNumber the secretNumber to set
     */
    public void setSecretNumber(int secretNumber){this.secretNumber = secretNumber;}

    /**
     * @return the numberGuessed
     */
    public int getNumberGuessed(){return numberGuessed;}

    /**
     * @param numberGuessed the numberGuessed to set
     */
    public void setNumberGuessed(int numberGuessed){this.numberGuessed = numberGuessed;}

    /**
     * @return the countGuesses
     */
    public int getCountGuesses(){return countGuesses;}

    /**
     * @param countGuesses the countGuesses to set
     */
    public void setCountGuesses(int countGuesses){this.countGuesses = countGuesses;}
}