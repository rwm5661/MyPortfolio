//Name: River Martinez
//Assignment: Homework 8
//Due: December 4, 2020
//rwm5661.psu.edu

package defaultpackage;


public class InputGreaterThanMaxIntegerValueException extends Exception
{
    public InputGreaterThanMaxIntegerValueException()
    {
        super("Input is greater than maximum integer value. \nPlease try again.");
    }
}
