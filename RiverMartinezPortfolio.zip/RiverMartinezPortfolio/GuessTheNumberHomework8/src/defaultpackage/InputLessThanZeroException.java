//Name: River Martinez
//Assignment: Homework 8
//Due: December 4, 2020
//rwm5661.psu.edu

package defaultpackage;


public class InputLessThanZeroException extends Exception
{
    public InputLessThanZeroException()
    {
        super("Input cannot be less than or equal to 0. \nPlease try again.");
    }
}
