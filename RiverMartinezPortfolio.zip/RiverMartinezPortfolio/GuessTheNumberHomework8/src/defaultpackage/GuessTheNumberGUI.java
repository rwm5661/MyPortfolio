//Name: River Martinez
//Assignment: Homework 8
//Due: December 4, 2020
//rwm5661.psu.edu

package defaultpackage;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

//Class name: GuessTheNumberGUI.java 2.4
//Purpose of class: Displays GUI of Guess The Number game

//Guess The Number GUI class inherits JFrame class and implements ActionListener interface
public class GuessTheNumberGUI extends JFrame implements ActionListener, ItemListener 
{
    private Container contentPane; //Container object
    private JPanel northPanel, southPanel, eastPanel; //JPanel objects
    private JTextArea display; //JTextArea object
    private JRadioButton computerPlay, playerPlay; //JButton objects
    private ButtonGroup gameModes; //ButtonGroup object
    private JLabel inputMessage1, inputMessage2; //JLabel objects
    private JTextField inputField1, inputField2; //JTextField objects
    private JScrollPane scrollbar; //JScrollBar object
    private GuessTheNumber game; //Guess The Number game object
    private int buttonFlag, last, guess; //buttonFlag int attribute to determine between computer and player button
    
    public GuessTheNumberGUI() //GuessTheNumberGUI constructor
    {
        buildGUI(); //builds GUI for Guess The Number game
    }
    
    /**
     * method to build GUI for Guess The Number game
     */
    private void buildGUI()
    {
        contentPane = getContentPane(); //Container acts as JFrame
        setTitle("Guess The Number!"); //sets title of JFrame window
        setSize (600, 400); //sets size of JFrame
        setDefaultCloseOperation(EXIT_ON_CLOSE); //sets close operation of JFrame
        buildNorth(); //builds North panel
        buildCenter(); //builds Center panel
        buildEast(); //builds East panel
        buildSouth(); //builds South panel
        setLocation(400,175); //sets location of JFrame on computer's window
        setVisible(true); //makes JFrame appear on screen
    }
    
    /**
     * method to build North panel for Guess The Number GUI
     */
    private void buildNorth()
    {
        northPanel = new JPanel(); //Instantiation of northPanel
        northPanel.setBackground(Color.green); //sets background color of northPanel to green
        
        inputMessage1 = new JLabel("Input the range 1 - "); //Instantiation of inputMessage1
        
        inputField1 = new JTextField(5); //Instantiation of inputField1
        inputField1.setEditable(false); //inputField1 uneditable
        inputField1.setBackground(Color.black); //sets background color of inputField1 to black
        inputField1.setForeground(Color.white); //sets foreground color of inputField1 to white
        inputField1.setCaretColor(Color.white); //sets caret color of inputField1 to white
        inputField1.addActionListener(this); //adds action listener to inputField1
        
            
        northPanel.add(inputMessage1); //adds inputMessage1 to northPanel
        northPanel.add(inputField1); //adds inputField1 to northPanel
        
        contentPane.add(northPanel, "North"); //add northPanel to North container of contentPane
    }
    
    /**
     * method to build Center panel for Guess The Number GUI
     */
    private void buildCenter()
    {
        display = new JTextArea(10,40); //Instantiation of display
        display.setEditable(false); //display uneditable
        display.setBackground(Color.black); //sets background color of display to black
        display.setForeground(Color.white); //sets foreground color of display to white
        
        scrollbar = new JScrollPane(display); //Instantiation of scrollbar with display attached to scrollbar
        scrollbar.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); //vertical scrollbar appears always on display
        scrollbar.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); //horizontal scrollbar never appears on display
        contentPane.add(scrollbar, "Center"); //add scrollbar to Center container of contentPane
    }
    
    /**
     * method to build East panel for Guess The Number GUI
     */
    private void buildEast()
    {
        eastPanel = new JPanel(); //Instantiation of eastPanel
        eastPanel.setBackground(Color.green); //sets background color of eastPanel to green
        GridLayout grid = new GridLayout(2,1,20,20); //Instantiation of grid
        eastPanel.setLayout(grid); //sets layout of eastPanel to grid
        
        computerPlay = new JRadioButton("Let Computer Play"); //Instantiation of computerPlay with label and icon added
        computerPlay.setBackground(Color.black); //sets background color of computerPlay to black
        computerPlay.setForeground(Color.white); //sets foreground color of computerPlay to white
        computerPlay.addItemListener(this); //adds action listener to computerPlays
        
        playerPlay = new JRadioButton("Let Me Play"); //Instantiation of playerPlay with label added
        playerPlay.setBackground(Color.black); //sets background color of playerPlay to white
        playerPlay.setForeground(Color.white); //sets foreground color of playerPlay to white
        playerPlay.addItemListener(this); //adds action listener to playerPlay
        
        gameModes = new ButtonGroup();
        gameModes.add(computerPlay);
        gameModes.add(playerPlay);
        
        eastPanel.add(computerPlay); //adds computerPlay to eastPanel
        eastPanel.add(playerPlay); //adds playerPlay to eastPanel
        
        contentPane.add(eastPanel, "East"); //adds eastPanel to East container of contentPane
    }
    
    /**
     * method to build South panel for Guess The Number GUI
     */
    private void buildSouth()
    {
        southPanel = new JPanel(); //Instantiation of southPanel
        southPanel.setBackground(Color.green); //sets background color of southPanel to green
        
        inputMessage2 = new JLabel("Enter your guess: "); //Instantiation of inputMessage1
        
        inputField2 = new JTextField(5); //Instantiation of inputField2
        inputField2.setEditable(false); //inputField2 unedittable
        inputField2.setBackground(Color.black); //sets background color of inputField2 to black
        inputField2.setForeground(Color.white); //sets foreground color of inputField2 to white
        inputField1.setCaretColor(Color.white); //sets caret color of inputField2 to white
        inputField2.addActionListener(this); //adds action listener to inputField2
        
        southPanel.add(inputMessage2); //adds inputMessage1 to southPanel
        southPanel.add(inputField2); //adds inputField2 to southPanel
        
        contentPane.add(southPanel, "South");//adds southPanel to South container of contentPane
    }
    
    /**
     * method to...
     * 1. enable both Computer Plays and Player plays button
     * 2. disable editing of inputField1
     * ...after an action is invoked on inputField1
     */
    private void resetButtonComponents()
    {
        display.setText("");
        inputField1.setEditable(false); //inputField1 uneditable
        computerPlay.setEnabled(true); //enables computerPlay button
        playerPlay.setEnabled(true); //enables playerPlay button
    }
    
    /**
     * method for inputField1 to...
     * 1. enable editing
     * 2. clear text
     * 3. request focus
     * ...when guess does not equal secret number
     */
    private void resetInputField1()
    {
        inputField1.setEditable(true); //inputField2 editable
        inputField1.setText(""); //clears input for inputField2
        inputField1.requestFocus(); //focus input on inputField2
    }
    
    /**
     * method for inputField2 to...
     * 1. enable editing
     * 2. clear text
     * 3. request focus
     * ...when guess does not equal secret number
     */
    private void resetInputField2()
    {
        inputField2.setEditable(true); //inputField2 editable
        inputField2.setText(""); //clears input for inputField2
        inputField2.requestFocus(); //focus input on inputField2
    }
 
    @Override
    public void itemStateChanged(ItemEvent e) 
    {
        if (e.getSource() == computerPlay) //if action is invoked on Computer Plays button
        {
            resetInputField1();
            inputField2.setEditable(false); //inputField2 uneditable
            buttonFlag = 0; //flag value of 0 to represent Computer Plays mode
        }
        
        if (e.getSource() == playerPlay) //if action is invoked on Player Plays button
        {
            resetInputField1();
            inputField2.setEditable(false); //inputField2 uneditable
            buttonFlag = 1; //flag value of 1 to represent Player Plays mode
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) //abstract method actionPerformed()
    {   
        if (e.getSource() == inputField1) //if action is invoked on inputField1 JTextField
        {
            if (buttonFlag == 0) //if computerPlay button is clicked
            {
                try //tests inputField for errors
                {
                    resetButtonComponents(); //resets buttons and disables inputField1
                    last = Integer.parseInt(inputField1.getText()); //converts input range from String to int
                    if (last <= 0) {throw new InputLessThanZeroException();} //if last <= 0, throws exception for negative values
                    if (last > 2147483647){throw new InputGreaterThanMaxIntegerValueException();}
                    game = new GuessTheNumber(last); //Instantiates Guess The Number game object passing an integer to the second constructor
                    game.autoPlay(display); //runs Guess The Number GUI application
                }
                catch (NumberFormatException nf) //NumberFormatException to catch non-integer inputs including null inputs
                {
                    JOptionPane.showMessageDialog(this, "Input is not an integer. \nPlease try again.",
                    "Invalid Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for non-negative integers (Strings)
                    resetInputField1();
                }
                catch (InputLessThanZeroException iltz) //InputLessThanZeroException to catch negative integers and zero inputs
                {
                    JOptionPane.showMessageDialog(this, iltz.getMessage(), "Invalid Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for negative integers or zero
                    resetInputField1();
                }
                catch (InputGreaterThanMaxIntegerValueException igtmiv) //InputGreaterThanMaxIntegerValueException to catch integers outside the max integer range
                {
                    JOptionPane.showMessageDialog(this, igtmiv.getMessage(), "Invalid Guess Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for integers outside the range
                    resetInputField2();
                }
            }
            if (buttonFlag == 1) //if playerPlay button is clicked
            {
                try //tests inputField for errors
                {
                    resetButtonComponents(); //resets buttons and disables inputField1
                    last = Integer.parseInt(inputField1.getText()); //converts input range from String to int
                    if (last <= 0) {throw new InputLessThanZeroException();} //if last <= 0, throws exception for negative values
                    if (last > 2147483647){throw new InputGreaterThanMaxIntegerValueException();}
                    game = new GuessTheNumber(last); //Instantiates Guess The Number game object passing an integer to the second constructor
                    display.append("Guess the secret number between 1 and " + last); //header for Player Plays mode
                    display.append("\n<<<<Enter Guess Below>>>>"); //header for Player Plays mode
                    resetInputField2();
                }
                catch (NumberFormatException nf) //NumberFormatException to catch non-integer inputs including null inputs
                {
                    JOptionPane.showMessageDialog(this, "Input is not an integer. \nPlease try again.",
                    "Invalid Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for non-negative integers (Strings)
                    resetInputField1();
                }
                catch (InputLessThanZeroException iltz) //InputLessThanZeroException to catch negative integers and zero inputs
                {
                    JOptionPane.showMessageDialog(this, iltz.getMessage(), "Invalid Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for negative integers or zero
                    resetInputField1();
                }
                catch (InputGreaterThanMaxIntegerValueException igtmiv) //InputGreaterThanMaxIntegerValueException to catch integers outside the max integer range
                {
                    JOptionPane.showMessageDialog(this, igtmiv.getMessage(), "Invalid Guess Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for integers outside the range
                    resetInputField2();
                }
            }
        }
        
        if (e.getSource() == inputField2) //if action is invoked on inputField2 JTextField
        {
            try //tests inputField2 for errors
            {
                inputField2.setEditable(false); //inputField2 uneditable
                guess = Integer.parseInt(inputField2.getText()); //converts text of inputField2 from String to Integer
                if (guess <= 0){throw new InputLessThanZeroException();}
                if (guess > last){throw new GuessGreaterThanRangeValueException();}
                if (guess > 2147483647){throw new InputGreaterThanMaxIntegerValueException();}
                game.userRun(display, guess); //calls userRun() to allow users to play Guess The Number game
                if (guess != game.getSecretNumber()) //if guess does not equal secret number allow for re-input
                {
                    resetInputField2();
                }
            }
            catch (NumberFormatException nf) //NumberFormatException to catch non-integer inputs
            {
                JOptionPane.showMessageDialog(this, "Guess is not an integer. Try again.",
                "Invalid Guess Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for non-negative integers (Strings)
                resetInputField2();
            }
            catch (InputLessThanZeroException iltz) //InputLessThanZeroException to catch guesses less than lowest range value
            {
                JOptionPane.showMessageDialog(this, iltz.getMessage(), "Invalid Guess Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for integers outside the range
                resetInputField2();
            }
            catch (GuessGreaterThanRangeValueException ggtrv) //GuessGreaterThanRangeValueException to catch guesses greater than highest range value
            {
                JOptionPane.showMessageDialog(this, ggtrv.getMessage(), "Invalid Guess Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for integers outside the range
                resetInputField2();
            }
            catch (InputGreaterThanMaxIntegerValueException igtmiv) //InputGreaterThanMaxIntegerValueException to catch guesses outside the max integer range
            {
                JOptionPane.showMessageDialog(this, igtmiv.getMessage(), "Invalid Guess Input", JOptionPane.ERROR_MESSAGE); //Display JOptionPane for integers outside the range
                resetInputField2();
            }
        }
    }
    
    /** 
     * @return the contentPane
     */
    public Container getcontentPane() {return contentPane;}

    /**
     * @param contentPane the contentPane to set
     */
    public void setContentPane1(Container contentPane) {this.contentPane = contentPane;}
    /** 
     * @return the northPanel
     */
    public JPanel getNorthPanel() {return northPanel;}

    /**
     * @param northPanel the northPanel to set
     */
    public void setNorthPanel(JPanel northPanel) {this.northPanel = northPanel;}

    /**
     * @return the southPanel
     */
    public JPanel getSouthPanel() {return southPanel;}

    /**
     * @param southPanel the southPanel to set
     */
    public void setSouthPanel(JPanel southPanel) {this.southPanel = southPanel;}

    /**
     * @return the eastPanel
     */
    public JPanel getEastPanel() {return eastPanel;}

    /**
     * @param eastPanel the eastPanel to set
     */
    public void setEastPanel(JPanel eastPanel) {this.eastPanel = eastPanel;}
    
    /**
     * @return the display
     */
    public JTextArea getDisplay() {return display;}

    /**
     * @param display the display to set
     */
    public void setDisplay(JTextArea display) {this.display = display;}

    /**
     * @return the computerPlay
     */
    public JRadioButton getComputerPlay() {return computerPlay;}

    /**
     * @param computerPlay the computerPlay to set
     */
    public void setComputerPlay(JRadioButton computerPlay) {this.computerPlay = computerPlay;}
    
    /**
     * @return the playerPlay
     */
    public JRadioButton getPlayerPlay() {return playerPlay;}

    /**
     * @param playerPlay the playerPlay to set
     */
    public void setPlayerPlay(JRadioButton playerPlay) {this.playerPlay = playerPlay;}
    
    /**
     * @return the inputMessage1
     */
    public JLabel getInputMessage1() {return inputMessage1;}

    /**
     * @param inputMessage1 the inputMessage1 to set
     */
    public void setInputMessage1(JLabel inputMessage1) {this.inputMessage1 = inputMessage1;}

    /**
     * @return the inputMessage2
     */
    public JLabel getInputMessage2() {return inputMessage2;}

    /**
     * @param inputMessage2 the inputMessage2 to set
     */
    public void setInputMessage2(JLabel inputMessage2) {this.inputMessage2 = inputMessage2;}

    /**
     * @return the inputField1
     */
    public JTextField getInputField1() {return inputField1;}

    /**
     * @param inputField1 the inputField1 to set
     */
    public void setInputField1(JTextField inputField1) {this.inputField1 = inputField1;}

    /**
     * @return the inputField2
     */
    public JTextField getInputField2() {return inputField2;}

    /**
     * @param inputField2 the inputField2 to set
     */
    public void setInputField2(JTextField inputField2) {this.inputField2 = inputField2;}

    /**
     * @return the scrollbar
     */
    public JScrollPane getScrollPane() {return scrollbar;}

    /**
     * @param scrollbar the scrollbar to set
     */
    public void setScrollPane(JScrollPane scrollbar) {this.scrollbar = scrollbar;}

    /**
     * @return the game
     */
    public GuessTheNumber getGame() {return game;}

    /**
     * @param game the game to set
     */
    public void setGame(GuessTheNumber game) {this.game = game;}
    
    /**
     * @return the buttonFlag
     */
    public int getButtonFlag() {return buttonFlag;}

    /**
     * @param buttonFlag the buttonFlag to set
     */
    public void setButtonFlag(int buttonFlag) {this.buttonFlag = buttonFlag;}
}
