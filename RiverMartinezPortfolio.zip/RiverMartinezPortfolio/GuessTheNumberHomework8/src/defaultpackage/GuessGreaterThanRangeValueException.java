//Name: River Martinez
//Assignment: Homework 8
//Due: December 4, 2020
//rwm5661.psu.edu

package defaultpackage;


public class GuessGreaterThanRangeValueException extends Exception
{
    public GuessGreaterThanRangeValueException()
    {
        super("Guess is greater than last number in the range. \nPlease try again.");
    }
}
