package model;

import java.io.Serializable;

/**  
 * IST 411-001 - MVC Lab
 * PurchaseDetails.java  
 * Purpose: Stores information data from /selection.html form into a PurchaseDetails Java Bean
 *  
 * @author River Martinez  
 * @version 1.0 3/24/2021  
 */
public class PurchaseDetails implements Serializable{
    
    public String product1;             //Product 1 Name
    public String product2;             //Product 2 Name
    public String product3;             //Product 3 Name
    public String product1Price;        //Product 1 Price
    public String product2Price;        //Product 2 Price
    public String product3Price;        //Product 3 Price
    public String subTotal;             //Order Subtotal
    public String taxRate;              //Order Tax rate
    public String shippingRate;         //Order Shipping Rate
    public String total;                //Order Total
    public String firstName;            //Buyer First Name
    public String lastName;             //Buyer Last Name
    public String address;              //Buyer Address
    public String city;                 //Buyer City
    public String state;                //Buyer State
    public String zip;                  //Buyer ZIP Code
    public String country;              //Buyer Country
    public String cardNum;              //Buyer Card Number
    public String expDate;              //Buyer Card Expiration Date
    public String secCode;              //Buyer Card Security Code
    
    /**
     * Zero argument constructor
     */
    public PurchaseDetails () {
        product1 = null;
        product2 = null;
        product3 = null;
        product1Price = "";
        product2Price = "";
        product3Price = "";
        subTotal = "";
        taxRate = "";
        shippingRate = "";
        total = "";
        firstName = "";
        lastName = "";
        address = "";
        city = "";
        state = "";
        zip = "";
        country = "";
        cardNum = "";
        expDate = "";
        secCode = "";
    }

    /**
     * @return the product1
     */
    public String getProduct1() {
        return product1;
    }

    /**
     * @param product1 the product1 to set
     */
    public void setProduct1(String product1) {
        this.product1 = product1;
    }

    /**
     * @return the product2
     */
    public String getProduct2() {
        return product2;
    }

    /**
     * @param product2 the product2 to set
     */
    public void setProduct2(String product2) {
        this.product2 = product2;
    }

    /**
     * @return the product3
     */
    public String getProduct3() {
        return product3;
    }

    /**
     * @param product3 the product3 to set
     */
    public void setProduct3(String product3) {
        this.product3 = product3;
    }

    /**
     * @return the product1Price
     */
    public String getProduct1Price() {
        return product1Price;
    }

    /**
     * @param product1Price the product1Price to set
     */
    public void setProduct1Price(String product1Price) {
        this.product1Price = product1Price;
    }

    /**
     * @return the product2Price
     */
    public String getProduct2Price() {
        return product2Price;
    }

    /**
     * @param product2Price the product2Price to set
     */
    public void setProduct2Price(String product2Price) {
        this.product2Price = product2Price;
    }

    /**
     * @return the product3Price
     */
    public String getProduct3Price() {
        return product3Price;
    }

    /**
     * @param product3Price the product3Price to set
     */
    public void setProduct3Price(String product3Price) {
        this.product3Price = product3Price;
    }

    /**
     * @return the subTotal
     */
    public String getSubTotal() {
        return subTotal;
    }

    /**
     * @param subTotal the subTotal to set
     */
    public void setSubTotal(String subTotal) {
        this.subTotal = subTotal;
    }

    /**
     * @return the taxRate
     */
    public String getTaxRate() {
        return taxRate;
    }

    /**
     * @param taxRate the taxRate to set
     */
    public void setTaxRate(String taxRate) {
        this.taxRate = taxRate;
    }

    /**
     * @return the shippingRate
     */
    public String getShippingRate() {
        return shippingRate;
    }

    /**
     * @param shippingRate the shippingRate to set
     */
    public void setShippingRate(String shippingRate) {
        this.shippingRate = shippingRate;
    }

    /**
     * @return the total
     */
    public String getTotal() {
        return total;
    }

    /**
     * @param total the total to set
     */
    public void setTotal(String total) {
        this.total = total;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * @param state the state to set
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * @return the zip
     */
    public String getZip() {
        return zip;
    }

    /**
     * @param zip the zip to set
     */
    public void setZip(String zip) {
        this.zip = zip;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the cardNum
     */
    public String getCardNum() {
        return cardNum;
    }

    /**
     * @param cardNum the cardNum to set
     */
    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }

    /**
     * @return the expDate
     */
    public String getExpDate() {
        return expDate;
    }

    /**
     * @param expDate the expDate to set
     */
    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    /**
     * @return the secCode
     */
    public String getSecCode() {
        return secCode;
    }

    /**
     * @param secCode the secCode to set
     */
    public void setSecCode(String secCode) {
        this.secCode = secCode;
    }
    
}
