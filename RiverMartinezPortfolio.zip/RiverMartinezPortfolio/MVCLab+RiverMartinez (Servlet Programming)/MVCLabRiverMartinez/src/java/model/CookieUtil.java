/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.servlet.http.Cookie;

/**  
 * IST 411-001 - MVC Lab
 * CookieUtil.java  
 * Purpose: returns the cookie value stored in a cookie
 *  
 * @author Bill Cantor - From PowerPoint slides  
 * @version 1.0 4/3/2021  
 */
public class CookieUtil {
    public static String getCookieValue(Cookie[] cookies, String cookieName) {
        
        String cookieValue = "";
        if (cookies != null) {
            for (Cookie cookie: cookies) {
                if (cookieName.equals(cookie.getName())) {
                    cookieValue = cookie.getValue(); //Retrieves cookie value
                }
            }
        }
        return cookieValue;
    }
}
