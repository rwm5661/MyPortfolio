package model;

import java.text.DecimalFormat;

/**  
 * IST 411-001 - MVC Lab
 * PurchaseCalculator.java  
 * Purpose: Performs Sub-Total, Tax, Shipping, and Total Calculations
 *  
 * @author River Martinez  
 * @version 1.0 3/24/2021  
 */
public class PurchaseCalculator {
    
    private static DecimalFormat df = new DecimalFormat("0.00"); //DecimalFormat object
    
    /**
     * Calculates the sub-total for the purchase order
     * 
     * @param p1Price
     * @param p2Price
     * @param p3Price
     * @return 
     */
    public static String calculateSubTotal(String p1Price, String p2Price, String p3Price) {
        double subTotal = 0.0;
        
        //if condition to set Product prices to zero if they are unselected
        if (p1Price == "") {
            p1Price = "0.0";
        }
        if (p2Price == "") {
            p2Price = "0.0";
        }
        if (p3Price == "") {
            p3Price = "0.0";
        }
        
        //Double parsing
        double p1P = Double.parseDouble(p1Price);
        double p2P = Double.parseDouble(p2Price);
        double p3P = Double.parseDouble(p3Price);
        
        subTotal = p1P + p2P + p3P;
        
        return String.valueOf(df.format(subTotal));
    }
    
    /**
     * Calculates the tax rate for the purchase order
     * 
     * @param subTotal
     * @return 
     */
    public static String calculateTax(String subTotal){
        double tax = 0.0;
        double taxRate = 0.06;
        
        //Double parsing
        double sT = Double.parseDouble(subTotal);
        
        tax = sT * taxRate;
        
        return String.valueOf(df.format(tax));
    }
    
    /**
     * Calculates the shipping rate for the purchase order
     * 
     * @param subTotal
     * @return 
     */
    public static String calculateShipping(String subTotal){
        double shipping = 0.0;
        double shippingRate = 0.10;
        
        //Double parsing
        double sT = Double.parseDouble(subTotal);
        
        shipping = sT * shippingRate;
        
        return String.valueOf(df.format(shipping));
    }
    
    /**
     * Calculates the total for the purchase order
     * @param subTotal
     * @param taxRate
     * @param shippingRate
     * @return 
     */
    public static String calculateTotal(String subTotal, String taxRate, String shippingRate) {
        double total = 0.0;
        
        //Double parsing
        double sT = Double.parseDouble(subTotal);
        double tax = Double.parseDouble(taxRate);
        double shipping = Double.parseDouble(shippingRate);
        
        total = sT + tax + shipping;
      
        return String.valueOf(df.format(total));
    }
}
