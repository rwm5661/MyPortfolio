/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**  
 * IST 411-001 - MVC Lab
 * User.java  
 * Purpose: Stores information data from /login.jsp form into a User Java Bean
 *  
 * @author River Martinez  
 * @version 1.0 4/3/2021  
 */
public class User implements Serializable{
    
    private String emailAddress;
    private String password;
    
    public User() {
        this.emailAddress = "";
        this.password = "";
    }
    
    public User(String e, String p) {
        this.emailAddress = e;
        this.password = p;
    }

    /**
     * @return the emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * @param emailAddress the emailAddress to set
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
