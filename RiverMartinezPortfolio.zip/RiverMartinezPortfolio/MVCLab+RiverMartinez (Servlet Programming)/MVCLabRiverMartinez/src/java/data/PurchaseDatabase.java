package data;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.PurchaseDetails;

/**  
 * IST 411-001 - MVC Lab
 * PurchaseDatabase.java  
 * Purpose: Stores PurchaseDetail object data into PurchaseDetails table
 *  
 * @author River Martinez  
 * @version 1.0 3/24/2021  
 */
public class PurchaseDatabase {
    
    /**
     * Inserts PurchaseDetail object data into PurchaseDetails table
     * 
     * @param pDetails 
     */
    public static void insertPurchaseDetails(PurchaseDetails pDetails) {
        String driver = "org.apache.derby.jdbc.ClientDriver"; //Driver
        String url = "jdbc:derby://localhost:1527/MVCLab";    //URL
        String username = "app";                              //Username
        String password = "app";                              //Password
        
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PurchaseDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            Connection con = DriverManager.getConnection(url, username, password);
            Statement stmt = con.createStatement();
            
            //Creates PurchaseDetails table in MVCLab database
            //stmt.execute("CREATE TABLE PurchaseDetails" + 
            //             "(FirstName varchar(100)," +
            //             "LastName varchar(100)," +
            //             "Address varchar(250)," +
            //             "City varchar(100)," +
            //             "State varchar(100)," +
            //             "ZIPCode varchar(11)," +
            //             "Country varchar(100)," +
            //             "CardNumber varchar(19)," +
            //             "ExpirationDate varchar(5)," +
            //             "CVV_CVC varchar(4)," + 
            //             "Purchase varchar(100)," +
            //             "Total varchar(50))");
            
            //Creates Users table in MVCLab database
            //stmt.execute("CREATE TABLE Users" + 
            //             "(EmailAddress varchar(250)," +
            //             "Password varchar(100)," +
            //             "Primary Key (EmailAddress))");
            
            //Inserts a row of credentials into Users table
            //stmt.execute("INSERT INTO Users(EmailAddress, Password) VALUES('rwm5661@psu.edu','psu2021')");
            
            //Inserts a row of data into PurchaseDetails table, if Product 1 was selected
            if (pDetails.getProduct1() != null) {
                stmt.execute("INSERT INTO PurchaseDetails(FirstName, LastName, "
                                    + "Address, City, State, ZIPCode, Country, "
                                       + "CardNumber, ExpirationDate, CVV_CVC, "
                                                            + "Purchase, Total)"
                            +"VALUES('" +
                                    pDetails.getFirstName() + "','" + pDetails.getLastName() + "','" +
                                    pDetails.getAddress() + "','" + pDetails.getCity() + "','" + pDetails.getState() + "','" + pDetails.getZip() + "','" + pDetails.getCountry() + "','" +
                                    pDetails.getCardNum() + "','" + pDetails.getExpDate() + "','" + pDetails.getSecCode() + "','" +
                                    pDetails.getProduct1() + "','$" + pDetails.getProduct1Price() + "')");
            }
            //Inserts a row of data into PurchaseDetails table, if Product 2 was selected
            if (pDetails.getProduct2() != null) {
                stmt.execute("INSERT INTO PurchaseDetails(FirstName, LastName, "
                                    + "Address, City, State, ZIPCode, Country, "
                                       + "CardNumber, ExpirationDate, CVV_CVC, "
                                                            + "Purchase, Total)"
                            +"VALUES('" +
                                    pDetails.getFirstName() + "','" + pDetails.getLastName() + "','" +
                                    pDetails.getAddress() + "','" + pDetails.getCity() + "','" + pDetails.getState() + "','" + pDetails.getZip() + "','" + pDetails.getCountry() + "','" +
                                    pDetails.getCardNum() + "','" + pDetails.getExpDate() + "','" + pDetails.getSecCode() + "','" +
                                    pDetails.getProduct2() + "','$" + pDetails.getProduct2Price() + "')");
            }
            //Inserts a row of data into PurchaseDetails table, if Product 3 was selected
            if (pDetails.getProduct3() != null) {
                stmt.execute("INSERT INTO PurchaseDetails(FirstName, LastName, "
                                    + "Address, City, State, ZIPCode, Country, "
                                       + "CardNumber, ExpirationDate, CVV_CVC, "
                                                            + "Purchase, Total)"
                            +"VALUES('" +
                                    pDetails.getFirstName() + "','" + pDetails.getLastName() + "','" +
                                    pDetails.getAddress() + "','" + pDetails.getCity() + "','" + pDetails.getState() + "','" + pDetails.getZip() + "','" + pDetails.getCountry() + "','" +
                                    pDetails.getCardNum() + "','" + pDetails.getExpDate() + "','" + pDetails.getSecCode() + "','" +
                                    pDetails.getProduct3() + "','$" + pDetails.getProduct3Price() + "')");
            }
            stmt.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
