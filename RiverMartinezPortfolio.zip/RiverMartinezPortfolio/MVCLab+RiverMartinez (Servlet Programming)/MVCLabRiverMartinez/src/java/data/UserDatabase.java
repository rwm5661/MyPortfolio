package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.User;

/**  
 * IST 411-001 - MVC Lab
 * UserDatabase.java  
 * Purpose: Verifies login credentials from the database with entered data on the login page
 *  
 * @author River Martinez  
 * @version 1.0 4/3/2021  
 */
public class UserDatabase {
    
    /**
     * Retrieves login credentials from the Users table 
     * and verifies whether the credentials matches what 
     * the user entered on the login page; returns a boolean value.
     * 
     * @param user
     * @return 
     */
    public static boolean checkCredentials(User user) {
        
        String driver = "org.apache.derby.jdbc.ClientDriver"; //Driver
        String url = "jdbc:derby://localhost:1527/MVCLab";    //URL
        String username = "app";                              //Username
        String password = "app";                              //Password
        
        String emailAddress = "";
        String userPassword = "";
        boolean isVerified = false;
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PurchaseDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            Connection con = DriverManager.getConnection(url, username, password);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT EmailAddress, Password FROM Users WHERE EmailAddress = 'rwm5661@psu.edu' AND Password = 'psu2021'");
            
            while(rs.next()){
                emailAddress = rs.getString("EmailAddress"); //Retrieves emailAddress
                userPassword = rs.getString("Password"); //Retrieves password
            }
            stmt.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(PurchaseDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        //If credentials do not match, return false
        if (!user.getEmailAddress().equals(emailAddress) && !user.getPassword().equals(userPassword)){
            isVerified = false;
        
        //If credentials do match, return true
        } else if (user.getEmailAddress().equals(emailAddress) && user.getPassword().equals(userPassword)){
            isVerified = true;
        }
        System.out.println(isVerified);
        return isVerified;
    }
}
