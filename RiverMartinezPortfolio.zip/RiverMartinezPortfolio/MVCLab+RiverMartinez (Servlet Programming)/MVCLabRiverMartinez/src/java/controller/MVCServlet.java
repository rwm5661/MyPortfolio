package controller;

import data.PurchaseDatabase;
import data.UserDatabase;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import model.CookieUtil;
import model.PurchaseCalculator;
import model.PurchaseDetails;
import model.User;

/**  
 * IST 411-001 - MVC Lab
 * MVCServlet.java  
 * Purpose: Acts as Controller for the web application; switches between "Purchase" and "Receipt" pages
 *  
 * @author River Martinez  
 * @version 1.0 3/24/2021  
 */
public class MVCServlet extends HttpServlet{
    
    /**
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {

        String url = "/selection.html"; //"Purchase" page

        //get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "purchase";  //default action
        }

        //perform action and set URL to appropriate page
        if (action.equals("purchase")) { //if purchase button was clicked on receipt page, return to purchase page
            url = "/selection.html";
        } else if (action.equals("checkUser")) { //if login button was clicked on login page, verify a session cookie
            url = checkForLoginSession(request, response);
        } else if (action.equals("receipt")) { //if receipt button was clicked on purchase page, create a session
            url = verifyCredentials(request, response);
        }
        
        //forward request and response objects to specified URL
        getServletContext().getRequestDispatcher(url).forward(request,response);
    }    
    
    /**
     * Creates cart (PurchaseDetails) cookie. 
     * 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void createCartCookie(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        //Get product and customer information from HttpServletRequest object
        String product1 = request.getParameter("product1");
        String product2 = request.getParameter("product2");
        String product3 = request.getParameter("product3");
        System.out.println(product1);
        System.out.println(product2);
        System.out.println(product3);
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String zip = request.getParameter("zip");
        String country = request.getParameter("country");
        String cardNum = request.getParameter("cardNum");
        String expDate = request.getParameter("expDate");
        String secCode = request.getParameter("secCode");
            
        //Store data in PurchaseDetails object
        PurchaseDetails pDetails = new PurchaseDetails();
        if (product1 != null) {
            pDetails.setProduct1("Pink Soap");
            pDetails.setProduct1Price("4.50");
        }
        if (product2 != null) {
            pDetails.setProduct2("Precision Cut Razor");
            pDetails.setProduct2Price("9.75");
        }
        if (product3 != null) {
            pDetails.setProduct3("Gray Towel");
            pDetails.setProduct3Price("14.25");
        }
        pDetails.setSubTotal(PurchaseCalculator.calculateSubTotal(pDetails.getProduct1Price(), 
                                                                  pDetails.getProduct2Price(), 
                                                                  pDetails.getProduct3Price()));
        pDetails.setTaxRate(PurchaseCalculator.calculateTax(pDetails.getSubTotal()));
        pDetails.setShippingRate(PurchaseCalculator.calculateShipping(pDetails.getSubTotal()));
        pDetails.setTotal(PurchaseCalculator.calculateTotal(pDetails.getSubTotal(),
                                                            pDetails.getTaxRate(),
                                                            pDetails.getShippingRate()));
        pDetails.setFirstName(firstName);
        pDetails.setLastName(lastName);
        pDetails.setAddress(street);
        pDetails.setCity(city);
        pDetails.setState(state);
        pDetails.setZip(zip);
        pDetails.setCountry(country);
        pDetails.setCardNum(cardNum);
        pDetails.setExpDate(expDate);
        pDetails.setSecCode(secCode);
        
        //Store cart in session cookie
        HttpSession cart = request.getSession();
        cart.setMaxInactiveInterval(-1);
        cart.setAttribute("cart", pDetails);
    }
    /**
     * Verifies whether a session cookie is present.If there a session cookie is present, process order.
     * If not, go to login page to create a session cookie.
 This method also gets HttpServletRequest parameters from "Purchases"
 page and stores it in a cookie
     * 
     * @param request
     * @param response
     * @return 
     * @throws ServletException
     * @throws IOException
     */
    protected String checkForLoginSession(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        String url = "/login.jsp";
        
        createCartCookie(request,response);
        
        //Get cart cookie value from HttpServletRequest object
        Cookie[] cookies = request.getCookies();
        String email = CookieUtil.getCookieValue(cookies,"email");
        
        //If secondary login session cookie does not exist, send user to "Login" page
        if (email == null || email.equals("")){
            //Send user to "Login" page
            url = "/login.jsp";
            
        //If secondary login session cookie exists, send user to "Receipt" page
        } else {
            //Send user to "Receipt" page
            url = processOrder(request, response);
        }
        return url;
    }
    
    /**
     * Creates login (User) session cookie and returns User object.
     * 
     * @param request
     * @param response
     * @return 
     * @throws ServletException
     * @throws IOException
     */
    protected User createLoginSession(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        //Get login credentials from HttpServletRequest object
        String emailAddress = request.getParameter("emailAddress");
        String password = request.getParameter("password");
        
        //Store data in User object
        User user = new User(emailAddress, password);
        
        //Creates email session cookie
        Cookie email = new Cookie("email", user.getEmailAddress());
        email.setMaxAge(-1);
        email.setPath("/");
        response.addCookie(email);
        
        //Creates password session cookie
        Cookie pass = new Cookie("pass", user.getPassword());
        pass.setMaxAge(-1);
        pass.setPath("/");
        response.addCookie(pass);
        
        return user;
    }
    
    /**
     * Creates a session cookie and verifies login credentials.If credentials match, create session cookie and process order.
     * If not, return to login page.
     * 
     * @param request
     * @param response
     * @return 
     * @throws ServletException
     * @throws IOException
     */
    protected String verifyCredentials(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        //sets URL
        String url = "/login.jsp";
        
        //Creates login session cookie and returns User object for verification
        User user = createLoginSession(request,response);
        
        //Verfiy credentials
        boolean verify = UserDatabase.checkCredentials(user);
        
        //if login credentials matches database credentials (true), send user to "Receipt" page
        if (verify == true) {           
            //Send user to "Receipt" page
            url = processOrder(request, response);
            
        //if login credentials does not match database credentials (false), send user to "Login" page
        } else {
            //Send user to "Login" page 
            url = "/login.jsp";
        }   
        
        return url;
    }
    
    /**
     * Stores cookie PurchaseDetails object in the database 
     * and sends user to "Receipt" page.
     * 
     * @param request
     * @param response
     * @return 
     * @throws ServletException
     * @throws IOException
     */
    protected String processOrder(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        //Get PurchaseDetails object from cart cookie
        PurchaseDetails pDetails = (PurchaseDetails) request.getSession().getAttribute("cart");
        
        //Store data in local Derby database
        PurchaseDatabase.insertPurchaseDetails(pDetails);    
        
        //Send user to "Receipt" page
        String url = "/orderreceipt.jsp";
            
        return url;
    }
    
    /**
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, 
                          HttpServletResponse response) 
                          throws ServletException, IOException {
        doPost(request, response);
    }
}
