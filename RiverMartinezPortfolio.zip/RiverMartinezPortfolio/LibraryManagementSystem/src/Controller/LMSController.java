/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.LMSModel;
import View.mainclasses.LMSMainFrame;
import View.LMSView;
import View.mainclasses.LMSViewCartFrame;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author River
 */
public class LMSController {

    private LMSModel model;
    private LMSView view;
    
    public LMSController(LMSModel model, LMSView view){
        
        this.model = model;
        this.view = view;
        
        view.getLogin().getSignInButton().addActionListener( //Login Sign in ActionListener
            (ActionEvent e) -> {
                String username = view.getLogin().getUsernameField().getText();
                String password = String.valueOf(view.getLogin().getPasswordField().getPassword());

                try {
                    if(model.getDB().checkForUsername(username)) {
                        if (model.getDB().checkForLoginMatch(username, password)) {
                            view.getLogin().setVisible(false);
                            LMSViewCartFrame cart = new LMSViewCartFrame();
                            LMSMainFrame main = new LMSMainFrame(view.getLogin(), cart);
                        } else {
                            view.getLogin().getLoginMessageLabel().setText("Password is incorrect");
                        }
                    } else {
                        view.getLogin().getLoginMessageLabel().setText("Username does not exist");
                    }
                } catch (SQLException | IOException ex) {
                    Logger.getLogger(LMSController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        );//end SignIn ActionListener for Login
        
        view.getLogin().getUsernameField().addKeyListener(//Login Username KeyListener
            new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent evt) {
                    if ("Username".equals(view.getLogin().getUsernameField().getText())){
                        view.getLogin().getUsernameField().setText("");
                    }
                    if(evt.getKeyCode() == KeyEvent.VK_ENTER) {
                        String username = view.getLogin().getUsernameField().getText();
                        String password = String.valueOf(view.getLogin().getPasswordField().getPassword());

                        try {
                            if(model.getDB().checkForUsername(username)) {
                                if (model.getDB().checkForLoginMatch(username, password)) {
                                    view.getLogin().setVisible(false);
                                    LMSViewCartFrame cart = new LMSViewCartFrame();
                                    LMSMainFrame main = new LMSMainFrame(view.getLogin(), cart);
                                } else {
                                    view.getLogin().getLoginMessageLabel().setText("Password is incorrect");
                                }
                            } else {
                                view.getLogin().getLoginMessageLabel().setText("Username does not exist");
                            }
                        } catch (SQLException | IOException ex) {
                            Logger.getLogger(LMSController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        ); //end Username KeyListener for Login
        
        view.getLogin().getPasswordField().addKeyListener(//Login Username KeyListener
            new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent evt) {
                    if ("Password".equals(String.valueOf(view.getLogin().getPasswordField().getPassword()))){
                        view.getLogin().getPasswordField().setText("");
                        view.getLogin().getPasswordField().setEchoChar((char)0x2022); //this will display '•' for every character in the password
                    }
                    if(evt.getKeyCode() == KeyEvent.VK_ENTER) {
                        String username = view.getLogin().getUsernameField().getText();
                        String password = String.valueOf(view.getLogin().getPasswordField().getPassword());

                        try {
                            if(model.getDB().checkForUsername(username)) {
                                if (model.getDB().checkForLoginMatch(username, password)) {
                                    view.getLogin().setVisible(false);
                                    LMSViewCartFrame cart = new LMSViewCartFrame();
                                    LMSMainFrame main = new LMSMainFrame(view.getLogin(), cart);
                                } else {
                                    view.getLogin().getLoginMessageLabel().setText("Password is incorrect");
                                }
                            } else {
                                view.getLogin().getLoginMessageLabel().setText("Username does not exist");
                            }
                        } catch (SQLException | IOException ex) {
                            Logger.getLogger(LMSController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        ); //end Password KeyListener for Login
        
    } //end LMSController Constructor
    
} //end LMSController Class
