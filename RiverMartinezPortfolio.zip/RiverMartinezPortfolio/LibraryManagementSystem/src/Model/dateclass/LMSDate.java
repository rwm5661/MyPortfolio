/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.dateclass;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author River
 */
public class LMSDate {
    
    public LMSDate(){
        
    }
    
    private static final String DATE_PATTERN =
            "^(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])-((?:19|20)[0-9][0-9])$";

    private final Pattern pattern = Pattern.compile(DATE_PATTERN);

    public boolean isValid(String date) {

        boolean result = false;

        Matcher matcher = pattern.matcher(date);

        if (matcher.matches()) {

            // it is a valid date format mm-dd-yyyy
            // assign true first, later we will check the leap year and odd or even months
            result = true;

            // (?:19|20), match but don't capture it, otherwise it will messy the group order
            // for example, 2020-2-30, it will create 4 groups.
            // group(1) = 02, group(2) = 30, group(3) = 2022, group(4) matches (19|20) = 20
            // So, we put (?:19|20), don't capture this group.

            // why string? month matches 02
            String month = matcher.group(1);
            String day = matcher.group(2);
            int year = Integer.parseInt(matcher.group(3));

            // 30 or 31 days checking
            // only 1,3,5,7,8,10,12 has 31 days
            if ((month.equals("04") || month.equals("06") || month.equals("09")||
                    month.equals("11")) && day.equals("31")) {
                result = false;
            } else if (month.equals("02")) {
                if (day.equals("30") || day.equals("31")) {
                    result = false;
                } else if (day.equals("29")) {  // leap year? feb 29 days.
                    if (!isLeapYear(year)) {
                        result = false;
                    }
                }
            }

        }

        return result;
    }
    
    private static boolean isLeapYear(int year) {
        return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
    }
    
    public String getCurrentDate(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM-dd-YYYY");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }
    
    public String getReturnDate(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM-dd-YYYY");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now.plusDays(10));
    }
    
    public int issueToReturnDateDifference(String issueDate, String returnDate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.ENGLISH);
        Date firstDate = sdf.parse(issueDate);
        Date secondDate = sdf.parse(returnDate);

        long diffInMillies = Math.abs(secondDate.getTime() - firstDate.getTime());
        int diff = (int) TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        
        return diff;
    }
}
