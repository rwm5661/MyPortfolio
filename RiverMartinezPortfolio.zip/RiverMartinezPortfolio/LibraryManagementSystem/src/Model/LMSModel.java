/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Model.databaseclass.LMSDatabase;

/**
 *
 * @author River
 */
public class LMSModel {
   
    private LMSDatabase db;
   
    public LMSModel() {
        db = new LMSDatabase();
    }

    /**
     * @return the db
     */
    public LMSDatabase getDB() {
        return db;
    }
}
