/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.databaseclass;

import Model.dateclass.LMSDate;
import Model.objectclasses.LMSBook;
import Model.objectclasses.LMSCartItem;
import Model.objectclasses.LMSIssue;
import Model.objectclasses.LMSPurchase;
import Model.objectclasses.LMSUser;
import View.mainclasses.LMSBooksToBuyCard;
import View.mainclasses.LMSBooksToRentCard;
import View.mainclasses.LMSProfileCard;
import View.registerclasses.LMSRegisterFrame;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author River
 */
public class LMSDatabase {
    
    /**
     * Purpose: Default constructor for LMSDatabase instances
     */
    public LMSDatabase () {

    }
    
    /**
     * Purpose: Returns a Connection object after connecting to the SQl Server
     * 
     * @return
     */
    private Connection getConnection(){
        Connection con = null;
        
        try {
            con = DriverManager.getConnection("jdbc:sqlserver://RIVER-LAPTOP;databaseName=TestDB;encrypt=true;trustServerCertificate=true;","sa","S5imbsdwi!");
        } catch (SQLException ex) {
            Logger.getLogger(LMSDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return con;
    } //end getConnection()
    
    /**
     * Purpose: Returns credentials related to username and email associated with 
     * LMS account
     * 
     * @param username
     * @param email
     * @return
     * @throws java.sql.SQLException
     */
    public String[] getCredentials(String username, String email) throws SQLException{
        boolean existenceIndicator = checkForUsername(username);
        boolean usernameAndEmailMatchIndicator = checkForUsernameAndEmailMatch(username, email);
        
        String[] credentials = new String[2];
        credentials[0] = username;
        
        if (!existenceIndicator){
            credentials[1] = "";
        } else if (!usernameAndEmailMatchIndicator) {
            credentials[0] = "";
        } else if (existenceIndicator && usernameAndEmailMatchIndicator) {
            Connection con = getConnection(); 
            Statement stmt;
            ResultSet rs;

            stmt = con.createStatement();
            rs = stmt.executeQuery(
                "SELECT Password " +
                "FROM TestDB.dbo.LMSUsers " +
                "WHERE Username = '" + username + "' "
            );

            String password = "";
            while(rs.next()){
                password = rs.getString("Password");
            }

            stmt.close();
            rs.close();
            con.close();

            credentials[1] = password;
        }
       
        return credentials;
    } //end getCredentials()
    
    /**
     * Purpose: Returns a byte array storing user's profile picture
     * 
     * @param username
     * @return
     * @throws java.sql.SQLException
     */
    public byte[] getUserProfilePic(String username) throws SQLException {
        Connection con = getConnection(); 
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT ProfilePicture " +
            "FROM TestDB.dbo.LMSUsers " +
            "WHERE Username = '" + username + "' "
        );
        
        byte[] profilePicImg = null;
        while(rs.next()){
            profilePicImg = rs.getBytes("ProfilePicture");
        }
        
        stmt.close();
        rs.close();
        con.close();
        
        return profilePicImg;
    }
    
    /**
     * Purpose: Returns a LMSUser object instance containing information related
     * to the signed-in user, which will be displayed in the profile page
     * 
     * @param username
     * @return
     * @throws java.sql.SQLException
     */
    public LMSUser getUserProfileInformation(String username) throws SQLException {
        Connection con = getConnection(); 
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT UserID, LibCardNum, Username, Password, ProfilePicture, FirstName, LastName, DateOfBirth, Sex, " +
                   "Ethnicity, PhoneNumber, StreetAddress, City, State, PostalCode, Country, TypeOfUser, Email " +
            "FROM TestDB.dbo.LMSUsers " +
            "WHERE Username = '" + username + "' "
        );
        
        LMSUser user = new LMSUser();
        while(rs.next()){
            user.setUserID(rs.getInt("UserID"));
            user.setLibCardNum(rs.getInt("LibCardNum"));
            user.setUsername(rs.getString("Username"));
            user.setPassword(rs.getString("Password"));
            user.setProfilePic(rs.getBytes("ProfilePicture"));
            user.setFirstName(rs.getString("FirstName"));
            user.setLastName(rs.getString("LastName"));
            user.setDateOfBirth(rs.getString("DateOfBirth"));
            user.setSex(rs.getString("Sex"));
            user.setEthnicity(rs.getString("Ethnicity"));
            user.setPhoneNum(rs.getString("PhoneNumber"));
            user.setStreetAddress(rs.getString("StreetAddress"));
            user.setCity(rs.getString("City"));
            user.setState(rs.getString("State"));
            user.setPostalCode(rs.getString("PostalCode"));
            user.setCountry(rs.getString("Country"));
            user.setTypeOfUser(rs.getString("TypeOfUser"));
            user.setEmail(rs.getString("Email"));
        }
        
        stmt.close();
        rs.close();
        con.close();
        
        return user;
    }
    
    /**
     * Purpose: Returns a list of cart items related to the signed-in user
     * 
     * @param username
     * @return
     * @throws java.sql.SQLException
     */
    public ArrayList<LMSCartItem> getUserCart(String username) throws SQLException {
        Connection con = getConnection();
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT CoverImage, ISBN, Title, ItemQuantity, Price " +
            "FROM TestDB.dbo.LMSCart " +
            "WHERE Username = '" + username + "' "
        );
        
        ArrayList<LMSCartItem> cartItems = new ArrayList<>();
        LMSCartItem cartItem;
        while(rs.next()){
            cartItem = new LMSCartItem(
            rs.getBytes("CoverImage"),
            rs.getString("ISBN"),
            rs.getString("Title"),
            rs.getInt("ItemQuantity"),
            rs.getInt("Price")
            );
            cartItems.add(cartItem);
        }
        
        stmt.close();
        rs.close();
        con.close();
        
        return cartItems;
    }
    
    /**
     * Purpose: Returns the list of books available for purchase
     * 
     * @return
     * @throws java.sql.SQLException
     */
    public ArrayList<LMSBook> getBooksToBuy () throws SQLException {
        Connection con = getConnection();
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT ISBN, CoverImage, Title, Author, YearPublished, Genre, Price " +
            "FROM TestDB.dbo.LMSBooks "
        );
        
        ArrayList<LMSBook> booksToBuy = new ArrayList<>();
        LMSBook book;
        while(rs.next()){
            book = new LMSBook(
            rs.getString("ISBN"),
            rs.getBytes("CoverImage"),
            rs.getString("Title"),
            rs.getString("Author"),
            rs.getString("YearPublished"),
            rs.getString("Genre"),
            rs.getInt("Price")
            );
            booksToBuy.add(book);
        }
        
        stmt.close();
        rs.close();
        con.close();
        
        return booksToBuy;
    }
    
    /**
     * Purpose: Returns the list of books available for rent
     * 
     * @return
     * @throws java.sql.SQLException
     */
    public ArrayList<LMSBook> getBooksToRent () throws SQLException {
        Connection con = getConnection();
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT ISBN, CoverImage, Title, Author, YearPublished, Genre " +
            "FROM TestDB.dbo.LMSBooks ");
        
        ArrayList<LMSBook> booksToRent = new ArrayList<>();
        LMSBook book;
        while(rs.next()){
            book = new LMSBook(
            rs.getString("ISBN"),
            rs.getBytes("CoverImage"),
            rs.getString("Title"),
            rs.getString("Author"),
            rs.getString("YearPublished"),
            rs.getString("Genre")
            );
            booksToRent.add(book);
        }
        
        stmt.close();
        rs.close();
        con.close();
        
        return booksToRent;
    }
    
        /**
     * Purpose: Returns a list of rented books related to the signed-in user
     * 
     * @param username
     * @return
     * @throws java.sql.SQLException
     */
    public ArrayList<LMSIssue> getYourRentals(String username) throws SQLException {
        Connection con = getConnection();
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT UserID " + 
            "FROM TestDB.dbo.LMSUsers " +
            "WHERE Username = '" + username + "' ");
        
        int memberID = 0;
        while (rs.next()) {
            memberID = rs.getInt("UserID");
        }
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT IssueDate, Period, ReturnDate, LateFee, ISBN " +
            "FROM TestDB.dbo.LMSIssues " +
            "WHERE MemberID = '" + memberID + "' " +
            "ORDER BY IssueDate DESC, IssueID DESC "
        );
        
        ArrayList<LMSIssue> yourRentals = new ArrayList<>();
        LMSIssue rental;
        while(rs.next()){
            rental = new LMSIssue(
            rs.getString("IssueDate"),
            rs.getInt("Period"),
            rs.getString("ReturnDate"),
            rs.getInt("LateFee"),
            rs.getString("ISBN"),
            null,
            null
            );
            yourRentals.add(rental);
        }
        
        for (int i = 0; i < yourRentals.size(); i++) {
            stmt = con.createStatement();
            rs = stmt.executeQuery(
                "SELECT Title, CoverImage " +
                "FROM TestDB.dbo.LMSBooks " +
                "WHERE ISBN = '" + yourRentals.get(i).getIsbn() + "' "
            );
            
            while (rs.next()){
                yourRentals.get(i).setBookTitle(rs.getString("Title"));
                yourRentals.get(i).setBookCover(rs.getBytes("CoverImage"));
            }
        }
        
        stmt.close();
        rs.close();
        con.close();
        
        return yourRentals;
    }
    
    /**
     * Purpose: Returns a list of purchased books related to the signed-in user
     * 
     * @param username
     * @return
     * @throws java.sql.SQLException
     */
    public ArrayList<LMSPurchase> getYourPurchases(String username) throws SQLException {
        Connection con = getConnection();
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT UserID " + 
            "FROM TestDB.dbo.LMSUsers " +
            "WHERE Username = '" + username + "' ");
        
        int memberID = 0;
        while (rs.next()) {
            memberID = rs.getInt("UserID");
        }
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT PurchaseDate, ItemQuantity, Price, ISBN " +
            "FROM TestDB.dbo.LMSPurchases " +
            "WHERE MemberID = '" + memberID + "' " +
            "ORDER BY PurchaseDate DESC, PurchaseID DESC "
        );
        
        ArrayList<LMSPurchase> yourPurchases = new ArrayList<>();
        LMSPurchase purchase;
        while(rs.next()){
            purchase = new LMSPurchase(
            rs.getString("PurchaseDate"),
            rs.getInt("ItemQuantity"),
            rs.getInt("Price"),
            rs.getString("ISBN"),
            null,
            null
            );
            yourPurchases.add(purchase);
        }
        
        for (int i = 0; i < yourPurchases.size(); i++) {
            stmt = con.createStatement();
            rs = stmt.executeQuery(
                "SELECT Title, CoverImage " +
                "FROM TestDB.dbo.LMSBooks " +
                "WHERE ISBN = '" + yourPurchases.get(i).getIsbn() + "' "
            );
            
            while (rs.next()){
                yourPurchases.get(i).setBookTitle(rs.getString("Title"));
                yourPurchases.get(i).setBookCover(rs.getBytes("CoverImage"));
            }
        }
        
        stmt.close();
        rs.close();
        con.close();
        
        return yourPurchases;
    }
    
    /**
     * Purpose: Returns a boolean value indicating whether or not the library 
     * card number submitted is in use or not
     * 
     * @param libCardNum
     * @return
     * @throws java.sql.SQLException
     */
    public boolean checkForLibCardNum(String libCardNum) throws SQLException {
        Connection con = getConnection(); 
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT CASE WHEN EXISTS ( " +
                "SELECT * " +
                "FROM TestDB.dbo.LMSUsers " +
                "WHERE LibCardNum = '" + libCardNum + "' " +
            ") " +
            "THEN CAST('YES' AS varchar(3)) " +
            "ELSE CAST('NO' AS varchar(2)) END AS LibCardNumExists"
        );
        
        String doesLibCardNumExist = "";
        while(rs.next()){
            doesLibCardNumExist = rs.getString("LibCardNumExists");
        }
        
        boolean existenceIndicator = false;
        existenceIndicator = "YES".equals(doesLibCardNumExist);
        
        stmt.close();
        rs.close();
        con.close();
        
        return existenceIndicator;
    } //end checkForLibCardNum()

    /**
     * Purpose: Returns a boolean value indicating whether or not the username
     * submitted is in use or not
     * 
     * @param username
     * @return
     * @throws java.sql.SQLException
     */
    public boolean checkForUsername(String username) throws SQLException {
        Connection con = getConnection(); 
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT CASE WHEN EXISTS ( " +
                "SELECT * " +
                "FROM TestDB.dbo.LMSUsers " +
                "WHERE Username = '" + username + "' " +
            ") " +
            "THEN CAST('YES' AS varchar(3)) " +
            "ELSE CAST('NO' AS varchar(2)) END AS UsernameExists"
        );
        
        String doesUsernameExist = "";
        while(rs.next()){
            doesUsernameExist = rs.getString("UsernameExists");
        }
        
        boolean existenceIndicator = false;
        existenceIndicator = "YES".equals(doesUsernameExist);
        
        stmt.close();
        rs.close();
        con.close();
        
        return existenceIndicator;
    } //end checkForUsername()

    /**
     * Purpose: Returns a boolean value indicating whether or not the username
     * and password submitted relate to the same account
     * 
     * @param username
     * @param password
     * @return
     * @throws java.sql.SQLException
     */
    public boolean checkForLoginMatch(String username, String password) throws SQLException {
        Connection con = getConnection(); 
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT CASE WHEN EXISTS ( " +
                "SELECT * " +
                "FROM TestDB.dbo.LMSUsers " +
                "WHERE Username = '" + username + "' AND Password = '" + password + "' " +
            ") " +
            "THEN CAST('YES' AS varchar(3)) " +
            "ELSE CAST('NO' AS varchar(2)) END AS LoginMatch"
        );
        
        String doesLoginMatch = "";
        while(rs.next()){
            doesLoginMatch = rs.getString("LoginMatch");
        }
        
        boolean matchIndicator = false;
        matchIndicator = "YES".equals(doesLoginMatch);
        
        stmt.close();
        rs.close();
        con.close();
        
        return matchIndicator;
    } //end checkForLoginMatch()
    
    /**
     * Purpose: Returns a boolean value indicating whether or not the username
     * submitted holds the title of administrator
     * 
     * @param username
     * @return
     * @throws java.sql.SQLException
     */
    public boolean checkForIsAdmin(String username) throws SQLException {
        Connection con = getConnection(); 
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        
        rs = stmt.executeQuery(
            "SELECT UserID " + 
            "FROM TestDB.dbo.LMSUsers " +
            "WHERE Username = '" + username + "'"
        );
        
        int staffID = 0;
        while(rs.next()){
            staffID = rs.getInt("UserID");
        }
        
        rs = stmt.executeQuery(
            "SELECT CASE WHEN EXISTS ( " +
                "SELECT * " +
                "FROM TestDB.dbo.LMSStaff " +
                "WHERE StaffID = '" + staffID + "' AND IsAdmin = 'Yes'" +
            ") " +
            "THEN CAST('YES' AS varchar(3)) " +
            "ELSE CAST('NO' AS varchar(2)) END AS IsAdmin"
        );
        
        String isAdmin = "";
        while(rs.next()){
            isAdmin = rs.getString("IsAdmin");
        }
        
        boolean isAdminIndicator = false;
        isAdminIndicator = "YES".equals(isAdmin);
        
        stmt.close();
        rs.close();
        con.close();
        
        return isAdminIndicator;
    } //end checkForIsAdmin()
    
    /**
     * Purpose: Returns a boolean value indicating whether or not the username
     * and email submitted relate to the same account
     * 
     * @param username
     * @param email
     * @return 
     * @throws java.sql.SQLException
     */
    public boolean checkForUsernameAndEmailMatch(String username, String email) throws SQLException {
        Connection con = getConnection(); 
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT CASE WHEN EXISTS ( " +
                "SELECT * " +
                "FROM TestDB.dbo.LMSUsers " +
                "WHERE Username = '" + username + "' AND Email = '" + email + "' " +
            ") " +
            "THEN CAST('YES' AS varchar(3)) " +
            "ELSE CAST('NO' AS varchar(2)) END AS LoginMatch"
        );
        
        String doesLoginMatch = "";
        while(rs.next()){
            doesLoginMatch = rs.getString("LoginMatch");
        }
        
        boolean usernameAndEmailMatchIndicator = false;
        usernameAndEmailMatchIndicator = "YES".equals(doesLoginMatch);
        
        stmt.close();
        rs.close();
        con.close();
        
        return usernameAndEmailMatchIndicator;
    }
    
    /**
     * Purpose: Creates an account for new users (adds user information to the 
     * User table in the database)
     * 
     * @param register
     * @throws java.sql.SQLException
     */
    public void createAccount(LMSRegisterFrame register) throws SQLException {
        if ("Member".equals(register.getCard1().getButtonGroup().getSelection().getActionCommand())){
            Connection con = getConnection();
            Statement stmt;
            ResultSet rs;

            //Retrieve most recent UserID then increment it for new User and Member
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT UserID " + 
                                   "FROM TestDB.dbo.LMSUsers " + 
                                   "WHERE  UserID = (SELECT MAX(UserID) FROM TestDB.dbo.LMSUsers)"
            );

            int insertedUserID = 0;
            while(rs.next()){
                insertedUserID = rs.getInt("UserID") + 1;
            }
            
            stmt.close();
            rs.close();
            
            PreparedStatement pstmt;
            
            //Create row in User table
            pstmt = con.prepareStatement("INSERT INTO TestDB.dbo.LMSUsers(UserID, LibCardNum, Username, Password, ProfilePicture, FirstName, " +
                                                                         "LastName, DateOfBirth, Sex, Ethnicity, PhoneNumber, StreetAddress, " +
                                                                         "City, State, PostalCode, Country, TypeOfUser, Email) " + 
                                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            pstmt.setInt(1, insertedUserID);
            pstmt.setInt(2, Integer.parseInt(register.getCard6().getLibNumField().getText()));
            pstmt.setString(3, register.getCard6().getUsernameField().getText());
            pstmt.setString(4, String.valueOf(register.getCard6().getPasswordField().getPassword()));
            pstmt.setBytes(5, register.getCard7().getProfilePicBytes());
            pstmt.setString(6, register.getCard2().getFirstNameField().getText());
            pstmt.setString(7, register.getCard2().getLastNameField().getText());
            pstmt.setString(8, register.getCard2().getDateOfBirthField().getText());
            pstmt.setString(9, register.getCard3().getSexCombo().getSelectedItem().toString());
            pstmt.setString(10, register.getCard3().getEthCombo().getSelectedItem().toString());
            pstmt.setString(11, register.getCard5().getPhoneField().getText());
            pstmt.setString(12, register.getCard4().getAddressField().getText());
            pstmt.setString(13, register.getCard4().getCityField().getText());
            pstmt.setString(14, register.getCard4().getStateField().getText());
            pstmt.setString(15, register.getCard4().getPostalCodeField().getText());
            pstmt.setString(16, register.getCard4().getCountryField().getText());
            pstmt.setString(17, register.getCard1().getButtonGroup().getSelection().getActionCommand());
            pstmt.setString(18, register.getCard5().getEmailField().getText());
            pstmt.executeUpdate();
            
            //Create row in Member table
            pstmt = con.prepareStatement("INSERT INTO TestDB.dbo.LMSMembers(MemberID, BooksRented, BooksBought, IsPremium) " + 
                                         "VALUES (?, ?, ?, ?)");
            pstmt.setInt(1, insertedUserID);
            pstmt.setInt(2, 0);
            pstmt.setInt(3, 0);
            pstmt.setString(4, register.getCard1().getIsPremiumCheckBox().getActionCommand());
            pstmt.executeUpdate();
            
            pstmt.close();
            con.close();
            
        } else if ("Staff".equals(register.getCard1().getButtonGroup().getSelection().getActionCommand())){
            Connection con = getConnection();
            Statement stmt;
            ResultSet rs;

            //Retrieve most recent UserID then increment it for new User, Member, and Staff
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT UserID " + 
                                   "FROM TestDB.dbo.LMSUsers " + 
                                   "WHERE  UserID = (SELECT MAX(UserID) FROM TestDB.dbo.LMSUsers)"
            );

            int insertedUserID = 0;
            while(rs.next()){
                insertedUserID = rs.getInt("UserID") + 1;
            }
            
            stmt.close();
            rs.close();
            
            PreparedStatement pstmt;
            
            //Create row in User table
            pstmt = con.prepareStatement("INSERT INTO TestDB.dbo.LMSUsers(UserID, LibCardNum, Username, Password, ProfilePicture, FirstName, " +
                                                                         "LastName, DateOfBirth, Sex, Ethnicity, PhoneNumber, StreetAddress, " +
                                                                         "City, State, PostalCode, Country, TypeOfUser, Email) " + 
                                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            pstmt.setInt(1, insertedUserID);
            pstmt.setInt(2, Integer.parseInt(register.getCard6().getLibNumField().getText()));
            pstmt.setString(3, register.getCard6().getUsernameField().getText());
            pstmt.setString(4, String.valueOf(register.getCard6().getPasswordField().getPassword()));
            pstmt.setBytes(5, register.getCard7().getProfilePicBytes());
            pstmt.setString(6, register.getCard2().getFirstNameField().getText());
            pstmt.setString(7, register.getCard2().getLastNameField().getText());
            pstmt.setString(8, register.getCard2().getDateOfBirthField().getText());
            pstmt.setString(9, register.getCard3().getSexCombo().getSelectedItem().toString());
            pstmt.setString(10, register.getCard3().getEthCombo().getSelectedItem().toString());
            pstmt.setString(11, register.getCard5().getPhoneField().getText());
            pstmt.setString(12, register.getCard4().getAddressField().getText());
            pstmt.setString(13, register.getCard4().getCityField().getText());
            pstmt.setString(14, register.getCard4().getStateField().getText());
            pstmt.setString(15, register.getCard4().getPostalCodeField().getText());
            pstmt.setString(16, register.getCard4().getCountryField().getText());
            pstmt.setString(17, register.getCard1().getButtonGroup().getSelection().getActionCommand());
            pstmt.setString(18, register.getCard5().getEmailField().getText());
            pstmt.executeUpdate();
            
            //Create row in Member table
            pstmt = con.prepareStatement("INSERT INTO TestDB.dbo.LMSMembers(MemberID, BooksRented, BooksBought, IsPremium) " + 
                                         "VALUES (?, ?, ?, ?)");
            pstmt.setInt(1, insertedUserID);
            pstmt.setInt(2, 0);
            pstmt.setInt(3, 0);
            pstmt.setString(4, register.getCard1().getIsPremiumCheckBox().getActionCommand());
            pstmt.executeUpdate();
            
            //Create row in Staff table
            pstmt = con.prepareStatement("INSERT INTO TestDB.dbo.LMSStaff(StaffID, TimeSheetCode, StartDate, MembersServed, HoursWorked, IsAdmin) " + 
                                         "VALUES (?, ?, ?, ?, ?, ?)");
            pstmt.setInt(1, insertedUserID);
            pstmt.setInt(2, Integer.parseInt(register.getCard6().getLibNumField().getText()));
            pstmt.setString(3, new LMSDate().getCurrentDate());
            pstmt.setInt(4, 0);
            pstmt.setInt(5, 0);
            pstmt.setString(6, register.getIsAdminCard().getButtonGroup().getSelection().getActionCommand());
            pstmt.executeUpdate();
            
            pstmt.close();
            con.close();
        }
    } //end createAccount()
    
    /**
     * Purpose: Saves (updates) user profile changes made in the profile page
     * 
     * @param profile
     * @param username
     * @throws java.sql.SQLException
     */
    public void saveProfileChanges(LMSProfileCard profile, String username) throws SQLException {
        Connection con = getConnection();
        PreparedStatement pstmt;
         
        //Create row in User table
        pstmt = con.prepareStatement("UPDATE TestDB.dbo.LMSUsers " +
                                     "SET ProfilePicture = ?, PhoneNumber = ?, StreetAddress = ?, City = ?, State = ?, " +
                                        "PostalCode = ?, Country = ?, Password = ?, Email = ? " +
                                     "WHERE Username = '" + username + "' ");
        pstmt.setBytes(1, profile.getProfilePicBytes());
        pstmt.setString(2, profile.getPhoneField().getText());
        pstmt.setString(3, profile.getStrAddField().getText());
        pstmt.setString(4, profile.getCityField().getText());
        pstmt.setString(5, profile.getStateField().getText());
        pstmt.setString(6, profile.getpCodeField().getText());
        pstmt.setString(7, profile.getCountryField().getText());
        pstmt.setString(8, String.valueOf(profile.getPwordField().getPassword()));
        pstmt.setString(9, profile.getEmailField().getText());
        pstmt.executeUpdate();
        
        pstmt.close();
        con.close();
    } //end saveProfileChanges()
    
    /**
     * Purpose: Adds selected books from BooksToRent page into LMSIssues table in 
     * DB
     * 
     * @param booksToRent
     * @param username
     * @throws java.sql.SQLException
     */
    public void addToYourRentals(LMSBooksToRentCard booksToRent, String username) throws SQLException {
        Connection con = getConnection();
        Statement stmt;
        ResultSet rs;
        
        //Add row to Books Issues (Add to Your Book Rentals)
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT IssueID " +
            "FROM TestDB.dbo.LMSIssues " +
            "WHERE  IssueID = (SELECT MAX(IssueID) FROM TestDB.dbo.LMSIssues) "
        );
        
        int issueID = 0;
        while(rs.next()){
            issueID = rs.getInt("IssueID") + 1;
        }
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT UserID " +
            "FROM TestDB.dbo.LMSUsers " +
            "WHERE Username = '" + username + "' "
        );
        
        int memberID = 0;
        while(rs.next()){
            memberID = rs.getInt("UserID");
        }
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT Price " +
            "FROM TestDB.dbo.LMSBooks " +
            "WHERE ISBN = '" + booksToRent.getIsbnLabel2().getText() + "' "
        );
        
        int lateFee = 0;
        while(rs.next()){
            lateFee = rs.getInt("Price") + 5;
        }
        
        PreparedStatement pstmt;
         
        pstmt = con.prepareStatement("INSERT INTO TestDB.dbo.LMSIssues (IssueID, IssueDate, Period, ReturnDate, LateFee, ISBN, MemberID, StaffID) " +
                                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?) ");
        pstmt.setInt(1, issueID);
        pstmt.setString(2, new LMSDate().getCurrentDate());
        pstmt.setInt(3, 10);
        pstmt.setString(4, new LMSDate().getReturnDate());
        pstmt.setInt(5, lateFee);
        pstmt.setString(6, booksToRent.getIsbnLabel2().getText());
        pstmt.setInt(7, memberID);
        pstmt.setInt(8, 1001);
        pstmt.executeUpdate();
        
        //Increment BooksRented
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT BooksRented " +
            "FROM TestDB.dbo.LMSMembers " +
            "WHERE MemberID = '" + memberID + "' "
        );
        
        int booksRented = 0;
        while(rs.next()){
            booksRented = rs.getInt("BooksRented") + 1;
        }

        pstmt = con.prepareStatement("UPDATE TestDB.dbo.LMSMembers " +
                                     "SET BooksRented = ? " +
                                     "WHERE MemberID = '" + memberID + "' ");
        pstmt.setInt(1, booksRented);
        pstmt.executeUpdate();
        
        //Increment MembersServed
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT MembersServed " +
            "FROM TestDB.dbo.LMSStaff " +
            "WHERE StaffID = '1001' "
        );
        
        int membersServed = 0;
        while(rs.next()){
            membersServed = rs.getInt("MembersServed") + 1;
        }

        stmt.close();
        rs.close();
        
        pstmt = con.prepareStatement("UPDATE TestDB.dbo.LMSStaff " +
                                     "SET MembersServed = ? " +
                                     "WHERE StaffID = '1001' ");
        pstmt.setInt(1, membersServed);
        pstmt.executeUpdate();
        
        pstmt.close();
        con.close();
    } //end addToYourRentals()
    
    /**
     * Purpose: Adds selected books from LMSCart page into LMSPurchases table in DB
     * 
     * @param username
     * @param itemQuantity
     * @param price
     * @param isbn
     * @throws java.sql.SQLException
     */
    public void addToYourPurchases(String username, String itemQuantity, String price, String isbn) throws SQLException {
        Connection con = getConnection();
        Statement stmt;
        ResultSet rs;
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT CASE WHEN EXISTS " +
                "(SELECT 1 FROM TestDB.dbo.LMSPurchases) " + 
            "THEN CAST ('NO' AS varchar(2)) " +
            "ELSE CAST ('YES' AS varchar(3)) END AS IsEmpty "
        );
        
        String isEmpty = "";
        while (rs.next()) {
            isEmpty = rs.getString("IsEmpty");
        }
        
        int purchaseID = 0;
        if ("YES".equals(isEmpty)) {
            purchaseID = 1001;
        } else {
            stmt = con.createStatement();
            rs = stmt.executeQuery(
                "SELECT PurchaseID " +
                "FROM TestDB.dbo.LMSPurchases " +
                "WHERE  PurchaseID = (SELECT MAX(PurchaseID) FROM TestDB.dbo.LMSPurchases) "
            );

            while(rs.next()){
                purchaseID = rs.getInt("PurchaseID") + 1;
            }
        }
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT UserID " +
            "FROM TestDB.dbo.LMSUsers " +
            "WHERE Username = '" + username + "' "
        );
        
        int memberID = 0;
        while(rs.next()) {
            memberID = rs.getInt("UserID");
        }
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT BooksBought " +
            "FROM TestDB.dbo.LMSMembers " +
            "WHERE MemberID = '" + memberID + "' "
        );
        
        int booksBought = 0;
        while (rs.next()) {
            booksBought = rs.getInt("BooksBought") + 1;
        }
        
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT MembersServed " +
            "FROM TestDB.dbo.LMSStaff " +
            "WHERE StaffID = '1001' "
        );
        
        int membersServed = 0;
        while (rs.next()) {
            membersServed = rs.getInt("MembersServed") + 1;
        }
        
        stmt.close();
        rs.close();
        
        PreparedStatement pstmt;
        
        pstmt = con.prepareStatement("INSERT INTO TestDB.dbo.LMSPurchases (PurchaseID, PurchaseDate, ItemQuantity, Price, ISBN, MemberID, StaffID) " +
                                     "VALUES (?,?,?,?,?,?,?) "
        );
        
        pstmt.setInt(1, purchaseID);
        pstmt.setString(2, new LMSDate().getCurrentDate());
        pstmt.setString(3, itemQuantity);
        pstmt.setString(4, price);
        pstmt.setString(5, isbn);
        pstmt.setInt(6, memberID);
        pstmt.setInt(7, 1001);
        pstmt.executeUpdate();

        pstmt = con.prepareStatement("UPDATE TestDB.dbo.LMSMembers " +
                                     "SET BooksBought = ? " +
                                     "WHERE MemberID = ? "
        );
        
        pstmt.setInt(1, booksBought);
        pstmt.setInt(2, memberID);
        pstmt.executeUpdate();
        
        pstmt = con.prepareStatement("UPDATE TestDB.dbo.LMSStaff " +
                                     "SET MembersServed = ? " +
                                     "WHERE StaffID = ? "
        );
        
        pstmt.setInt(1, membersServed);
        pstmt.setInt(2, 1001);
        pstmt.executeUpdate();
        
        pstmt.close();
        con.close();
    }
    
    /**
     * Purpose: Adds selected books from BooksToBuy page into LMSCart table in DB
     * 
     * @param booksToBuy
     * @param username
     * @throws java.sql.SQLException
     */
    public void addToCart(LMSBooksToBuyCard booksToBuy, String username) throws SQLException {
        Connection con = getConnection();
        Statement stmt;
        ResultSet rs;
        
        //Check whether same book is already in cart
        stmt = con.createStatement();
        rs = stmt.executeQuery(
            "SELECT CASE WHEN EXISTS ( " +
                "SELECT * " +
                "FROM TestDB.dbo.LMSCart " +
                "WHERE ISBN = '" + booksToBuy.getIsbnLabel2().getText() + "' AND Username = '" + username + "' " +
            ") " +
            "THEN CAST('YES' AS varchar(3)) " +
            "ELSE CAST('NO' AS varchar(2)) END AS RowExists"
        );
        
        String rowExists = "";
        while (rs.next()) {
            rowExists = rs.getString("RowExists");
        }
        
        //If selected item is already in cart, then update item quantity only
        if ("YES".equals(rowExists)) {
            stmt = con.createStatement();
            rs = stmt.executeQuery(
                "SELECT Price " +
                "FROM TestDB.dbo.LMSBooks " +
                "WHERE ISBN = '" + booksToBuy.getIsbnLabel2().getText() + "' "
            );

            int price = 0;
            while(rs.next()){
                price = rs.getInt("Price");
            }
            
            stmt = con.createStatement();
            rs = stmt.executeQuery(
                "SELECT ItemQuantity " +
                "FROM TestDB.dbo.LMSCart " +
                "WHERE ISBN = '" + booksToBuy.getIsbnLabel2().getText() + "' AND Username = '" + username + "' "
            );

            int itemQuantity = 0;
            while(rs.next()){
                itemQuantity = rs.getInt("ItemQuantity");
            }
            
            int totalItemQuantity = itemQuantity + Integer.parseInt(booksToBuy.getItemQuantityLabel().getText());
        
            if (totalItemQuantity > 99) {
                totalItemQuantity = 99;
            }
            
            stmt.close();
            rs.close();
            
            PreparedStatement pstmt;
         
            pstmt = con.prepareStatement("UPDATE TestDB.dbo.LMSCart " +
                                         "SET ItemQuantity = ? , Price = ? " +
                                         "WHERE ISBN = '" + booksToBuy.getIsbnLabel2().getText() + "' AND Username = '" + username + "' "
            );
            pstmt.setInt(1, totalItemQuantity);
            pstmt.setInt(2, price * totalItemQuantity);
            pstmt.executeUpdate();

            pstmt.close();
            con.close();
        
        //If selected item is not in cart, then add to cart with chosen item quantity
        } else {
            stmt = con.createStatement();
            rs = stmt.executeQuery(
                "SELECT Price " +
                "FROM TestDB.dbo.LMSBooks " +
                "WHERE ISBN = '" + booksToBuy.getIsbnLabel2().getText() + "' "
            );

            int price = 0;
            while(rs.next()){
                price = rs.getInt("Price");
            }

            stmt.close();
            rs.close();
            
            PreparedStatement pstmt;

            pstmt = con.prepareStatement("INSERT INTO TestDB.dbo.LMSCart (Username, CoverImage, ISBN, Title, ItemQuantity, Price) " +
                                         "VALUES (?, ?, ?, ?, ?, ?) ");
            pstmt.setString(1, username);
            pstmt.setBytes(2, booksToBuy.getCoverImageBytes());
            pstmt.setString(3, booksToBuy.getIsbnLabel2().getText());
            pstmt.setString(4, booksToBuy.getTitleLabel2().getText());
            pstmt.setInt(5, Integer.parseInt(booksToBuy.getItemQuantityLabel().getText()));
            pstmt.setInt(6, price * Integer.parseInt(booksToBuy.getItemQuantityLabel().getText()));
            pstmt.executeUpdate();

            pstmt.close();
            con.close();
        }
    } //end addToCart()
    
    /**
     * Purpose: Updates (increments or decrements) item quantity and price 
     * values in LMSCart table in DB
     * 
     * @param itemQuantity
     * @param price
     * @param username
     * @param isbn
     * @throws java.sql.SQLException
     */
    public void updateItemQuantityAndPrice(String itemQuantity, String price, String username, String isbn) throws SQLException {
        Connection con = getConnection();
        PreparedStatement pstmt;
        
        int prce = (int) Double.parseDouble(price);
        String prc = String.valueOf(prce);
        
        pstmt = con.prepareStatement("UPDATE TestDB.dbo.LMSCart " +
                                     "SET ItemQuantity = ?, Price = ? " + 
                                     "WHERE Username = ? AND ISBN = ? "
        );
        
        pstmt.setString(1, itemQuantity);
        pstmt.setString(2, prc);
        pstmt.setString(3, username);
        pstmt.setString(4, isbn);
        pstmt.executeUpdate();

        pstmt.close();
        con.close();
    }
    
    /**
     * Purpose: Deletes selected book from Cart tab or Checkout page related to 
     * signed-in user (removes book from LMSCart table in DB)
     * 
     * @param username
     * @param isbn
     * @throws java.sql.SQLException
     */
    public void deleteItemFromCart(String username, String isbn) throws SQLException {
        Connection con = getConnection();
        PreparedStatement pstmt;
         
        pstmt = con.prepareStatement("DELETE FROM TestDB.dbo.LMSCart " +
                                     "WHERE Username = ? AND ISBN = ? "
        );
        
        pstmt.setString(1, username);
        pstmt.setString(2, isbn);
        pstmt.executeUpdate();

        pstmt.close();
        con.close();
    }
    
    /**
     * Purpose: Deletes all books from LMSCart table in DB related to signed-in 
     * user
     * 
     * @param username
     * @throws java.sql.SQLException
     */
    public void deleteAllFromCart(String username) throws SQLException {
        Connection con = getConnection();
        PreparedStatement pstmt;
         
        pstmt = con.prepareStatement("DELETE FROM TestDB.dbo.LMSCart " +
                                     "WHERE Username = ? "
        );
        
        pstmt.setString(1, username);
        pstmt.executeUpdate();

        pstmt.close();
        con.close();
    }
}
