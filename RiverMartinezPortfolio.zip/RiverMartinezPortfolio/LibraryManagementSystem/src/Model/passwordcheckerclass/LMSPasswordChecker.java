/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.passwordcheckerclass;

import javax.swing.JPasswordField;

/**
 *
 * @author River
 */
public class LMSPasswordChecker {
    
    public LMSPasswordChecker(){
        
    }
    
    public boolean isPasswordStrong(String passwordField) {
        
        final String LOWERCASES = "abcdefghijklmnopqrstuvwxyz";
        final char[] UPPERCASES = String.valueOf(LOWERCASES).toUpperCase().toCharArray();
        final char[] DIGITS = "0123456789".toCharArray();
        final char[] SYMBOLS = "!@#&()–[{}]:;',?/*~$^+=<>".toCharArray();
        final int MIN_PASSWORD_LENGTH = 8;
        final int MAX_PASSWORD_LENGTH = 16;
        boolean passwordStrengthIndicator = true;
        
        int uppercaseCount = 0;
        for (int i = 0; i < UPPERCASES.length; i++) {
            if (passwordField.contains(String.valueOf(UPPERCASES[i]))){
                uppercaseCount++;
            }
        }
        
        int digitCount = 0;
        for (int i = 0; i < DIGITS.length; i++) {
            if (passwordField.contains(String.valueOf(DIGITS[i]))){
                digitCount++;
            }
        }
        
        int symbolCount = 0;
        for (int i = 0; i < SYMBOLS.length; i++) {
            if (passwordField.contains(String.valueOf(SYMBOLS[i]))){
                symbolCount++;
            }
        }
        
        if (uppercaseCount == 0 || digitCount == 0 || symbolCount == 0){
            passwordStrengthIndicator = false;
        }
        
        return passwordStrengthIndicator;
    }
}
