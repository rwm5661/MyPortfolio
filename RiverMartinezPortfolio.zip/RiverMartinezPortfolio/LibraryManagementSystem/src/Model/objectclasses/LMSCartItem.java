/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.objectclasses;

/**
 *
 * @author River
 */
public class LMSCartItem {
    
    private byte[] coverImage;
    private String isbn;
    private String title;
    private int itemQuantity;
    private int price;
    
    public LMSCartItem(byte[] cI, String isbn, String t, int iQ, int prc) {
        this.coverImage = cI;
        this.isbn = isbn;
        this.title = t;
        this.itemQuantity = iQ;
        this.price = prc;
    }

    /**
     * @return the coverImage
     */
    public byte[] getCoverImage() {
        return coverImage;
    }

    /**
     * @param coverImage the coverImage to set
     */
    public void setCoverImage(byte[] coverImage) {
        this.coverImage = coverImage;
    }

    /**
     * @return the isbn
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @param isbn the isbn to set
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the itemQuantity
     */
    public int getItemQuantity() {
        return itemQuantity;
    }

    /**
     * @param itemQuantity the itemQuantity to set
     */
    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    /**
     * @return the price
     */
    public int getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(int price) {
        this.price = price;
    }
    
    
}
