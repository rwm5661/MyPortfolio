/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.objectclasses;

/**
 *
 * @author River
 */
public class LMSIssue {
    
    private String issueDate;
    private int period;
    private String returnDate;
    private int lateFee;
    private String isbn;
    private String bookTitle;
    private byte[] bookCover;
    
    public LMSIssue(String iDate, int p, String rDate, int lFee, String isbn, String bT, byte[] bC){
        this.issueDate = iDate;
        this.period = p;
        this.returnDate = rDate;
        this.lateFee = lFee;
        this.isbn = isbn;
        this.bookTitle = bT;
        this.bookCover = bC;
    }

    /**
     * @return the issueDate
     */
    public String getIssueDate() {
        return issueDate;
    }

    /**
     * @return the period
     */
    public int getPeriod() {
        return period;
    }

    /**
     * @return the returnDate
     */
    public String getReturnDate() {
        return returnDate;
    }

    /**
     * @return the lateFee
     */
    public int getLateFee() {
        return lateFee;
    }

    /**
     * @return the isbn
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @return the bookTitle
     */
    public String getBookTitle() {
        return bookTitle;
    }

    /**
     * @param bookTitle the bookTitle to set
     */
    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    /**
     * @return the bookCover
     */
    public byte[] getBookCover() {
        return bookCover;
    }

    /**
     * @param bookCover the bookCover to set
     */
    public void setBookCover(byte[] bookCover) {
        this.bookCover = bookCover;
    }
}
