/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.objectclasses;

/**
 *
 * @author River
 */
public class LMSStaff {
    
    private int staffID;
    private int timeSheetCode;
    private String startDate;
    private int membersServed;
    private int hoursWorked;
    private String isAdmin;
    
    /*
      Constructor for Library Management System User instances
    */
    public LMSStaff(int sID, int tSC, String sDate, int mServed, int hWorked, String iA){
        this.staffID = sID;
        this.timeSheetCode = tSC;
        this.startDate = sDate;
        this.membersServed = mServed;
        this.hoursWorked = hWorked;
        this.isAdmin = iA;
    }

    /**
     * @return the staffID
     */
    public int getStaffID() {
        return staffID;
    }

    /**
     * @return the timeSheetCode
     */
    public int getTimeSheetCode() {
        return timeSheetCode;
    }

    /**
     * @return the startDate
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * @return the membersServed
     */
    public int getMembersServed() {
        return membersServed;
    }

    /**
     * @return the hoursWorked
     */
    public int getHoursWorked() {
        return hoursWorked;
    }

    /**
     * @return the isAdmin
     */
    public String getIsAdmin() {
        return isAdmin;
    }
}
