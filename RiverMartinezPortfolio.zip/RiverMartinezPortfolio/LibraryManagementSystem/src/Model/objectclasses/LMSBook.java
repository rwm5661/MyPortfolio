/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.objectclasses;

/**
 *
 * @author River
 */
public class LMSBook {
    
    private String isbn;
    private byte[] coverImage;
    private String title;
    private String author;
    private String yearPub;
    private String genre;
    private int price;
    
    /*
      Constructor for Library Management System Books To Buy instances
    */
    public LMSBook(String isbn, byte[] cI, String ttle, String athr, String yrPb, String gnr, int prce){
        this.isbn = isbn;
        this.coverImage = cI;
        this.title = ttle;
        this.author = athr;
        this.yearPub = yrPb;
        this.genre = gnr;
        this.price = prce;
    }
    
    /*
      Constructor for Library Management System Book To Rent instances
    */
    public LMSBook(String isbn, byte[] cI, String ttle, String athr, String yrPb, String gnr){
        this.isbn = isbn;
        this.coverImage = cI;
        this.title = ttle;
        this.author = athr;
        this.yearPub = yrPb;
        this.genre = gnr;
    }

    /**
     * @return the isbn
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * @return the coverImage
     */
    public byte[] getCoverImage() {
        return coverImage;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @return the yearPub
     */
    public String getYearPub() {
        return yearPub;
    }

    /**
     * @return the genre
     */
    public String getGenre() {
        return genre;
    }

    /**
     * @return the price
     */
    public int getPrice() {
        return price;
    }
}
