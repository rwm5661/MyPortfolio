/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.objectclasses;

/**
 *
 * @author River
 */
public class LMSMember {
 
    private int memberID;
    private int booksRent;
    private int booksBought;
    private String isPremium;
    
    /*
      Constructor for Library Management System User instances
    */
    public LMSMember(int mID, int bRent, int bBought, String isPre){
        this.memberID = mID;
        this.booksRent = bRent;
        this.booksBought = bBought;
        this.isPremium = isPre;
    }

    /**
     * @return the memberID
     */
    public int getMemberID() {
        return memberID;
    }

    /**
     * @return the booksRent
     */
    public int getBooksRent() {
        return booksRent;
    }

    /**
     * @return the booksBought
     */
    public int getBooksBought() {
        return booksBought;
    }

    /**
     * @return the isPremium
     */
    public String getIsPremium() {
        return isPremium;
    }
}
