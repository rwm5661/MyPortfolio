/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.objectclasses;

/**
 *
 * @author River
 */
public class LMSPurchase {
    
    private String purchaseDate;
    private int itemQuantity;
    private int price;
    private String isbn;
    private String bookTitle;
    private byte[] bookCover;
    
    public LMSPurchase(String pDate, int iQ, int prc, String isbn, String bT, byte[] bC){
        this.purchaseDate = pDate;
        this.itemQuantity = iQ;
        this.price = prc;
        this.isbn = isbn;
        this.bookTitle = bT;
        this.bookCover = bC;
    }

    /**
     * @return the purchaseDate
     */
    public String getPurchaseDate() {
        return purchaseDate;
    }
    
    /**
     * @return the itemQuantity
     */
    public int getItemQuantity() {
        return itemQuantity;
    }

    /**
     * @return the price
     */
    public int getPrice() {
        return price;
    }
    
    /**
     * @return the isbn
     */
    public String getIsbn() {
        return isbn;
    }
    
    /**
     * @return the bookTitle
     */
    public String getBookTitle() {
        return bookTitle;
    }

    /**
     * @return the bookCover
     */
    public byte[] getBookCover() {
        return bookCover;
    }

    /**
     * @param bookTitle the bookTitle to set
     */
    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    /**
     * @param bookCover the bookCover to set
     */
    public void setBookCover(byte[] bookCover) {
        this.bookCover = bookCover;
    }
}
