/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.objectclasses;

/**
 *
 * @author River
 */
public class LMSUser {
    
    private int userID;
    private int libCardNum;
    private String username;
    private String password;
    private byte[] profilePic;
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String sex;
    private String ethnicity;
    private String phoneNum;
    private String streetAddress;
    private String city;
    private String state;
    private String postalCode;
    private String country;
    private String typeOfUser;
    private String email;
    
    /*
      Default constructor for Library Management System User instances
    */
    public LMSUser(){
        
    }
    
    /*
      Constructor for Library Management System User instances
    */
    public LMSUser(int uID, int lCN, String un, String pw, byte[] pP, String fN, 
                   String lN, String dOB, String sex, String eth, String phone, String sA,
                   String cty, String stte, String pC, String cntry, String tOU, String email){
        this.userID = uID;
        this.libCardNum = lCN;
        this.username = un;
        this.password = pw;
        this.profilePic = pP;
        this.firstName = fN;
        this.lastName = lN;
        this.dateOfBirth = dOB;
        this.sex = sex;
        this.ethnicity = eth;
        this.phoneNum = phone;
        this.streetAddress = sA;
        this.city = cty;
        this.state = stte;
        this.country = cntry;
        this.typeOfUser = tOU;
        this.email = email;
    }

    /**
     * @return the userID
     */
    public int getUserID() {
        return userID;
    }

    /**
     * @return the libCardNum
     */
    public int getLibCardNum() {
        return libCardNum;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @return the profilePic
     */
    public byte[] getProfilePic() {
        return profilePic;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @return the dateOfBirth
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * @return the sex
     */
    public String getSex() {
        return sex;
    }

    /**
     * @return the ethnicity
     */
    public String getEthnicity() {
        return ethnicity;
    }

    /**
     * @return the phoneNum
     */
    public String getPhoneNum() {
        return phoneNum;
    }

    /**
     * @return the streetAddress
     */
    public String getStreetAddress() {
        return streetAddress;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * @return the postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @return the typeOfUser
     */
    public String getTypeOfUser() {
        return typeOfUser;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param userID the userID to set
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * @param libCardNum the libCardNum to set
     */
    public void setLibCardNum(int libCardNum) {
        this.libCardNum = libCardNum;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @param profilePic the profilePic to set
     */
    public void setProfilePic(byte[] profilePic) {
        this.profilePic = profilePic;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @param dateOfBirth the dateOfBirth to set
     */
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * @param sex the sex to set
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * @param ethnicity the ethnicity to set
     */
    public void setEthnicity(String ethnicity) {
        this.ethnicity = ethnicity;
    }

    /**
     * @param phoneNum the phoneNum to set
     */
    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    /**
     * @param streetAddress the streetAddress to set
     */
    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @param state the state to set
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * @param postalCode the postalCode to set
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @param typeOfUser the typeOfUser to set
     */
    public void setTypeOfUser(String typeOfUser) {
        this.typeOfUser = typeOfUser;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
