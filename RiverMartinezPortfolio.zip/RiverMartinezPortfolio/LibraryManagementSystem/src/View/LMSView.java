/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import View.mainclasses.LMSMainFrame;
import View.loginclasses.LMSLoginFrame;

/**
 *
 * @author River
 */
public class LMSView {
    
    private LMSLoginFrame login;
    private LMSMainFrame main;
    
    public LMSView() {
        login = new LMSLoginFrame();
    }

    /**
     * @return the login
     */
    public LMSLoginFrame getLogin() {
        return login;
    }  
    
    /**
     * @return the main
     */
    public LMSMainFrame getMain() {
        return main;
    } 
}
