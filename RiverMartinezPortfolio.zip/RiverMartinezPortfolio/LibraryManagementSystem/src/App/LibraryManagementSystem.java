/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package App;

import Controller.LMSController;
import Model.LMSModel;
import View.LMSView;

/**
 *
 * @author River
 */
public class LibraryManagementSystem {
    public static void main(String[] args) {
        LMSModel model = new LMSModel();
        LMSView view = new LMSView();
        LMSController controller = new LMSController(model, view);
    }
}