CREATE TABLE [TestDB].[dbo].[LMSUsers](
	[UserID] [int] NOT NULL PRIMARY KEY,
	[LibCardNum] [int] NOT NULL UNIQUE,
	[Username] [varchar](20) NOT NULL UNIQUE,
	[Password] [varchar](16) NOT NULL,
	[ProfilePicture] [image],
	[FirstName] [varchar](50) NOT NULL,
	[LastName] [varchar](50) NOT NULL,
	[DateOfBirth] [varchar](10) NOT NULL,
	[Sex] [varchar](20) NOT NULL,
	[Ethnicity] [varchar](100) NOT NULL,
	[PhoneNumber] [varchar](14) NOT NULL UNIQUE,
	[StreetAddress] [varchar](255) NOT NULL,
	[City] [varchar](255) NOT NULL,
	[State] [varchar](255) NOT NULL,
	[PostalCode] [varchar](5) NOT NULL,
	[Country] [varchar](255) NOT NULL,
	[TypeOfUser] [varchar](50) NOT NULL
)

CREATE TABLE [TestDB].[dbo].[LMSMembers](
	[MemberID] [int] NOT NULL PRIMARY KEY FOREIGN KEY REFERENCES [TestDB].[dbo].[LMSUsers] (UserID),
	[BooksRented] [int] NOT NULL,
	[BooksBought] [int] NOT NULL,
	[IsPremium] [varchar](3) NOT NULL
)

CREATE TABLE [TestDB].[dbo].[LMSStaff](
	[StaffID] [int] NOT NULL PRIMARY KEY FOREIGN KEY REFERENCES [TestDB].[dbo].[LMSUsers] (UserID),
	[TimeSheetCode] [int] NOT NULL UNIQUE,
	[StartDate] [varchar](10) NOT NULL,
	[MembersServed] [int] NOT NULL,
	[HoursWorked] [int] NOT NULL,
	[IsAdmin] [varchar](3) NOT NULL
)

CREATE TABLE [TestDB].[dbo].[LMSBooks](
	[ISBN] [varchar](17) NOT NULL PRIMARY KEY,
	[CoverImage] [image],
	[Title] [varchar](255) NOT NULL,
	[Author] [varchar](100),
	[YearPublished] [varchar](10),
	[Genre] [varchar](50),
	[Price] [varchar](50) NOT NULL
)

CREATE TABLE [TestDB].[dbo].[LMSIssues](
	[IssueID] [int] NOT NULL PRIMARY KEY,
	[IssueDate] [varchar](10) NOT NULL,
	[Period] [int] NOT NULL,
	[ReturnDate] [varchar](10) NOT NULL,
	[LateFee] [int] NOT NULL,
	[ISBN] [varchar](17) NOT NULL FOREIGN KEY REFERENCES [TestDB].[dbo].[LMSBooks] (ISBN),
	[MemberID] [int] NOT NULL FOREIGN KEY REFERENCES [TestDB].[dbo].[LMSMembers] (MemberID),
	[StaffID] [int] NOT NULL FOREIGN KEY REFERENCES [TestDB].[dbo].[LMSStaff] (StaffID)
)

CREATE TABLE [TestDB].[dbo].[LMSPurchases](
	[PurchaseID] [int] NOT NULL PRIMARY KEY,
	[PurchaseDate] [varchar](10) NOT NULL,
	[ISBN] [varchar](17) NOT NULL FOREIGN KEY REFERENCES [TestDB].[dbo].[LMSBooks] (ISBN),
	[MemberID] [int] NOT NULL FOREIGN KEY REFERENCES [TestDB].[dbo].[LMSMembers] (MemberID),
	[StaffID] [int] NOT NULL FOREIGN KEY REFERENCES [TestDB].[dbo].[LMSStaff] (StaffID)
)


