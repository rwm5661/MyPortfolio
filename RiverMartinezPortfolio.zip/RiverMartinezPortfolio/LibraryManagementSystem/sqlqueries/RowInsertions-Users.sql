INSERT INTO [TestDB].[dbo].[LMSUsers] ([UserID], [LibCardNum], [Username], [Password], [ProfilePicture], [FirstName], [LastName], [DateOfBirth], [Sex], [Ethnicity], [PhoneNumber], [StreetAddress], [City], [State], [PostalCode], [Country], [TypeOfUser])
VALUES ('1001', '0905', 'rwm5661', 'noiceCar102!', NULL, 'River', 'Martinez', '09-05-1999', 'Male', 'Hispanic/Latino', '(555) 555-5555', '123 Jolly Road', 'Hanover', 'Pennsylvania', '17331', 'United States of America', 'Both')

INSERT INTO [TestDB].[dbo].[LMSMembers] ([MemberID], [BooksRented], [BooksBought], [IsPremium])
VALUES ('1001','97','14','Yes')

INSERT INTO [TestDB].[dbo].[LMSStaff] ([StaffID], [TimeSheetCode], [StartDate], [MembersServed], [HoursWorked], [IsAdmin])
VALUES ('1001','0509','03-10-2012','459','9999','Yes')