//Name: River Martinez
//Assignment: Homework 6
//Due: November 11, 2020
//rwm5661.psu.edu

package defaultpackage;

//Class name: ATM.java
//Purpose of class: Instantiates ATMGUI object and runs application

public class ATM //ATM class
{
    public static void main(String[] args) //main method
    {
        ATMGUI atm = new ATMGUI("Welcome to the ATM"); //Instantiaties ATMGUI object
    }
}
