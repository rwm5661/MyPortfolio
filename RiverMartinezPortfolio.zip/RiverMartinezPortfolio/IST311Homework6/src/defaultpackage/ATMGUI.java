//Name: River Martinez
//Assignment: Homework 6
//Due: November 11, 2020
//rwm5661.psu.edu

package defaultpackage;

import javax.swing.*;
import java.awt.*;    // container class located
import java.awt.event.*;  // actionListener interface
import java.text.DecimalFormat; //accesses DecimalFormat class

//Class name: ATMGUI.java
//Purpose of class: Constructs functional ATM GUI
//Author: Robert Bartell

public class ATMGUI extends JFrame implements ActionListener
{
    //JPanel objects
    private JPanel northJPanel = new JPanel();
    private JPanel northDisplayJPanel = new JPanel();
    private JPanel northEnterJPanel = new JPanel();
    private JPanel southJPanel = new JPanel();
    private JPanel eastButtonJPanel = new JPanel();
    private JPanel buttonJPanel = new JPanel();
    private JPanel keyPadJPanel = new JPanel();
    //Display objects
    private JTextField enterField = new JTextField(15); //JTextField object used to display userPIN or withDrawAmount
    private JTextArea display = new JTextArea(5,30); //JTextArea object used to display ATM actions
    private JScrollPane scrollbar; //Used to allow scrolling on JTextArea
    //Bank buttons
    private JButton enterButton = new JButton   ("<html><font size=4>Enter</font></html>");  
    private JButton balanceButton = new JButton ("<html><font size=4>Balance</font></html>");
    private JButton withDrawButton = new JButton("<html><font size=4>Withdraw</font></html>");    
    private JButton doneButton = new JButton    ("<html><font size=4>Done</font></html>");
    //Numeric keypad buttons
    private JButton buttons[];
    private final static int NBUTTONS = 12; //size of button array
    private String labels[] = {"1","2","3","4","5","6","7","8","9"," ","0"," "}; //keypad button labels
    private BankAccount[] accounts = new BankAccount[5]; //array of BankAccount objects
    private String accountNumber[] = new String[5]; //array of String account numbers
    private DecimalFormat df = new DecimalFormat("#.##"); //Decimal Format object
    private JLabel prompt = new JLabel("Account Number:        "); //JLabel object to prompt use to enter account number
    private JComboBox namesComboBox; //JComboBox object to choose account numbers
    private String accountNumString; //variable to hold String of account number of currently-used account
    private int textFieldCount; //attribute to count the number of characters in JTextField
    private final static int TEXT_FIELD_MAX_CHAR_AMOUNT = 4; //constant to hold max character value of text field
    private String enterFieldValue; //variable to hold String of text field input, whether it is for userPIN or withDrawAmount
    private boolean withDrawButtonFlag = false; //flag variable to tell if withdraw is in process
    
    public ATMGUI(String title) //ATMGUI Constructor
    {	
        populateBankAccounts(); //Instantiates BankAccount objects
        buildGUI(title); //Builds GUI of ATM
    } // end ATMAppGUI
    
    // builds ATMGUI
    private void buildGUI(String title)
    {
        buildNorthPanel();
        buildCenterPanel();
        buildSouthPanel();
        setLocation(400,175); // position window on screen (x,y)
        setTitle(title);
        setSize(600,500);  // width, height
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // exits JFRAME APP
        setVisible(true);  // makes the GUI appear in the window
    }// end buildGUI
    
    // routine that builds a north panel and adds display to it
    private void buildNorthPanel()
    {
        northJPanel.setLayout(new BorderLayout(0,0));
        northJPanel.setBackground(Color.DARK_GRAY);
        northDisplayJPanel.add(Box.createRigidArea(new Dimension(0,100)));
        scrollbar = new JScrollPane(display); //Instantiation of scrollbar with display attached to scrollbar
        scrollbar.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); //vertical scrollbar appears always on display
        scrollbar.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); //horizontal scrollbar never appears on display
        northDisplayJPanel.add(scrollbar);
        northDisplayJPanel.setBackground(Color.DARK_GRAY);
        northJPanel.add("North",northDisplayJPanel);
        display.setEditable(false);
        display.setLineWrap(true);
        display.setBackground(Color.black);
        display.setForeground(Color.green);
        
        northEnterJPanel.setBackground(Color.DARK_GRAY);
        northEnterJPanel.add(enterField);
        northJPanel.add("South",northEnterJPanel);
        enterField.setEditable(false);
			
        add("North",northJPanel);
        display.append("Please select your account number");
    }// end buildNorthPanel
         	
    // builds center panel and adds several buttons along with an array of buttons
    private void buildCenterPanel()
    {
        buttonJPanel.add(Box.createRigidArea(new Dimension(20,250)));
        buttonJPanel.setBackground(Color.DARK_GRAY);
        keyPadJPanel.setLayout(new GridLayout(4,3,0,0));
        keyPadJPanel.setBackground(Color.DARK_GRAY);
        buttons = new JButton[NBUTTONS];
        for (int k=0; k < buttons.length; k++)
        {
            buttons[k] = new JButton(labels[k]);
            buttons[k].addActionListener(this);
            keyPadJPanel.add(buttons[k]);
        } // end for
               	
        buttonJPanel.add(keyPadJPanel,"Center");
        
        eastButtonJPanel.setLayout(new BoxLayout(eastButtonJPanel,BoxLayout.Y_AXIS));
        eastButtonJPanel.setBackground(Color.DARK_GRAY);
        eastButtonJPanel.add(Box.createRigidArea(new Dimension(25,0)));
        eastButtonJPanel.add(enterButton);
        enterButton.addActionListener(this);
        eastButtonJPanel.add(Box.createRigidArea(new Dimension(0,5)));
        eastButtonJPanel.add(balanceButton);
        balanceButton.addActionListener(this);
        eastButtonJPanel.add(Box.createRigidArea(new Dimension(0,5)));
        eastButtonJPanel.add(withDrawButton);
        withDrawButton.addActionListener(this);
        eastButtonJPanel.add(Box.createRigidArea(new Dimension(0,5)));
        eastButtonJPanel.add(doneButton);
        doneButton.addActionListener(this);
        eastButtonJPanel.add(Box.createRigidArea(new Dimension(0,5)));      
         
        for (JButton button : buttons) {button.setEnabled(false);}
        enterButton.setEnabled(false);
        balanceButton.setEnabled(false);
        doneButton.setEnabled(false);
        withDrawButton.setEnabled(false);
        
        buttonJPanel.add("East",eastButtonJPanel); 
        
        add("Center",buttonJPanel);
    }// end buildCenterPanel
         	
    //  routine that builds south panel and adds a combobox to it
    private void buildSouthPanel()
    {
        southJPanel.add(Box.createRigidArea(new Dimension(0,50)));
        southJPanel.setBackground(Color.DARK_GRAY);
        southJPanel.add(prompt);
        loadAccounts();
        namesComboBox = new JComboBox(accountNumber);
        namesComboBox.setMaximumRowCount(3);
        namesComboBox.addActionListener(this);
        namesComboBox.setSelectedIndex(-1);
        southJPanel.add(namesComboBox);
      
        add("South",southJPanel);
    }// end buildSouthPanel
   
    // not needed yet
    public void actionPerformed(ActionEvent e)
    {
        //if event source is on JComboBox, enter PIN or cancel PIN entry
        if (e.getSource() == namesComboBox)
        {
            if (namesComboBox.getSelectedIndex() != -1) //used so that a selection can be made after GUI reset
            {
                namesComboBox.setEnabled(false);
                enableKeyPad();
                doneButton.setEnabled(true);
                display.setText("");
                display.append("Please enter your PIN");
                accountNumString = String.valueOf(namesComboBox.getSelectedItem());
                System.out.println(accountNumString);
            }
        }
        
        //if event source is on Balance JButton, check account balance
        if (e.getSource() == balanceButton)
        {
            int accountNum = Integer.parseInt(accountNumString);
            for (BankAccount account : accounts) //search for account with same account number
            {
                if (accountNum == account.getAccountNumber()) //if account exists, display account balance
                {
                    doneButton.setEnabled(true);
                    display.append("\nYour account balance is $" + df.format(account.accountBalance));
                }
            }
        }
        
        //if event source is on Withdraw JButton, prompt user to enter an amount to withdraw on keypad then click enter
        if (e.getSource() == withDrawButton)
        {
            display.append("\nEnter an amount to withdraw");
            enableKeyPad();
            enterButton.setEnabled(true);
            doneButton.setEnabled(false);
            withDrawButtonFlag = true; //allows system to know withdraw button was clicked
        }
        
        //if event source is on Done JButton, reset GUI to original state
        if (e.getSource() == doneButton)
        {
            resetGUI(); //resets ATM GUI so that other accounts can be accessed
        }
        
        //if event source is on Enter JButton...
        if (e.getSource() == enterButton)
        {
            int accountNum = Integer.parseInt(accountNumString);
            for (BankAccount account : accounts) //find account with account number selected
            {
                if (accountNum == account.getAccountNumber()) //if account number matches an account stored
                {
                    if (withDrawButtonFlag == false) //if withdraw was not in process
                    {
                        if (account.verifyPIN(Integer.parseInt(enterFieldValue)) == true) //if PIN is correct, access account
                        {
                            display.setText("");
                            enterField.setText("");
                            enterButton.setEnabled(false);
                            doneButton.setEnabled(false);
                            disableKeyPad();
                            balanceButton.setEnabled(true);
                            withDrawButton.setEnabled(true);
                            display.append("Welcome to your account");
                            display.append("\nPlease select 'Balance' to check your account balance or \nselect 'Withdraw' to make a withdraw");
                        }
                        else //if PIN is incorrect, prompt user to re-enter PIN
                        {
                            enterField.setText("");
                            enterFieldValue = "";
                            display.append("\nPIN is incorrect. Please re-enter");
                        }
                    }
                    else //if withdraw was in process
                    {
                        withDrawButtonFlag = false; //turn off withdraw process
                        enterButton.setEnabled(false);
                        doneButton.setEnabled(true);
                        disableKeyPad();
                        int withDrawAmount = Integer.parseInt(enterFieldValue);
                        enterField.setText("");
                        if (account.getAccountBalance() - withDrawAmount < 0) //if withdraw is more than account balance
                        {
                            display.append("\nInsufficient funds");
                        }
                        else //if withdraw is equal to or less than account balance
                        {
                            account.setAccountBalance(account.getAccountBalance() - withDrawAmount);
                            display.append("\nYour account balance is now $" + df.format(account.accountBalance));
                            withDrawButtonFlag = false;
                        }
                    }
                }
            }
            textFieldCount = 0; //resets JTextField character count
        }
        
        //if event source is on Numeric Keypad
        for (int i = 0; i < buttons.length; i++)
        {
            final int j = i;
            if (e.getSource() == buttons[j])
            {
                textFieldCount++;
                String keyLabel;
                keyLabel = buttons[i].getText();
                if (withDrawButtonFlag == false) //if withdraw is not in process
                {
                    if (textFieldCount <= TEXT_FIELD_MAX_CHAR_AMOUNT) //only allow JTextField to hold 4 characters
                    {
                        zeroToNineJButtonActionPerformed(keyLabel);
                        if (textFieldCount == TEXT_FIELD_MAX_CHAR_AMOUNT) //once 4 characters are entered, enable enter button
                        {
                            enterButton.setEnabled(true);
                        }
                    }
                }
                else //if withdraw is in process
                {
                    zeroToNineJButtonActionPerformed(keyLabel);
                }
            }
        }
    }
    
    //instantiates an array of BankAccount objects
    private void populateBankAccounts()
    {
        int accountNumber = 1000;
        int accountPIN = 9999;
	double accountBalance = 500.75;
        //creates array of BankAccount objects
	for(int i = 0; i < accounts.length; i++)
        {
            accounts[i] = new BankAccount(accountNumber,accountPIN, accountBalance);
            accountNumber += 1000;
            accountPIN -= 1;
            accountBalance += 500.34;
	}
    }
    
    //adds account numbers as Strings to String array which will be added as items to JComboBox
    private void loadAccounts()
    {
        for (int i = 0; i < accountNumber.length; i++)
        {
            accountNumber[i] = String.valueOf(accounts[i].getAccountNumber());
        }
    }
    
    //builds userPIN in JTextField and stores userPIN as String variable enterFieldValue
    private void zeroToNineJButtonActionPerformed(String keyLabel)
    {
        enterField.setText(enterField.getText() + keyLabel);
        enterFieldValue = enterField.getText();
    }
    
    //Allows users to click Numeric keypad buttons 0-9
    private void enableKeyPad() // note - disable unused buttons
    {
        for (JButton button : buttons) 
        {
            button.setEnabled(true);
            if (button == buttons[9] || button == buttons[11])
            {
                button.setEnabled(false);
            }
        }
    }
    
    //Prohibits users from clicking Numeric keypad buttons 0-9
    private void disableKeyPad()
    {
        for (JButton button : buttons) {button.setEnabled(false);}
    }
    
    //resets ATM GUI so that a new account can be accessed
    private void resetGUI()
    {
        display.setText("");
        display.append("Please select your account number.");
        enterField.setText("");
        for (JButton button : buttons) {button.setEnabled(false);}
        enterButton.setEnabled(false);
        balanceButton.setEnabled(false);
        doneButton.setEnabled(false);
        withDrawButton.setEnabled(false);
        disableKeyPad();
        namesComboBox.setSelectedIndex(-1); 
        namesComboBox.setEnabled(true);
    }
}// end class
