//Name: River Martinez
//Assignment: Homework 6
//Due: November 11, 2020
//rwm5661.psu.edu

package defaultpackage;

import java.math.*;

//Class name: BankAccount.java
//Purpose of class: Constructs BankAccount objects

public class BankAccount 
{
    public int accountNumber; //Attribute holds Bank Account number
    public int accountPIN; //Attribute holds Bank Account PIN
    public double accountBalance; //Attribute holds Bank Account balance
    
    public BankAccount() //Default Constructor
    {
        accountNumber = 0000;
        accountPIN = 0000;
        accountBalance = 0.00;
    }    

    public BankAccount(int aN, int aPIN, double aB) //Custom Constructor
    {
        accountNumber = aN;
        accountPIN = aPIN;
        accountBalance = aB;
    }
    
    /**
     * @param inputPIN
     * @return true if inputPIN == accountPIN or false if inputPIN != accountPIN
     */
    public boolean verifyPIN(int inputPIN)
    {
        return inputPIN == accountPIN;
    }
    
    /**
     * @param withdrawAmount
     * Method to...
     * 1. Determine if withdraw is impossible due to insufficient funds
     * 2. If withdraw if possible, calculate and display new account balance based off withdraw
     */
    public void withdrawFunds(int withdrawAmount)
    {
        accountBalance -= withdrawAmount;
    }
    
    /**
     * @return the accountNumber
     */
    public int getAccountNumber() {return accountNumber;}

    /**
     * @param accountNumber the accountNumber to set
     */
    public void setAccountNumber(int accountNumber) {this.accountNumber = accountNumber;}

    /**
     * @return the accountPIN
     */
    public int getAccountPIN() {return accountPIN;}

    /**
     * @param accountPIN the accountPIN to set
     */
    public void setAccountPIN(int accountPIN) {this.accountPIN = accountPIN;}

    /**
     * @return the accountBalance
     */
    public double getAccountBalance() {return accountBalance;}

    /**
     * @param accountBalance the accountBalance to set
     */
    public void setAccountBalance(double accountBalance) {this.accountBalance = accountBalance;}
}
