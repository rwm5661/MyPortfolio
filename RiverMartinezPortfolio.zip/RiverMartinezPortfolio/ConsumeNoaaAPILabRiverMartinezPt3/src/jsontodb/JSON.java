package jsontodb;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**  
 * IST 411-001 - Lab ConsumeNoaaAPI Part 3
 * JSON.java  
 * Purpose: Converts Noaa API from JSON to Java objects and ArrayLists and transfers data into Derby database
 *  
 * @author River Martinez  
 * @version 3.0 3/14/2021 
 */
public class JSON {
    
    public NoaaData noaa;           //Noaa object
    public Database data;           //Database object
    private final String noaaWebPage = "https://www.ncdc.noaa.gov/cdo-web/api/v2/locationcategories"; //Noaa web page
    private final String token = "ZdGMkdEiKogkVtZwdGsVWBCHwYJDFzVp";                                  //Noaa header token
    
    /**
     * JSON Constructor
     */
    public JSON() {
        
    }
    
    /**
     * 1. Converts Noaa API from JSON to Java objects and ArrayList,
     * 2. Creates Derby database tables,
     * 3. Then inserts Noaa data into the Derby database tables
     * @throws IOException 
     */
    public void captureJSON() throws IOException{
        //Opens URL connection then casts it to HttpURLConnection object
        HttpURLConnection con2 = (HttpURLConnection) new URL(noaaWebPage).openConnection();
        //Sets header token for HttpURLConnection object
        con2.setRequestProperty("token", token);
        //Requests GET message
        con2.setRequestMethod("GET");
        
        //Converts URL to InputStream, then converts InputStream to Reader allowing for webpage data to be read
        try (InputStream is = con2.getInputStream();
                Reader reader = new InputStreamReader(is, StandardCharsets.UTF_8)) {

            //Instantiation of Gson object
            Gson gson = new Gson();
            
            //Converts any JSON object and array to Java object and ArrayList
            noaa = gson.fromJson(reader, NoaaData.class);
            
            //Instantiation of Database object
            data = new Database();
            
            //Create tables in database based on Noaa web page
            data.createTables();
            
            //Insert data from Noaa web page
            data.insertDataIntoTables(noaa);
        }
    }

    /**
     * @return the data
     */
    public Database getData() {
        return data;
    }
}
