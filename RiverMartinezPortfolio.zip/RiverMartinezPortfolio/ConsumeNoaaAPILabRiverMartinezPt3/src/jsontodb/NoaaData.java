package jsontodb;

import java.util.ArrayList;

/**  
 * IST 411-001 - Lab ConsumeNoaaAPI Part 3 (Originally from Lab #5 by River Martinez)
 * NoaaData.java  
 * Purpose: Used a placement holder for data acquired from JSON URL file: 
 * https://www.ncdc.noaa.gov/cdo-web/api/v2/locationcategories
 *  
 * @author River Martinez  
 * @version 1.0 3/14/2021 (Unmodified from Part 1)  
 */
class ResultSet {
    
    private int offset;
    private int count;
    private int limit;
    
    @Override
    public String toString() {
        return "ResultSetData{" + "offset=" + getOffset() + ", count=" + getCount() + 
                ", limit=" + getLimit() + '}';
    }

    /**
     * @return the offset
     */
    public int getOffset() {
        return offset;
    }

    /**
     * @return the count
     */
    public int getCount() {
        return count;
    }

    /**
     * @return the limit
     */
    public int getLimit() {
        return limit;
    }
}

class Metadata{
    
    private ResultSet resultset;
    
    @Override
    public String toString() {
        return "MetaData{" + getResultset().toString() + "}\n";
    }

    /**
     * @return the resultset
     */
    public ResultSet getResultset() {
        return resultset;
    }
}

class Result {
    
    private String name;
    private String id;
    
    @Override
    public String toString() {
        return "Results{" + "name=" + getName() + ", id=" + getId() + "}\n";
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }
}

public class NoaaData {
    
    private Metadata metadata;
    private ArrayList<Result> results;
    
    @Override
    public String toString() {
        return "NoaaLocationCategoriesData{\n" + getMetadata() + getResults() + "}";
    }

    /**
     * @return the metadata
     */
    public Metadata getMetadata() {
        return metadata;
    }

    /**
     * @return the results
     */
    public ArrayList<Result> getResults() {
        return results;
    }
}
