package jsontodb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.swing.JComboBox;

/**  
 * IST 411-001 - Lab ConsumeNoaaAPI Part 3
 * Database.java  
 * Purpose: Holds all database queries necessary for this application
 *  
 * @author River Martinez  
 * @version 3.0 3/14/2021 
 */
public class Database {
    
    private String driver = "org.apache.derby.jdbc.ClientDriver"; //Driver
    private String url = "jdbc:derby://localhost:1527/JSONDB";    //URL
    private String username = "river";                            //Username
    private String password = "river";                            //Password
    
    /**
     * Database Constructor
     */
    public Database() {

    }
    
    /**
     * Creates Derby database table for the Noaa API
     */
    public void createTables() {
        try
        {
            Class.forName(driver);
        }
        catch (Exception e) 
        {
            System.out.println("Failed to load  driver.");
            return;
        }
        try
        {
            Connection con = DriverManager.getConnection(url,username,password);            
            Statement stmt = con.createStatement();
         
            stmt.execute("CREATE TABLE Metadata" +
                         "(Offset int," +
                         "Count int," +
                         "Limit int," +
                         "primary key (Offset))");
            System.out.println("Created Metadata table");
            
            stmt.execute("CREATE TABLE Results" +
                         "(ID varchar(10)," +
                         "Name varchar(50)," +
                         "primary key (ID))");
            System.out.println("Created Results table\n");
            
            stmt.close();
            con.close();
        }
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
    
    /**
     * Inserts Noaa API data into the corresponding tables in the Derby database
     * @param noaa 
     */
    public void insertDataIntoTables(NoaaData noaa) {
        try
        {
            Class.forName(driver);
        }
        catch (Exception e) 
        {
            System.out.println("Failed to load  driver.");
            return;
        }
        try
        {
            Connection con = DriverManager.getConnection(url,username,password);
            Statement stmt = con.createStatement();
         
            String insertMetadataQuery = "INSERT INTO Metadata(Offset, Count, Limit) VALUES(" + 
                            String.valueOf(noaa.getMetadata().getResultset().getOffset()) + "," + 
                            String.valueOf(noaa.getMetadata().getResultset().getCount()) + "," +
                            String.valueOf(noaa.getMetadata().getResultset().getLimit()) +")";
            System.out.println(insertMetadataQuery + "\n"); //Outputs Noaa Metadata Insert query
            stmt.execute(insertMetadataQuery); //Inserts data into Metadata table
            
            String[] id = new String[noaa.getResults().size()];
            String[] name = new String[noaa.getResults().size()];
            
            for (int i = 0; i < noaa.getResults().size(); i++){
                id[i] = noaa.getResults().get(i).getId();
                name[i] = noaa.getResults().get(i).getName();
            }
            
            String[] resultsQuery = new String[noaa.getResults().size()];
            
            //for loop to add respective IDs and Names to query statements storing the queries in a String array 
            for (int i = 0; i < noaa.getResults().size(); i++){
                resultsQuery[i] = "INSERT INTO Results (ID, Name) VALUES(" + "'" + id[i] + "'" + "," + "'" + name[i] + "'" + ")";
            }
                
            //Outputs Noaa Results Insert queries for testing purposes
            for (int i = 0; i < noaa.getResults().size(); i++){
                System.out.println(resultsQuery[i]);
            }
                
            //for loop to insert data into Results table
            for (int i = 0; i < noaa.getResults().size(); i++){
                stmt.execute(resultsQuery[i]);
            }
            
            stmt.close();
            con.close();
        }
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
    
    /**
     * Deletes Derby database tables relating to the Noaa API
     */
    public void deleteTables() {
        try
        {
            Class.forName(driver);
        }
        catch (Exception x)
        {
            System.out.println(driver + " driver failed to load.");
            System.exit(-1);
        }
        try
        {
            Connection con = DriverManager.getConnection(url, username, password);
            Statement stmt = con.createStatement();
                    
            stmt.execute("DROP TABLE RESULTS");
            stmt.execute("DROP TABLE METADATA");

            stmt.close();
            con.close();
        }
        catch (Exception x)
        {
            System.out.println(x);
        }
    }
    
    /**
     * Retrieves each element in the ID column in Results table; stored in a String array
     * @return id
     */
    public String[] getIDList() {        
        String[] id = new String[12];
        String[] name = {"City","Climate Division","Climate Region","Country","County",
                         "Hydrologic Accounting Unit","Hydrologic Cataloging Unit","Hydrologic Region",
                         "Hydrologic Subregion","State","US Territory","Zip Code"};
        try
        {
            Class.forName(driver);
        }
        catch (Exception x)
        {
            System.out.println(driver + " driver failed to load.");
            System.exit(-1);
        }
        try
        {
            Connection con = DriverManager.getConnection(url, username, password);
            Statement stmt = con.createStatement();
            
            for (int i = 0; i < 12; i++){
                ResultSet rs = stmt.executeQuery("SELECT ID FROM Results WHERE Name = " + "'" + name[i] + "'");
                while (rs.next()){
                    id[i] = rs.getString("ID");
                }
            }
            stmt.close();
            con.close();
        }
        catch (Exception x)
        {
            System.out.println(x);
        }
        return id;
    }
    
    /**
     * Retrieves the corresponding name of the ID selected from the Results table in the Derby database
     * @param categoryID
     * @return 
     */
    public String getName(JComboBox categoryID) {      
        String name = "";
        
        try
        {
            Class.forName(driver);
        }
        catch (Exception x)
        {
            System.out.println(driver + " driver failed to load.");
            System.exit(-1);
        }
        try
        {
            Connection con = DriverManager.getConnection(url, username, password);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT NAME FROM RESULTS WHERE ID = " + "'" + String.valueOf(categoryID.getSelectedItem()) + "'");

            while (rs.next()){
                name = rs.getString("Name");
            }
            stmt.close();
            con.close();
        }
        catch (Exception x)
        {
            System.out.println(x);
        }
        return name;
    }
    
}
