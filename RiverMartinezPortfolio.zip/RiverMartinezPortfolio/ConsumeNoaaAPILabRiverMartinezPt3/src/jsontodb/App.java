package jsontodb;

import java.io.IOException;

/**  
 * IST 411-001 - Lab ConsumeNoaaAPI Part 3
 * App.java  
 * Purpose: Runs the Noaa GUI application
 *  
 * @author River Martinez  
 * @version 3.0 3/14/2021 
 */
public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        NoaaFrame n = new NoaaFrame();    
    } //end main
} //end class
