//Project By: Adama Doumbia, Alex Koontz, River Martinez, Catie Noble
//Assignment: Project Mastermind - Group Project
//Due December 11, 2020

package defaultpackage;

//Name of class: WhiteButtonException.java

/**
 * WhiteButtonException class inherits the Exception class.
 * If a player makes a guess with one or more JButtons containing a white background color in the guessed row, 
 * a WhiteButtonException is thrown.
 */
public class WhiteButtonException extends Exception
{
    /**
     * NoWhiteButtonException constructor
     */
    public WhiteButtonException()
    {
        super("Sorry, some buttons in the row are white.\nPlease guess again.");
    }
}
