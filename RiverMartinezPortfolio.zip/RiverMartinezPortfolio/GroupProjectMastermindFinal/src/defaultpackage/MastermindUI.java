//Project By: Adama Doumbia, Alex Koontz, River Martinez, Catie Noble
//Assignment: Project Mastermind - Group Project
//Due December 11, 2020

package defaultpackage;

//Name of class: MastermindUI.java

/**
 * MastermindUI class instantiates Mastermind game object and runs the game application
 */
public class MastermindUI
{
    /**
     * Runs Mastermind game application
     * @param args 
     */
    public static void main(String[] args)
    {
        MastermindGUI game = new MastermindGUI(); //Instantiation of MastermindGUI object
    }
}