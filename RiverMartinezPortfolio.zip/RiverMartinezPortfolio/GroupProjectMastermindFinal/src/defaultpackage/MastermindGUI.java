//Project By: Adama Doumbia, Alex Koontz, River Martinez, Catie Noble
//Assignment: Project Mastermind - Group Project
//Due December 11, 2020

package defaultpackage;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

//Name of class: MastermindGUI.java

/**
 * MastermindGUI class builds the graphical user interface for Mastermind game application, 
 * sets game rules and constraints, stores game score and information on game-play,
 * contains variables and arrays that are used during game-play, 
 * and contains the start, main game, and instructions panels for the Mastermind game application.
 * MastermindGUI extends the JFrame class, 
 * and implements the ActionListener interface to invoke changes on components during game-play
 */
public class MastermindGUI extends JFrame implements ActionListener
{
    private Container contentPane; //Container to hold the start, main game, and instructions panels
    private JPanel 
            startPanel, startPanelLabel, startPanelButton, //JPanels on the start screen
            
            gamePanel = new JPanel(new BorderLayout()), northPanel, northPanelLabels, northPanelButtons, centerPanel, 
            westPanel, eastPanel, southPanel, //JPanels on the main game screen
            
            instructionsPanel, instructionsLabelPanel, returnToGameButtonPanel; //JPanels on the instructions screen
    private JTextArea instructions; //JTextArea to display instructions for Mastermind
    private JButton startButton, //JButton on start screen
                    secretButton, clickButton, //JButtons on main game screen used during game-play
                    instructionsButton, checkAnswerButton, //JButtons on main game screen
                    returnToGameButton; //JButton on instructions screen
    private JLabel startLabel, picLabel, //start screen JLabels
                   bestGameMessage, countGamesMessage, countTriesMessage, //main game screen JLabels
                   instructionsLabel; //instruction screen JLabel
    private JRadioButton pegButton, indicatorButton; //pegs on main game screen; pegButton on east and indicatorButton on west
    private RoundIcon pegColor; //Used to color the full surface of pegButtons (oval shape); colors give clues to players
    private SquareIcon indicatorColor; //Used to color the full surface indicatorButton (square shape); indicates which row a player is playing
    private ArrayList<JButton> secretRow, //JButtons at the top of the main screen
                               clickRow; //one row of JButtons in the 10x4 grid of JButtons
    private ArrayList<ArrayList<JButton>> clickGrid; //whole 10x4 grid of JButtons
    private ArrayList<JRadioButton> pegRow, //one row of JRadioButtons in the 10x4 grid of JRadioButtons (east)
                                    indicatorRow; //one row of JRadioButtons in the 10x1 grid of JRadioButtons (west)
    private ArrayList<ArrayList<JRadioButton>> pegGrid, //whole 10x4 grid of JRadioButtons (east)
                                               indicatorGrid; //whole 10x1 grid of JRadio Buttons (west)
    private int clickCount = 0, //number of button clicks in 10x4 grid of JButtons
                currentGuess = 9, //holds value for which row a player is on; used for game and indicator pegs, and JButtons
                rowCount = 10, //number of tries left in a game; used for displaying tries and for determining end of game
                countNumGames = 0, //holds number of games played
                leastTries = 11; //holds the value of the least amount of tries played out of all games played
    private int[] secretInts = new int[4], //holds color int values for secret code
                  currentInts = new int[4]; //holds color int values for guess played
    BufferedImage brainPic; //holds a BufferedImage for the start screen logo
    
    /**
     * MastermindGUI constructor
     * Sets up JFrame and builds initial start screen
     * @throws java.io.IOException
     */
    public MastermindGUI()
    {
        contentPane = getContentPane(); //Container acts as JFrame
        setTitle("Mastermind"); //sets title of JFrame window
        setSize(710, 475); //sets size of JFrame
        setLocationRelativeTo(null); //sets JFrame Window in the center of the screen
        setResizable(false); //JFrame stretching disabled
        buildStart(); //builds Start Panel
        setVisible(true); //JFrame visible
        
        //Window inner listener for mid-game application closing
        addWindowListener(new WindowAdapter() 
        {
            @Override
            public void windowClosing(WindowEvent e) 
            {
                int response = JOptionPane.showConfirmDialog(null,"Are you sure you want to exit the program?", "Exit Program Message Box",JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {dispose();} 
                else if (response == JOptionPane.NO_OPTION) {setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);}
            }
        });
    }

    /**
     * Builds start screen for Mastermind game
     */
    private void buildStart()
    {   
        System.out.println("Start panel loaded");
        //Instantiation of overhead start screen JPanel
        startPanel = new JPanel(new GridLayout(3,1));
        startPanel.setBackground(Color.decode("#306CD0"));
        startPanel.setBorder(BorderFactory.createEmptyBorder(100,100,100,100));
        //Instantiation of start screen JLabel
        startLabel = new JLabel("Mastermind");
        startLabel.setFont(startLabel.getFont().deriveFont(68.0f));
        startLabel.setForeground(Color.white);
        //Instantiation of picture JLabel containing Mastermind ImageIcon
        try {this.brainPic = ImageIO.read(getClass().getResource("brain.png"));} 
        catch (IOException ex) {Logger.getLogger(MastermindGUI.class.getName()).log(Level.SEVERE, null, ex);}
        picLabel = new JLabel(new ImageIcon(brainPic));
        //Instantiation of start screen JButton
        startButton = new JButton("Play Game!");
        startButton.setPreferredSize(new Dimension(150,50));
        startButton.setBackground(Color.white);
        startButton.setForeground(Color.decode("#306CD0"));
        startButton.setFocusable(false);
        startButton.addActionListener(this);
        //Instantiation of start screen JPanel that only holds startLabel JLabel
        startPanelLabel = new JPanel();
        startPanelLabel.setBackground(Color.decode("#306CD0"));
        //Instantiation of start screen JPanel that only holds startButton JButton
        startPanelButton = new JPanel();
        startPanelButton.setBackground(Color.decode("#306CD0"));
        //Component additions
        startPanelLabel.add(startLabel);
        startPanelButton.add(startButton);
        startPanel.add(startPanelLabel);
        startPanel.add(picLabel);
        startPanel.add(startPanelButton);
        startPanel.setVisible(true);
        contentPane.add(startPanel);
    }
    
    /**
     * Builds main game screen for Mastermind game
     */
    private void buildGUI()
    {
        generateSecretCode(); //generates secret color/number code
        buildNorth(); //builds North panel
        buildWest(); //builds West panel
        buildCenter(); //builds Center panel
        buildEast(); //builds East panel
        buildSouth(); //builds South panel
        contentPane.add(gamePanel); //Adds gamePanel to contentPane
        gamePanel.setVisible(true); //gamePanel visible to players
    }
    
    /**
     * Builds north panel for main game screen
     */
    private void buildNorth()
    {
        //Instantiation of overhead north JPanel
        northPanel = new JPanel();
        northPanel.setBackground(Color.decode("#306CD0"));
        northPanel.setLayout(new GridLayout(2,1));
        //Instantiation of label north JPanel
        northPanelLabels = new JPanel(new BorderLayout());
        northPanelLabels.setBackground(Color.decode("#306CD0"));
        northPanelButtons = new JPanel();
        northPanelButtons.setBackground(Color.decode("#306CD0"));
        //Instantiation of instructions JButton
        instructionsButton = new JButton("Instructions");
        instructionsButton.setPreferredSize(new Dimension(130,25));
        instructionsButton.setBackground(Color.white);
        instructionsButton.setForeground(Color.decode("#306CD0"));
        instructionsButton.setFocusable(false);
        instructionsButton.addActionListener(this);
        //Instantiation of "# of Games Played:" JLabel
        countGamesMessage = new JLabel("               # of Games Played: " + String.valueOf(countNumGames) + "                                                ");
        countGamesMessage.setForeground(Color.white);
        //Instantiation of "Least Tries Played:" JLabel
        bestGameMessage = new JLabel("Least Tries Played:                 ");
        bestGameMessage.setForeground(Color.white);
        //Instantiation of "Tries Left:" JLabel
        countTriesMessage = new JLabel("Tries Left: " + String.valueOf(rowCount) + "");
        countTriesMessage.setForeground(Color.white);
        //Component additions
        northPanelButtons.add(instructionsButton);
        northPanelLabels.add(countGamesMessage, "West");
        northPanelLabels.add(countTriesMessage, "Center");
        northPanelLabels.add(bestGameMessage, "East");
        northPanel.add(northPanelButtons);
        northPanel.add(northPanelLabels);
        gamePanel.add(northPanel, "North");
    }

    /**
     * Builds west panel for main game screen
     */
    private void buildWest()
    {
        //Instantiation of west JPanel
        westPanel = new JPanel();
        westPanel.setBackground(Color.decode("#306CD0"));
        westPanel.setLayout(new GridLayout(12,4));
        //Add Boxes for spacing
        for (int i = 0; i < 8; i++)
        { 
            westPanel.add(Box.createRigidArea(new Dimension(0,20)));
        }
        //Instantiation of indicatorGrid, indicatorRows, and indicatorButtons
        indicatorGrid = new ArrayList();
        for (int i = 0; i < 10; i++)
        {
            indicatorRow = new ArrayList();
            for (int j = 0; j < 1; j++)
            {
                indicatorButton = new JRadioButton();
                indicatorButton.setBackground(Color.decode("#306CD0"));
                indicatorColor = new SquareIcon(Color.LIGHT_GRAY);
                if (i == 9)
                {
                    indicatorColor = new SquareIcon(Color.green);
                }
                indicatorButton.setBorder(BorderFactory.createLineBorder(Color.black, 5));
                indicatorButton.setIcon(indicatorColor);
                indicatorRow.add(indicatorButton);
            }
            indicatorGrid.add(indicatorRow);
        }
        //Component additions
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                westPanel.add(Box.createRigidArea(new Dimension(0,20)));
            }
            for (int j = 0; j < 1; j++)
            {
                westPanel.add(indicatorGrid.get(i).get(j));
            }
        }
        gamePanel.add(westPanel, "West");
    }
    
    /**
     * Builds center panel for main game screen
     */
    private void buildCenter()
    {
        //Instantiation of center JPanel
        centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(12, 4));
        centerPanel.setBackground(Color.decode("#306CD0"));
        //Instantiation of secretRow and secretButtons
        secretRow = new ArrayList();
        for (int i = 0; i < 4; i++)
        {
            secretButton = new JButton();
            secretButton.setBackground(Color.LIGHT_GRAY);
            secretButton.setEnabled(false);
            secretRow.add(secretButton);
            centerPanel.add(secretRow.get(i));
        }
        //Add Boxes for spacing
        for (int i = 0; i < 4; i++)
        { 
            centerPanel.add(Box.createRigidArea(new Dimension(0,20)));
        }
        //Instantiation of clickGrid, clickRows, and clickButtons
        clickGrid = new ArrayList();
        for (int i = 0; i < 10; i++)
        {
            clickRow = new ArrayList();
            for (int j = 0; j < 4; j++)
            {
                clickButton = new JButton();
                clickButton.setBackground(Color.white);
                clickButton.setText("0");
                clickButton.setFocusable(false);
                clickButton.addActionListener(this);
                if (i < 9)
                {
                    clickButton.setEnabled(false);
                }
                clickRow.add(clickButton);
            }
            clickGrid.add(clickRow);
        }
        //Component additions
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                centerPanel.add(clickGrid.get(i).get(j));
            }
        }
        gamePanel.add(centerPanel, "Center");
    }

    /**
     * Builds east panel for main game screen
     */
    private void buildEast()
    {
        //Instantiation of east JPanel
        eastPanel = new JPanel();
        eastPanel.setBackground(Color.decode("#306CD0"));
        eastPanel.setLayout(new GridLayout(12,4));
        //Add Boxes for spacing
        for (int i = 0; i < 8; i++)
        { 
            eastPanel.add(Box.createRigidArea(new Dimension(0,20)));
        }
        //Instantiation of pegGrid, pegRows, and pegButtons
        pegGrid = new ArrayList();
        for (int i = 0; i < 10; i++)
        {
            pegRow = new ArrayList();
            for (int j = 0; j < 4; j++)
            {
                pegButton = new JRadioButton();
                pegButton.setBackground(Color.decode("#306CD0"));
                pegColor = new RoundIcon(Color.LIGHT_GRAY);
                pegButton.setBorder(BorderFactory.createLineBorder(Color.black, 5));
                pegButton.setIcon(pegColor);
                pegRow.add(pegButton);
            }
            pegGrid.add(pegRow);
        }
        //Component additions
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                eastPanel.add(pegGrid.get(i).get(j));
            }
        }
        gamePanel.add(eastPanel, "East");
    }

    /**
     * Builds south panel for main game screen 
     */
    private void buildSouth()
    {
        //Instantiation of south JPanel
        southPanel = new JPanel();
        southPanel.setBackground(Color.decode("#306CD0"));
        //Instantiation of "Check Answer" JButton
        checkAnswerButton = new JButton("Check Answer");
        checkAnswerButton.setPreferredSize(new Dimension(130,25));
        checkAnswerButton.setBackground(Color.white);
        checkAnswerButton.setForeground(Color.decode("#306CD0"));
        checkAnswerButton.addActionListener(this);
        //Component additions
        southPanel.add(checkAnswerButton);
        gamePanel.add(southPanel, "South");
    }

    /**
     * appends pre-written instruction text to the instructions JTextArea
     */
    private void fillInstructions()
    {
        instructions.setFont(new Font("MS Boli", Font.BOLD, 12));
        instructions.append(" • Try to guess the secret code of colors/numbers (the hidden row at the very top) in the correct order to win the game\n");
        instructions.append(" • If you cannot guess the correct order of colors/numbers within ten tries, you will lose the game\n");
        instructions.append(" • One row of buttons will be enabled at a time for guessing; starting at the bottom and working your way up\n");
        instructions.append(" • Click on the buttons to cycle through the six (6) colors/numbers\n");
        instructions.append(" • When you have finished selecting your colors/numbers for the row, click “Check Answer” at the bottom of the window\n");
        instructions.append(" • The computer will compare your guess with the secret code, then give you the results in pegs (right side of the window)\n");
        instructions.append("                ○ A red peg means a color/number is present in the secret code and is in the correct position in the code\n");
        instructions.append("                ○ A white peg means a color/number is present in the secret code but is not in the correct position in the code\n");
        instructions.append("                ○ A gray peg means a color/number guessed is not present in the secret code\n");
        instructions.append(" • Note: The buttons in each row do not correspond to pegs in the peg rows\n");
        instructions.append(" • Tip: The feedback from the pegs, as well as your previous guesses, should be used to make decisions on your next guess\n");
        instructions.append(" • Lastly, a highlighted green square on the left side of the window will display where your guess should be made\n\n");
        instructions.append(" \t\t\t                 GOOD LUCK!\n\n");
        instructions.append(" • Color to number decoder:\n");
        instructions.append("                ○ White = 0\n");
        instructions.append("                ○ Red = 1\n");
        instructions.append("                ○ Yellow = 2\n");
        instructions.append("                ○ Green = 3\n");
        instructions.append("                ○ Cyan = 4\n");
        instructions.append("                ○ Blue = 5\n");
        instructions.append("                ○ Magenta = 6\n");
    }

    /**
     * Builds instructions screen for Mastermind game
     */
    private void buildInstructions()
    {
        //Instantiation of overhead instructions JPanel
        instructionsPanel = new JPanel(new BorderLayout());
        instructionsPanel.setBackground(Color.decode("#306CD0"));
        //Instantiation of label instructions JPanel
        instructionsLabelPanel = new JPanel();
        instructionsLabelPanel.setBackground(Color.decode("#306CD0"));
        instructionsLabel = new JLabel("Instructions and Gameplay");
        instructionsLabel.setForeground(Color.white);
        instructionsLabel.setFont(new Font("MS Boli", Font.BOLD, 14));
        //Instantiation of instructions JTextArea
        instructions = new JTextArea();
        instructions.setForeground(Color.white);
        instructions.setBackground(Color.decode("#306CD0"));
        instructions.setEditable(false);
        fillInstructions();
        //Instantiation of "Return to Game" JPanel
        returnToGameButtonPanel = new JPanel();
        returnToGameButtonPanel.setBackground(Color.decode("#306CD0"));
        returnToGameButton = new JButton("Return to Game");
        returnToGameButton.setPreferredSize(new Dimension(130,25));
        returnToGameButton.setBackground(Color.white);
        returnToGameButton.setForeground(Color.decode("#306CD0"));
        returnToGameButton.setFocusable(false);
        returnToGameButton.addActionListener(this);
        //Component additions
        instructionsLabelPanel.add(instructionsLabel);
        returnToGameButtonPanel.add(returnToGameButton);
        instructionsPanel.add(instructionsLabelPanel, "North");
        instructionsPanel.add(instructions, "Center");
        instructionsPanel.add(returnToGameButtonPanel, "South");
        contentPane.add(instructionsPanel);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) //abstract method actionPerformed()
    {
        //When player clicks start button on start page, start game
        if (e.getSource() == startButton)
        {
            System.out.println("Game Started");
            buildGUI();
            startPanel.setVisible(false);
        }
        
        //cycle through colors
        for (int i = 0; i < clickGrid.size(); i++)
        {
            for (int j = 0; j < clickRow.size(); j++)
            {
                final int q = j;
                if (e.getSource() == clickGrid.get(i).get(q))
                {
                    clickCount = getClickCount(clickGrid.get(i).get(j)); //retrieves integer value of JButton background color
                    clickCount++; //increments integer value of JButton background color
                    if (clickCount > 6) //if player clicks button while color is magenta, color will return back to red
                    {
                       clickCount = 1;
                    }
                    clickGrid.get(i).get(j).setBackground(getColor(clickCount)); //sets background color of JButton
                    if (clickCount == 1 || clickCount == 5) //if JButton background color is red or blue, text color is white
                    {
                        clickGrid.get(i).get(j).setForeground(Color.white);
                    }
                    else //if JButton background color is any other color, text color is black
                    {
                        clickGrid.get(i).get(j).setForeground(Color.black);
                    }
                    clickGrid.get(i).get(j).setText(String.valueOf(clickCount)); //sets text of JButton for color-blind compatability
                }
            }
        }
        
        //if "Instructions" button is pressed
        if (e.getSource() == instructionsButton)
        {
            buildInstructions(); //builds instructions screen
            gamePanel.setVisible(false); //main game screen is invisible
            instructionsPanel.setVisible(true); //instructions screen is visible
        }
        
        //if "Return to Game" button is pressed
        if (e.getSource() == returnToGameButton)
        {
            instructionsPanel.setVisible(false); //instructions screen is invisible
            gamePanel.setVisible(true); //main game screen is visible
        }
        
        //check answer
        if (e.getSource() == checkAnswerButton)
        {
            try
            {
                boolean isAnyCellWhite = false; //holds value for true or false if any played buttons are colored white
                checkAnswerButton.setFocusable(false);
                int pegMarker = 0; //After every guess peg marker is initialized back to 0
                //receive color values of played row (player guess)
                for (int i = 0; i < 4; i++)
                {
                    currentInts[i] = getClickCount(clickGrid.get(currentGuess).get(i)); //assignment of clickButton color background values
                    if(currentInts[i] == 0) //if any buttons hold a white number value of 0, isAnyCellWhite set true
                    {
                        isAnyCellWhite = true;
                    }
                }
                if(isAnyCellWhite == true) //if isAnyCellWhite is true, throw WhiteButtonException and have player guess again for that row
                {
                    throw new WhiteButtonException();
                }
                ArrayList<JRadioButton> currentPegRow = pegGrid.get(currentGuess); //Instantiation of current ArrayList of pegRow
                //peg color changes
                for (int i = 0; i < 4; i++)
                {
                    System.out.println(currentInts[i] + " ," + secretInts[i]);
                    if (currentInts[i] == secretInts[i]) //if corresponding columns in current row and secret row match, display red peg
                    {
                        currentPegRow.get(pegMarker).setIcon(new RoundIcon(Color.red));
                        pegMarker++;
                    }
                    //if non-corresponding columns in current row and secret row match, display white peg
                    else if (currentInts[i] == secretInts[0] || currentInts[i] == secretInts[1] || currentInts[i] == secretInts[2] || currentInts[i] == secretInts[3]) 
                    {
                        currentPegRow.get(pegMarker).setIcon(new RoundIcon(Color.white));
                        pegMarker++;
                    }
                }
                //disable clickable buttons of played row and set played row indicator color to light gray
                for (int i = 0; i < 4; i++)
                {
                    clickGrid.get(currentGuess).get(i).setEnabled(false);
                    if (i == 0)
                    {
                        indicatorGrid.get(currentGuess).get(i).setIcon(new SquareIcon(Color.LIGHT_GRAY));
                    }
                }
                currentGuess--;
                //used after all rows played; prevents ArrayOutOfBounds Exception
                if (currentGuess < 0)
                {
                    currentGuess = 0;
                }
                rowCount--; //decrement number of tries left
                //enable clickable buttons of next row and set played row indicator color to green
                for (int i = 0; i < 4; i++)
                {
                    clickGrid.get(currentGuess).get(i).setEnabled(true);
                    if (i == 0)
                    {
                        indicatorGrid.get(currentGuess).get(i).setIcon(new SquareIcon(Color.green));
                    }
                }
                System.out.println("Row count " + rowCount);
                //change label of message to fit number of tries left
                countTriesMessage.setText("Tries Left: " + String.valueOf(rowCount) + "               ");
                //if current row matches secret row, or if both current and secret rows do not match and last row is played
                if (    
                        //if rows match
                        (currentInts[0] == secretInts[0] && currentInts[1] == secretInts[1] 
                        && currentInts[2] == secretInts[2] && currentInts[3] == secretInts[3])
                        || 
                        //if rows do not match and all rows have been played
                        ((currentInts[0] != secretInts[0] || currentInts[1] != secretInts[1] 
                        || currentInts[2] != secretInts[2] || currentInts[3] != secretInts[3]) && rowCount < 1)
                    )
                {
                    checkAnswerButton.setEnabled(false); //disable check answer button
                    //displays background color of secret row
                    for (int i = 0; i < 4; i++)
                    {
                        secretRow.get(i).setBackground(getColor(secretInts[i]));
                        secretRow.get(i).setText(String.valueOf(secretInts[i]));
                    }
                    //disables all clickable buttons and sets color of last row indicator back to light gray
                    for (int i = 0; i < clickGrid.size(); i++)
                    {
                        for (int j = 0; j < clickRow.size(); j++)
                        {
                            clickGrid.get(i).get(j).setEnabled(false);
                            if (i == 0 && j == 0)
                            {
                                indicatorGrid.get(currentGuess).get(i).setIcon(new SquareIcon(Color.LIGHT_GRAY));
                            }
                        }
                    }
                    String gameWinResultMessage = "End of game."; //Initialization of String variable to hold game-ending display message
                    //if current row matches secret row
                    if (currentInts[0] == secretInts[0] && currentInts[1] == secretInts[1] && 
                        currentInts[2] == secretInts[2] && currentInts[3] == secretInts[3])
                    {
                        gameWinResultMessage = "You won! Do you want to play again?"; //displays "You won" message
                    }
                    //if current row does not match secret row and player guesses 10 times
                    else if ((currentInts[0] != secretInts[0] || currentInts[1] != secretInts[1] 
                           || currentInts[2] != secretInts[2] || currentInts[3] != secretInts[3]) && rowCount < 1) //if both current and secret rows do not match and last row is played
                    {
                        //needs condition filled out
                        gameWinResultMessage = "You lost! Do you want to play again?"; //displays "You lost" message
                    }
                    playAgainPopUpQuestion(gameWinResultMessage);
                }//end game ending if condition
            }//end try block
            catch(WhiteButtonException wb)
            {
                JOptionPane.showMessageDialog(this, wb.getMessage(), "Invalid Guess Input", JOptionPane.ERROR_MESSAGE);
            }//end catch block
        }//end if e.getSource() == checkAnswerButton
    }//end actionPerformed()

    /**
     * returns color of JButton based on the clickCount
     * @param clickCount
     * @return color
     */
    private Color getColor(int clickCount)
    {
        Color color = Color.white;
        switch (clickCount)
        {
            case 0 : color = Color.white; break;
            case 1 : color = Color.red; break;
            case 2 : color = Color.yellow; break;
            case 3 : color = Color.green; break;
            case 4 : color = Color.cyan; break;
            case 5 : color = Color.blue; break;
            case 6 : color = Color.magenta; break;
        }
        return color;
    }

    /**
     * returns integer value of JButton color based on the background color of a clickButton JButton
     * @param b
     * @return clickCount
     */
    private int getClickCount(JButton b)
    {
        if (b.getBackground() == Color.white){clickCount = 0;}
        if (b.getBackground() == Color.red){clickCount = 1;}
        if (b.getBackground() == Color.yellow){clickCount = 2;}
        if (b.getBackground() == Color.green){clickCount = 3;}
        if (b.getBackground() == Color.cyan){clickCount = 4;}
        if (b.getBackground() == Color.blue){clickCount = 5;}
        if (b.getBackground() == Color.magenta){clickCount = 6;}

        return clickCount;
    }
    
    /**
     * generates unique secret color/number code that does not contain duplicated colors/numbers
     */
    private void generateSecretCode()
    {
        secretInts[0] = 0; secretInts[1] = 0; secretInts[2] = 0; secretInts[3] = 0; //Initializes array values to 0
        //generates secret that does not allow the color white or duplicates of colors in the row
        while (secretInts[0] == 0)
        {
            secretInts[0] = (int) Math.floor(Math.random() * 6) + 1;
        }
        while (secretInts[1] == secretInts[0] || secretInts[1] == 0)
        {
            secretInts[1] = (int) Math.floor(Math.random() * 6) + 1;
        }
        while (secretInts[2] == secretInts[0] || secretInts[2] == secretInts[1] || secretInts[2] == 0)
        {
            secretInts[2] = (int) Math.floor(Math.random() * 6) + 1;
        }
        while (secretInts[3] == secretInts[0] || secretInts[3] == secretInts[1] || secretInts[3] == secretInts[2] || secretInts[3] == 0)
        {
            secretInts[3] = (int) Math.floor(Math.random() * 6) + 1;
        }
        System.out.println("Secret code: " + secretInts[0] + ", " + secretInts[1] + ", " + secretInts[2] + ", " + secretInts[3]);
    }

    /**
     * play again pop up question when guess and secret row match or when game ends
     * @param gameWinResultMessage
     */
    private void playAgainPopUpQuestion(String gameWinResultMessage)
    {
        int result = JOptionPane.showConfirmDialog(null,gameWinResultMessage, " Notice ", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.NO_OPTION) {dispose();} //if player does not want to play again
        else if (result == JOptionPane.YES_OPTION) //if player does want to play again
        {
            countNumGames++; //increments number of games played
            countGamesMessage.setText("               # of Games Played: " + String.valueOf(countNumGames) + "                                              ");
            if (currentInts[0] == secretInts[0] && currentInts[1] == secretInts[1] && 
                currentInts[2] == secretInts[2] && currentInts[3] == secretInts[3]) //if row matched
            {
                //if current least tries played is smaller than previous least tries played, current least tries is new leastTries
                if ((11 - rowCount) - 1 < leastTries){leastTries = (11 - rowCount) - 1;} 
                bestGameMessage.setText("Least Tries Played: " + String.valueOf(leastTries) + "                    ");
            }
            restartGame();
        }
    }

    /**
     * resets game for another round of game-play
     */
    private void restartGame()
    {
        generateSecretCode(); //generates new secret code
        currentGuess = 9; //starts back on bottom row
        rowCount = 10; //tries left variable back to 10
        countTriesMessage.setText("Tries Left: " + String.valueOf(rowCount) + "               ");
        checkAnswerButton.setEnabled(true); //enables check answer button
        //sets background color of all clickable buttons back to white
        for (int i = 0; i < clickGrid.size(); i++)
        {
            for (int j = 0; j < clickRow.size(); j++)
            {
                clickGrid.get(i).get(j).setBackground(getColor(0));
                clickGrid.get(i).get(j).setForeground(Color.BLACK);
                clickGrid.get(i).get(j).setText("0");
            }
        }
        //enables button clicks of bottom JButton row and sets color of bottom indicator row to green
        for (int i = 0; i < 4; i++)
        {
            clickGrid.get(currentGuess).get(i).setEnabled(true);
            if (i == 0)
            {
                indicatorGrid.get(currentGuess).get(i).setIcon(new SquareIcon(Color.green));
            }
        }
        //sets background color of all pegs back to light gray
        for (int i = 0; i < pegGrid.size(); i++)
        {
            for (int j = 0; j < pegRow.size(); j++)
            {
                pegColor = new RoundIcon(Color.LIGHT_GRAY);
                pegGrid.get(i).get(j).setIcon(pegColor);
            }
        }
        //sets background color of secret row to light gray
        for (int i = 0; i < secretRow.size(); i++)
        {
            secretRow.get(i).setBackground(Color.LIGHT_GRAY);
            secretRow.get(i).setText("");
        }
    }
}