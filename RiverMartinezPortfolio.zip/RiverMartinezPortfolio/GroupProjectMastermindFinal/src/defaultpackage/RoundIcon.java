//Project By: Adama Doumbia, Alex Koontz, River Martinez, Catie Noble
//Assignment: Project Mastermind - Group Project
//Due December 11, 2020

package defaultpackage;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import javax.swing.Icon;

//Name of class: RoundIcon.java

/**
 * RoundIcon class builds colored RoundIcons for game pegs. The source for this class was acquired from
 * https://coderanch.com/t/456966/java/give-color-JRadioButtons
 */
public class RoundIcon implements Icon 
{
    private Color color; //Declaration of Color object

    /**
     * RoundIcon constructor
     * @param c 
     */
    public RoundIcon(Color c) //RoundIcon constructor
    {
        color = c;
    }

    @Override
    public void paintIcon (Component c, Graphics g, int x, int y) 
    {
      g.setColor(color); //sets color of Graphics object
      g.fillOval (x, y, getIconWidth(), getIconHeight()); //Graphics icon in shape of an oval
    }
    
    @Override
    public int getIconWidth() {return 10;}
    
    @Override
    public int getIconHeight() {return 10;}
 }