//Project By: Adama Doumbia, Alex Koontz, River Martinez, Catie Noble
//Assignment: Project Mastermind - Group Project
//Due December 11, 2020

package defaultpackage;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import javax.swing.Icon;

//Name of class: SquareIcon.java

/**
 * SquareIcon class is a modified version of RoundIcon class, which builds colored SquareIcons for indicator pegs. 
 * The source for this class was acquired from
 * https://coderanch.com/t/456966/java/give-color-JRadioButtons
 */
public class SquareIcon implements Icon 
{
    private Color color; //Declaration of Color object

    /**
     * SquareIcon constructor
     * @param c 
     */
    public SquareIcon(Color c)
    {
        color = c;
    }

    @Override
    public void paintIcon (Component c, Graphics g, int x, int y) 
    {
      g.setColor(color); //sets color of Graphics object
      g.fillRect (x, y, getIconWidth(), getIconHeight()); //Graphics icon in shape of a rectangle
    }
    
    @Override
    public int getIconWidth() {return 10;}
    
    @Override
    public int getIconHeight() {return 10;}
}